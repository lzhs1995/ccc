//! Opt-in evidence of the foreground thread, independent of startup resume arguments.
//! This contains no credential and does not submit or interrupt any turn.

use super::App;
use codex_protocol::ThreadId;
use std::path::Path;
use std::time::Duration;
use std::time::Instant;

type Selection = (
    std::path::PathBuf,
    Option<ThreadId>,
    String,
    Option<codex_protocol::openai_models::ReasoningEffort>,
);

#[derive(Default)]
struct PublicationState {
    committed: Option<Selection>,
    attempted: Option<Selection>,
    retry_after: Option<Instant>,
}

impl PublicationState {
    fn publish(&mut self, selection: Selection, now: Instant) {
        if self.committed.as_ref() == Some(&selection)
            || (self.attempted.as_ref() == Some(&selection)
                && self.retry_after.is_some_and(|deadline| now < deadline))
        {
            return;
        }
        if publish_with_settings(
            &selection.0,
            selection.1,
            Some(&selection.2),
            selection.3.clone(),
        ) {
            self.committed = Some(selection);
            self.attempted = None;
            self.retry_after = None;
        } else {
            self.committed = None;
            self.attempted = Some(selection);
            self.retry_after = Some(now + Duration::from_secs(1));
        }
    }
}

pub(crate) fn client_epoch() -> uuid::Uuid {
    static EPOCH: std::sync::OnceLock<uuid::Uuid> = std::sync::OnceLock::new();
    *EPOCH.get_or_init(uuid::Uuid::new_v4)
}

impl App {
    pub(super) fn select_observed_thread(&mut self, thread_id: Option<ThreadId>) {
        self.active_thread_id = thread_id;
        // Observability failures must not change navigation or reconnect behavior.
        self.publish_observed_settings();
    }

    pub(super) fn publish_observed_settings(&self) {
        static PUBLICATION: std::sync::Mutex<PublicationState> =
            std::sync::Mutex::new(PublicationState {
                committed: None,
                attempted: None,
                retry_after: None,
            });
        let selection = (
            self.config.codex_home.to_path_buf(),
            self.active_thread_id,
            self.chat_widget.current_model().to_string(),
            self.chat_widget.current_reasoning_effort(),
        );
        PUBLICATION
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
            .publish(selection, Instant::now());
    }
}

#[cfg(test)]
fn publish(home: &Path, thread_id: Option<ThreadId>) {
    publish_with_settings(home, thread_id, None, None);
}

#[cfg(unix)]
fn publish_with_settings(
    home: &Path,
    thread_id: Option<ThreadId>,
    model: Option<&str>,
    effort: Option<codex_protocol::openai_models::ReasoningEffort>,
) -> bool {
    use std::ffi::CString;
    use std::fs;
    use std::io::Read;
    use std::io::Write;
    use std::os::fd::AsRawFd;
    use std::os::fd::FromRawFd;
    use std::os::unix::fs::MetadataExt;
    use std::os::unix::fs::OpenOptionsExt;
    use uuid::Uuid;

    let directory = home.join("credential-observations");
    let destination = CString::new(format!("client-{}-thread.json", std::process::id())).unwrap();
    // Retain the validated directory for every mutation, including failure cleanup.
    // A path replaced by a symlink must never redirect deletion to another directory.
    let Ok(root) = fs::OpenOptions::new()
        .read(true)
        .custom_flags(libc::O_DIRECTORY | libc::O_NOFOLLOW | libc::O_CLOEXEC)
        .open(&directory)
    else {
        return false;
    };
    let Ok(directory_metadata) = root.metadata() else {
        return false;
    };
    let Ok(home_metadata) = fs::symlink_metadata(home) else {
        return false;
    };
    if !home.is_absolute()
        || !home_metadata.is_dir()
        || directory_metadata.mode() & 0o077 != 0
        || directory_metadata.uid() != home_metadata.uid()
    {
        return false;
    }
    let open_relative = |name: &std::ffi::CStr, flags| -> std::io::Result<fs::File> {
        // SAFETY: root remains open, name is NUL-terminated, and the owned result
        // is converted into exactly one File only when openat succeeds.
        let fd = unsafe {
            libc::openat(
                root.as_raw_fd(),
                name.as_ptr(),
                flags | libc::O_CLOEXEC | libc::O_NOFOLLOW,
                0o600,
            )
        };
        if fd < 0 {
            return Err(std::io::Error::last_os_error());
        }
        Ok(unsafe { fs::File::from_raw_fd(fd) })
    };
    let temporary_name = CString::new(format!(
        ".client-{}-{}.tmp",
        std::process::id(),
        Uuid::new_v4()
    ))
    .unwrap();
    let attempt = || -> std::io::Result<()> {
        let identity = |m: &fs::Metadata| (m.dev(), m.ino(), m.mode(), m.uid());
        let mut marker = open_relative(c"enabled-v1", libc::O_RDONLY | libc::O_NONBLOCK)?;
        let marker_metadata = marker.metadata()?;
        if !marker_metadata.is_file()
            || marker_metadata.mode() & 0o077 != 0
            || marker_metadata.uid() != directory_metadata.uid()
            || marker_metadata.len() != 27
        {
            return Err(std::io::Error::other("invalid observation opt-in"));
        }
        let mut bytes = Vec::new();
        (&mut marker).take(28).read_to_end(&mut bytes)?;
        if bytes != b"ccc-request-credentials-v1\n"
            || identity(&marker_metadata)
                != identity(
                    &open_relative(c"enabled-v1", libc::O_RDONLY | libc::O_NONBLOCK)?.metadata()?,
                )
        {
            return Err(std::io::Error::other("changed observation opt-in"));
        }
        let mut record = serde_json::json!({
            "schema": 1,
            "purpose": "client_foreground_thread",
            "compact_interrupt_capability": "thread-compact-interrupt-v4",
            "pid": std::process::id(),
            "client_epoch": client_epoch(),
            "thread_id": thread_id.map(|id| id.to_string()),
            "published_at_ms": chrono::Utc::now().timestamp_millis(),
        });
        if let Some(model) = model {
            record["model"] = serde_json::json!(model);
            record["effort"] = serde_json::json!(effort);
        }
        let mut temporary = open_relative(
            &temporary_name,
            libc::O_WRONLY | libc::O_CREAT | libc::O_EXCL,
        )?;
        temporary.write_all(serde_json::to_string(&record)?.as_bytes())?;
        temporary.flush()?;
        if identity(&directory_metadata) != identity(&fs::symlink_metadata(&directory)?)
            || identity(&home_metadata) != identity(&fs::symlink_metadata(home)?)
        {
            return Err(std::io::Error::other("observation directory replaced"));
        }
        // SAFETY: both names are NUL-terminated and anchored to the retained fd.
        if unsafe {
            libc::renameat(
                root.as_raw_fd(),
                temporary_name.as_ptr(),
                root.as_raw_fd(),
                destination.as_ptr(),
            )
        } != 0
        {
            return Err(std::io::Error::last_os_error());
        }
        if identity(&directory_metadata) != identity(&fs::symlink_metadata(&directory)?)
            || identity(&home_metadata) != identity(&fs::symlink_metadata(home)?)
        {
            return Err(std::io::Error::other("observation directory replaced"));
        }
        Ok(())
    };
    let published = attempt().is_ok();
    if !published {
        // A failed new publication must not leave the previous selection usable.
        // SAFETY: cleanup uses only the retained directory, never a fresh path.
        unsafe {
            libc::unlinkat(root.as_raw_fd(), destination.as_ptr(), 0);
        }
    }
    // SAFETY: a random temporary name within the retained directory is ours.
    unsafe {
        libc::unlinkat(root.as_raw_fd(), temporary_name.as_ptr(), 0);
    }
    published
}

#[cfg(not(unix))]
fn publish_with_settings(
    _home: &Path,
    _thread_id: Option<ThreadId>,
    _model: Option<&str>,
    _effort: Option<codex_protocol::openai_models::ReasoningEffort>,
) -> bool {
    false
}

#[cfg(all(test, unix))]
#[path = "client_thread_observation_tests.rs"]
mod tests;
