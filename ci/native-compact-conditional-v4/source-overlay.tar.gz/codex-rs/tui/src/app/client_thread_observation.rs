//! Opt-in evidence of the foreground thread, independent of startup resume arguments.
//! This contains no credential and does not submit or interrupt any turn.

use super::App;
use codex_protocol::ThreadId;
use std::path::Path;

pub(crate) fn client_epoch() -> uuid::Uuid {
    static EPOCH: std::sync::OnceLock<uuid::Uuid> = std::sync::OnceLock::new();
    *EPOCH.get_or_init(uuid::Uuid::new_v4)
}

impl App {
    pub(super) fn select_observed_thread(&mut self, thread_id: Option<ThreadId>) {
        self.active_thread_id = thread_id;
        // Observability failures must not change navigation or reconnect behavior.
        publish(&self.config.codex_home, thread_id);
    }
}

#[cfg(unix)]
fn publish(home: &Path, thread_id: Option<ThreadId>) {
    use std::ffi::CString;
    use std::fs;
    use std::io::Read;
    use std::io::Write;
    use std::os::fd::AsRawFd;
    use std::os::fd::FromRawFd;
    use std::os::unix::fs::MetadataExt;
    use std::os::unix::fs::OpenOptionsExt;
    use uuid::Uuid;

    let directory = home.join("credential-observations");
    let destination = CString::new(format!("client-{}-thread.json", std::process::id())).unwrap();
    // Retain the validated directory for every mutation, including failure cleanup.
    // A path replaced by a symlink must never redirect deletion to another directory.
    let Ok(root) = fs::OpenOptions::new()
        .read(true)
        .custom_flags(libc::O_DIRECTORY | libc::O_NOFOLLOW | libc::O_CLOEXEC)
        .open(&directory)
    else {
        return;
    };
    let Ok(directory_metadata) = root.metadata() else {
        return;
    };
    let Ok(home_metadata) = fs::symlink_metadata(home) else {
        return;
    };
    if !home.is_absolute()
        || !home_metadata.is_dir()
        || directory_metadata.mode() & 0o077 != 0
        || directory_metadata.uid() != home_metadata.uid()
    {
        return;
    }
    let open_relative = |name: &std::ffi::CStr, flags| -> std::io::Result<fs::File> {
        // SAFETY: root remains open, name is NUL-terminated, and the owned result
        // is converted into exactly one File only when openat succeeds.
        let fd = unsafe {
            libc::openat(
                root.as_raw_fd(),
                name.as_ptr(),
                flags | libc::O_CLOEXEC | libc::O_NOFOLLOW,
                0o600,
            )
        };
        if fd < 0 {
            return Err(std::io::Error::last_os_error());
        }
        Ok(unsafe { fs::File::from_raw_fd(fd) })
    };
    let temporary_name = CString::new(format!(
        ".client-{}-{}.tmp",
        std::process::id(),
        Uuid::new_v4()
    ))
    .unwrap();
    let attempt = || -> std::io::Result<()> {
        let identity = |m: &fs::Metadata| (m.dev(), m.ino(), m.mode(), m.uid());
        let mut marker = open_relative(c"enabled-v1", libc::O_RDONLY | libc::O_NONBLOCK)?;
        let marker_metadata = marker.metadata()?;
        if !marker_metadata.is_file()
            || marker_metadata.mode() & 0o077 != 0
            || marker_metadata.uid() != directory_metadata.uid()
            || marker_metadata.len() != 27
        {
            return Err(std::io::Error::other("invalid observation opt-in"));
        }
        let mut bytes = Vec::new();
        (&mut marker).take(28).read_to_end(&mut bytes)?;
        if bytes != b"ccc-request-credentials-v1\n"
            || identity(&marker_metadata)
                != identity(
                    &open_relative(c"enabled-v1", libc::O_RDONLY | libc::O_NONBLOCK)?.metadata()?,
                )
        {
            return Err(std::io::Error::other("changed observation opt-in"));
        }
        let record = serde_json::json!({
            "schema": 1,
            "purpose": "client_foreground_thread",
            "compact_interrupt_capability": "thread-compact-interrupt-v4",
            "pid": std::process::id(),
            "client_epoch": client_epoch(),
            "thread_id": thread_id.map(|id| id.to_string()),
            "published_at_ms": chrono::Utc::now().timestamp_millis(),
        });
        let mut temporary = open_relative(
            &temporary_name,
            libc::O_WRONLY | libc::O_CREAT | libc::O_EXCL,
        )?;
        temporary.write_all(serde_json::to_string(&record)?.as_bytes())?;
        temporary.flush()?;
        if identity(&directory_metadata) != identity(&fs::symlink_metadata(&directory)?)
            || identity(&home_metadata) != identity(&fs::symlink_metadata(home)?)
        {
            return Err(std::io::Error::other("observation directory replaced"));
        }
        // SAFETY: both names are NUL-terminated and anchored to the retained fd.
        if unsafe {
            libc::renameat(
                root.as_raw_fd(),
                temporary_name.as_ptr(),
                root.as_raw_fd(),
                destination.as_ptr(),
            )
        } != 0
        {
            return Err(std::io::Error::last_os_error());
        }
        if identity(&directory_metadata) != identity(&fs::symlink_metadata(&directory)?)
            || identity(&home_metadata) != identity(&fs::symlink_metadata(home)?)
        {
            return Err(std::io::Error::other("observation directory replaced"));
        }
        Ok(())
    };
    if attempt().is_err() {
        // A failed new publication must not leave the previous selection usable.
        // SAFETY: cleanup uses only the retained directory, never a fresh path.
        unsafe {
            libc::unlinkat(root.as_raw_fd(), destination.as_ptr(), 0);
        }
    }
    // SAFETY: a random temporary name within the retained directory is ours.
    unsafe {
        libc::unlinkat(root.as_raw_fd(), temporary_name.as_ptr(), 0);
    }
}

#[cfg(not(unix))]
fn publish(_home: &Path, _thread_id: Option<ThreadId>) {}

#[cfg(all(test, unix))]
#[path = "client_thread_observation_tests.rs"]
mod tests;
