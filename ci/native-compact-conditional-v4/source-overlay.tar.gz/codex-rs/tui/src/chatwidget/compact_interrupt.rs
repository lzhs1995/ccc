//! Interrupt-only recovery entry. Ordinary Escape and /compact keep their own semantics.
//! The core decision is authoritative; an empty composer or visible status never grants control.
use super::ChatWidget;
use crate::app_command::AppCommand;
use codex_app_server_protocol::ThreadCompactInterruptParams;
use serde::Deserialize;

#[derive(Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
struct BoundInterrupt {
    client_pid: u32,
    client_epoch: uuid::Uuid,
    request: ThreadCompactInterruptParams,
}

impl ChatWidget {
    pub(super) fn dispatch_compact_interrupt(&mut self, text: &str) {
        if text.len() > 2048 || self.blocks_direct_input || self.active_side_conversation {
            self.add_error_message("Conditional interruption is unavailable for this view.".into());
            return;
        }
        let parsed = serde_json::from_str::<BoundInterrupt>(text);
        let Ok(bound) = parsed else {
            self.add_error_message("Invalid bound interruption request.".into());
            return;
        };
        if bound.client_pid != std::process::id()
            || bound.request.client_pid != bound.client_pid
            || bound.client_epoch != crate::app::client_thread_observation::client_epoch()
            || self.thread_id.map(|id| id.to_string()).as_deref()
                != Some(bound.request.thread_id.as_str())
            || self.input_queue.user_turn_pending_start
            || self.input_queue.has_queued_follow_up_messages()
        {
            self.add_error_message(
                "Interruption identity or pending-input boundary changed.".into(),
            );
            return;
        }
        // This bypasses user Escape's Goal pause and active-turn retargeting.
        // The request contains the original attempt and core independently checks the turn.
        self.submit_op(AppCommand::InterruptCompaction(bound.request));
    }
}
