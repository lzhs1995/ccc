//! Full-revision CAS for the join-accounting fence (real StateRuntime, real SQL).
use super::*;
use crate::runtime::test_support::test_thread_metadata;
use crate::runtime::test_support::unique_temp_dir;
use codex_utils_absolute_path::test_support::PathExt;
use pretty_assertions::assert_eq;

async fn seeded() -> (std::sync::Arc<StateRuntime>, ThreadId, crate::ThreadGoal) {
    let runtime = StateRuntime::init(
        crate::SqliteConfig::new_for_testing(unique_temp_dir().as_path().abs()),
        "test-provider".to_string(),
    )
    .await
    .expect("state db should initialize");
    let thread_id = ThreadId::from_string("00000000-0000-0000-0000-000000000456").unwrap();
    let home = runtime.sqlite().home();
    runtime
        .upsert_thread(&test_thread_metadata(
            home,
            thread_id,
            home.join("workspace"),
        ))
        .await
        .unwrap();
    let goal = runtime
        .thread_goals()
        .replace_thread_goal(thread_id, "finish", crate::ThreadGoalStatus::Active, None)
        .await
        .unwrap();
    (runtime, thread_id, goal)
}

async fn cas(
    runtime: &StateRuntime,
    thread_id: ThreadId,
    expected: &crate::ThreadGoal,
) -> GoalAccountingOutcome {
    runtime
        .thread_goals()
        .account_thread_goal_usage_expecting(
            thread_id,
            /*time_delta_seconds*/ 300,
            /*token_delta*/ 900,
            GoalAccountingMode::ActiveOnly,
            /*expected_goal_id*/ None,
            Some(expected),
        )
        .await
        .unwrap()
}

#[tokio::test]
async fn full_revision_cas_accounts_once_against_the_exact_row() {
    let (runtime, thread_id, pre) = seeded().await;
    let GoalAccountingOutcome::Updated(after) = cas(&runtime, thread_id, &pre).await else {
        panic!("exact pre row must be accounted");
    };
    assert_eq!((after.tokens_used, after.time_used_seconds), (900, 300));
    assert_eq!(
        (after.goal_id.as_str(), after.status),
        (pre.goal_id.as_str(), pre.status)
    );
    // The same pre row is now stale: no second accounting.
    assert!(matches!(
        cas(&runtime, thread_id, &pre).await,
        GoalAccountingOutcome::Unchanged(_)
    ));
    let current = runtime
        .thread_goals()
        .get_thread_goal(thread_id)
        .await
        .unwrap();
    assert_eq!(current, Some(after));
}

#[tokio::test]
async fn external_edit_or_same_second_replace_defeats_the_cas() {
    let (runtime, thread_id, pre) = seeded().await;
    // Budget edit keeps goal_id and status, so only the full-row CAS can notice it.
    let edited = runtime
        .thread_goals()
        .update_thread_goal(
            thread_id,
            GoalUpdate {
                objective: None,
                status: None,
                token_budget: Some(Some(50_000)),
                expected_goal_id: None,
            },
        )
        .await
        .unwrap()
        .unwrap();
    assert!(matches!(
        cas(&runtime, thread_id, &pre).await,
        GoalAccountingOutcome::Unchanged(_)
    ));
    assert_eq!(
        runtime
            .thread_goals()
            .get_thread_goal(thread_id)
            .await
            .unwrap(),
        Some(edited.clone())
    );
    // Positive control: the legacy goal_id-only path would have accounted over that edit.
    assert!(matches!(
        runtime
            .thread_goals()
            .account_thread_goal_usage(
                thread_id,
                1,
                1,
                GoalAccountingMode::ActiveOnly,
                Some(&pre.goal_id)
            )
            .await
            .unwrap(),
        GoalAccountingOutcome::Updated(_)
    ));
    // Same-second replace with identical objective/status: new goal_id, CAS misses.
    let replaced = runtime
        .thread_goals()
        .replace_thread_goal(thread_id, "finish", crate::ThreadGoalStatus::Active, None)
        .await
        .unwrap();
    assert_ne!(replaced.goal_id, pre.goal_id);
    assert!(matches!(
        cas(&runtime, thread_id, &pre).await,
        GoalAccountingOutcome::Unchanged(_)
    ));
    // Zero delta is Unchanged even against the exact row (goals.rs zero-delta return).
    assert!(matches!(
        runtime
            .thread_goals()
            .account_thread_goal_usage_expecting(
                thread_id,
                0,
                0,
                GoalAccountingMode::ActiveOnly,
                None,
                Some(&replaced)
            )
            .await
            .unwrap(),
        GoalAccountingOutcome::Unchanged(_)
    ));
}
