use super::*;
use pretty_assertions::assert_eq;
use std::os::unix::fs::MetadataExt;
use std::os::unix::fs::PermissionsExt;

const KEY: &str = "0123456789abcdef01234567";
const SECONDS: i64 = 1_760_000_000;

struct Fixture {
    _dir: tempfile::TempDir,
    base: PathBuf,
    root: PathBuf,
    params: ThreadCompactInterruptParams,
    rollout: PathBuf,
}

fn put(path: &Path, value: &Value) {
    std::fs::write(path, value.to_string()).unwrap();
    std::fs::set_permissions(path, std::fs::Permissions::from_mode(0o600)).unwrap();
}

fn pin(path: &Path) -> Value {
    json!({"path": path, "sha256": sha256_hex(&std::fs::read(path).unwrap())})
}

fn names(root: &Path) -> Vec<String> {
    let mut names: Vec<String> = std::fs::read_dir(root)
        .unwrap()
        .map(|e| e.unwrap().file_name().to_string_lossy().into_owned())
        .collect();
    names.sort();
    names
}

/// A real original journal: `edit` may break any document before it is written.
fn fixture(edit: impl FnOnce(&mut Value)) -> Fixture {
    // The manifest dir is runner-owned without group/world write, unlike /tmp.
    let dir = tempfile::tempdir_in(env!("CARGO_MANIFEST_DIR")).unwrap();
    let base = dir.path().canonicalize().unwrap();
    let root = base.join("journal");
    std::fs::create_dir(&root).unwrap();
    std::fs::set_permissions(&root, std::fs::Permissions::from_mode(0o700)).unwrap();
    let thread = uuid::Uuid::new_v4().to_string();
    let occurrence = uuid::Uuid::new_v4().to_string();
    let rollout = base.join("rollout.jsonl");
    std::fs::write(&rollout, b"{}\n").unwrap();
    let meta = std::fs::metadata(&rollout).unwrap();
    let file_id = json!([meta.dev(), meta.ino()]);
    let pid = std::process::id();
    let params = ThreadCompactInterruptParams {
        thread_id: thread.clone(),
        expected_turn_id: "turn-1".into(),
        compaction_occurrence: occurrence.clone(),
        attempt_id: KEY.into(),
        intent_path: root
            .join(format!("{KEY}-interrupt.json"))
            .to_string_lossy()
            .into_owned(),
        client_pid: pid,
    };
    let process = json!({"pid": pid, "birth": [SECONDS, 12], "tty": "/dev/ttys001"});
    let (workspace, pane, surface) = (
        uuid::Uuid::new_v4().to_string().to_uppercase(),
        uuid::Uuid::new_v4().to_string().to_uppercase(),
        uuid::Uuid::new_v4().to_string().to_uppercase(),
    );
    let now = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap()
        .as_secs_f64();
    let mut docs = json!({
        "intent": {"kind":"interrupt","session_id":thread,"binding":process,
            "params":{"threadId":thread,"turnId":"turn-1"},
            "client_request": serde_json::to_value(&params).unwrap(),
            "input_token":"tok-1","client_epoch":"epoch-1","goal_revision":null,
            "facts":{"path":rollout,"file_id":file_id,"user_offset":7}},
        "state": {"episode":{"key":KEY,"phase":"control_pending","turn_id":"turn-1",
            "compaction_occurrence":occurrence,"input_token":"tok-1","attempt":0,
            "started_at":now - 400.0,"path":rollout,"file_id":file_id,"user_offset":7,
            "goal":null},
            "authenticated_binding":{"process":process},"target":{"process":process}},
        "foreground": {"schema":1,"purpose":"client_foreground_thread","pid":pid,
            "client_epoch":"epoch-1","thread_id":thread,
            "compact_interrupt_capability":CAPABILITY},
        "enrollment": {"scope":"existing_compact_sessions_180_300_v2",
            "targets":[{"session_id":thread,"surface_id":surface,"workspace_id":workspace,
                "pane_id":pane,"process":{"pid":1}}]},
        "config": {"global_paused":false,"sessions":{}},
        "pending": [],
        "native": [],
        "authority": {"schema":AUTHORITY_SCHEMA,"episode_key":KEY,
            "intent_path":params.intent_path,"session_id":thread,
            "compaction_occurrence":occurrence,
            "target":{"workspace_id":workspace,"pane_id":pane,"surface_id":surface,
                "session_id":thread,"process":process},
            "client":{"pid":pid,"epoch":"epoch-1","thread_id":thread,"capability":CAPABILITY},
            "input_guard":{"safe":true,"caught_up":true,"token":"tok-1",
                "pending":[],"unknown":[]}},
    });
    edit(&mut docs);
    let files = [
        ("intent", format!("{KEY}-interrupt.json")),
        ("state", "state.json".into()),
        ("foreground", "foreground.json".into()),
        ("enrollment", "enrollment.json".into()),
        ("config", "config.json".into()),
        ("pending", "pending-inputs.json".into()),
        ("native", "native-input-intents.json".into()),
    ];
    for (doc, name) in &files {
        put(&root.join(name), &docs[*doc]);
    }
    let mut authority = docs["authority"].clone();
    authority["foreground"] = pin(&root.join("foreground.json"));
    authority["enrollment"] = pin(&root.join("enrollment.json"));
    authority["config"] = pin(&root.join("config.json"));
    authority["pinned_inputs"] = json!([
        pin(&root.join("pending-inputs.json")),
        pin(&root.join("native-input-intents.json")),
    ]);
    put(&root.join(format!("{KEY}-authority.json")), &authority);
    Fixture {
        _dir: dir,
        base,
        root,
        params,
        rollout,
    }
}
fn read(f: &Fixture) -> anyhow::Result<OriginalIntent> {
    OriginalIntent::read(&f.params, &f.rollout)
}

fn claimed(f: &Fixture) -> bool {
    f.root.join(format!("{KEY}-client-claimed.json")).exists()
}

#[test]
fn valid_original_claims_once_and_every_receipt_is_write_once() {
    let f = fixture(|_| {});
    let original = read(&f).unwrap();
    original.check_goal(None).unwrap();
    original.claim().unwrap();
    assert_eq!(
        original.claim().unwrap_err().kind(),
        std::io::ErrorKind::AlreadyExists
    );
    // A fresh read of the same original episode is not a new budget.
    assert_eq!(
        read(&f).unwrap().claim().unwrap_err().kind(),
        std::io::ErrorKind::AlreadyExists
    );
    original
        .receipt("interrupted", &json!({"turnId":"turn-1"}))
        .unwrap();
    assert!(original.receipt("interrupted", &json!({})).is_err());
    original.compact_intent().unwrap();
    assert_eq!(
        original.compact_intent().unwrap_err().kind(),
        std::io::ErrorKind::AlreadyExists
    );
    // A partial UNKNOWN claim is still the consumed budget; nothing was removed.
    std::fs::write(f.root.join(format!("{KEY}-client-claimed.json")), b"{").unwrap();
    assert!(original.claim().is_err());
    assert!(names(&f.root).contains(&format!("{KEY}-compact.json")));
}

#[test]
fn drift_after_read_is_rejected_before_any_side_effect() {
    let cases: [(&str, &[u8]); 7] = [
        ("intent", b"{\"kind\":\"interrupt\"}"),
        ("authority", b"{}"),
        ("state", b"{\"episode\":{}}"),
        ("foreground.json", b"{}"),
        ("pending-inputs.json", b"[1]"),
        ("native-input-intents.json", b"[1]"),
        ("config.json", b"{\"global_paused\":true}"),
    ];
    for (target, bytes) in cases {
        let f = fixture(|_| {});
        let original = read(&f).unwrap();
        let name = match target {
            "intent" => format!("{KEY}-interrupt.json"),
            "authority" => format!("{KEY}-authority.json"),
            "state" => "state.json".into(),
            other => other.into(),
        };
        std::fs::write(f.root.join(&name), bytes).unwrap();
        assert!(original.claim().is_err(), "{target} drift claimed");
        assert!(
            original.compact_intent().is_err(),
            "{target} drift wrote compact"
        );
        assert!(!claimed(&f), "{target} drift left a claim");
    }
}

#[test]
fn symlinked_or_replaced_ancestor_is_never_touched() {
    let f = fixture(|_| {});
    let original = read(&f).unwrap();
    let moved = f.base.join("moved");
    std::fs::rename(&f.root, &moved).unwrap();
    std::os::unix::fs::symlink(&moved, &f.root).unwrap();
    assert!(original.claim().is_err());
    assert!(!moved.join(format!("{KEY}-client-claimed.json")).exists());
    // Same bytes in a different directory inode is still a replaced ancestor.
    std::fs::remove_file(&f.root).unwrap();
    std::fs::create_dir(&f.root).unwrap();
    std::fs::set_permissions(&f.root, std::fs::Permissions::from_mode(0o700)).unwrap();
    for name in names(&moved) {
        std::fs::copy(moved.join(&name), f.root.join(&name)).unwrap();
    }
    assert!(original.claim().is_err());
    assert!(!claimed(&f) && !moved.join(format!("{KEY}-client-claimed.json")).exists());
    // A freshly opened symlinked journal is refused at read time too.
    let g = fixture(|_| {});
    let moved = g.base.join("moved");
    std::fs::rename(&g.root, &moved).unwrap();
    std::os::unix::fs::symlink(&moved, &g.root).unwrap();
    assert!(read(&g).is_err());
}

#[test]
fn untrusted_or_wrong_authority_is_rejected_before_any_write() {
    let cases: Vec<(&str, Box<dyn FnOnce(&mut Value)>)> = vec![
        (
            "enrollment target",
            Box::new(|d: &mut Value| {
                d["enrollment"]["targets"][0]["surface_id"] =
                    json!(uuid::Uuid::new_v4().to_string())
            }),
        ),
        (
            "enrollment duplicated",
            Box::new(|d: &mut Value| {
                let t = d["enrollment"]["targets"][0].clone();
                d["enrollment"]["targets"].as_array_mut().unwrap().push(t);
            }),
        ),
        (
            "enrollment scope",
            Box::new(|d: &mut Value| d["enrollment"]["scope"] = json!("restored_success")),
        ),
        (
            "enrollment empty",
            Box::new(|d: &mut Value| d["enrollment"]["targets"] = json!([])),
        ),
        (
            "process birth",
            Box::new(|d: &mut Value| {
                d["state"]["authenticated_binding"]["process"]["birth"] = json!([SECONDS, 13])
            }),
        ),
        (
            "birth not numeric",
            Box::new(|d: &mut Value| {
                for k in ["intent", "authority"] {
                    let p = if k == "intent" {
                        &mut d[k]["binding"]
                    } else {
                        &mut d[k]["target"]["process"]
                    };
                    p["birth"] = json!(["x", 12]);
                }
                d["state"]["authenticated_binding"]["process"]["birth"] = json!(["x", 12]);
            }),
        ),
        (
            "tty empty",
            Box::new(|d: &mut Value| d["authority"]["target"]["process"]["tty"] = json!("")),
        ),
        (
            "client epoch",
            Box::new(|d: &mut Value| d["authority"]["client"]["epoch"] = json!("epoch-2")),
        ),
        (
            "foreground epoch",
            Box::new(|d: &mut Value| d["foreground"]["client_epoch"] = json!("epoch-2")),
        ),
        (
            "foreground capability",
            Box::new(|d: &mut Value| d["foreground"]["compact_interrupt_capability"] = json!("v3")),
        ),
        (
            "global paused",
            Box::new(|d: &mut Value| d["config"]["global_paused"] = json!(true)),
        ),
        (
            "global paused absent",
            Box::new(|d: &mut Value| d["config"] = json!({"sessions":{}})),
        ),
        (
            "input pending",
            Box::new(|d: &mut Value| d["authority"]["input_guard"]["pending"] = json!(["x"])),
        ),
        (
            "input token",
            Box::new(|d: &mut Value| d["authority"]["input_guard"]["token"] = json!("tok-2")),
        ),
        (
            "schema",
            Box::new(|d: &mut Value| d["authority"]["schema"] = json!("ccc-compact-authority-v3")),
        ),
        (
            "occurrence",
            Box::new(|d: &mut Value| {
                d["authority"]["compaction_occurrence"] = json!(uuid::Uuid::new_v4().to_string())
            }),
        ),
        (
            "target uuid",
            Box::new(|d: &mut Value| d["authority"]["target"]["pane_id"] = json!("pane-1")),
        ),
    ];
    for (label, edit) in cases {
        let f = fixture(edit);
        let before = names(&f.root);
        assert!(read(&f).is_err(), "{label} accepted");
        assert_eq!(names(&f.root), before, "{label} wrote evidence");
    }
}

#[test]
fn group_writable_journal_is_untrusted() {
    let f = fixture(|_| {});
    std::fs::set_permissions(&f.root, std::fs::Permissions::from_mode(0o770 | 0o020)).unwrap();
    assert!(read(&f).is_err());
    assert!(!claimed(&f));
}
fn goal(thread: &str, goal_id: &str, created_ms: i64, updated_ms: i64) -> codex_state::ThreadGoal {
    codex_state::ThreadGoal {
        thread_id: codex_protocol::ThreadId::from_string(thread).unwrap(),
        goal_id: goal_id.into(),
        objective: "finish".into(),
        status: codex_state::ThreadGoalStatus::Active,
        token_budget: None,
        tokens_used: 5,
        time_used_seconds: 9,
        created_at: chrono::DateTime::from_timestamp_millis(created_ms).unwrap(),
        updated_at: chrono::DateTime::from_timestamp_millis(updated_ms).unwrap(),
    }
}

#[test]
fn same_second_goal_replace_is_rejected_by_revision() {
    let (created, updated) = (SECONDS * 1000 + 100, SECONDS * 1000 + 200);
    let f = fixture(|d| {
        let thread = d["intent"]["session_id"].clone();
        d["state"]["episode"]["goal"] = json!({"threadId":thread,"objective":"finish",
            "status":"active","tokenBudget":null,"tokensUsed":5,"timeUsedSeconds":9,
            "createdAt":SECONDS,"updatedAt":SECONDS});
        d["intent"]["goal_revision"] =
            json!({"goal_id":"goal-1","created_at_ms":created,"updated_at_ms":updated});
    });
    let original = read(&f).unwrap();
    let thread = f.params.thread_id.clone();
    original
        .check_goal(Some(&goal(&thread, "goal-1", created, updated)))
        .unwrap();
    // Identical API seconds, different revision: replace/ABA within one second.
    assert!(
        original
            .check_goal(Some(&goal(&thread, "goal-2", created, updated)))
            .is_err()
    );
    assert!(
        original
            .check_goal(Some(&goal(&thread, "goal-1", created, updated + 1)))
            .is_err()
    );
    assert!(original.check_goal(None).is_err());
    // Expected null Goal needs an explicit null revision, not an absent one.
    let g = fixture(|d| {
        d["intent"].as_object_mut().unwrap().remove("goal_revision");
    });
    assert!(read(&g).unwrap().check_goal(None).is_err());
}
