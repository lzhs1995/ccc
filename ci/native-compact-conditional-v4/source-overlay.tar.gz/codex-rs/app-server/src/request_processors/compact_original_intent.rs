//! CCC's existing episode key and write-once files are the operation budget.
//! A client claim is a receipt beneath that original journal, never a new budget.
//! The journal directory is opened once (no symlink component, trusted ancestry)
//! and every later read/write is anchored to that retained descriptor.
//! `<key>-authority.json` only pins evidence; it never itself grants control.
use codex_app_server_protocol::ThreadCompactInterruptParams;
use serde_json::Value;
use serde_json::json;
use sha2::Digest;
use sha2::Sha256;
use std::path::Path;
use std::path::PathBuf;

const MAX_EVIDENCE: u64 = 2 * 1024 * 1024;
const AUTHORITY_SCHEMA: &str = "ccc-compact-authority-v4";
const CAPABILITY: &str = "thread-compact-interrupt-v4";
const ENROLLMENT_SCOPES: [&str; 2] = [
    "four_existing_compact_sessions_180_300",
    "existing_compact_sessions_180_300_v2",
];
const REQUIRED_INPUT_PINS: [&str; 2] = ["pending-inputs.json", "native-input-intents.json"];

#[cfg(unix)]
mod jfs {
    use std::ffi::CString;
    use std::fs::File;
    use std::io::Read;
    use std::io::Write;
    use std::os::fd::AsRawFd;
    use std::os::fd::FromRawFd;
    use std::os::unix::ffi::OsStrExt;
    use std::os::unix::fs::MetadataExt;
    use std::path::Component;
    use std::path::Path;

    /// A canonical directory whose every ancestor was opened without following symlinks.
    pub(super) struct Dir {
        path: std::path::PathBuf,
        chain: Vec<(u64, u64)>,
        fd: File,
    }

    fn other(message: &str) -> std::io::Error {
        std::io::Error::other(message.to_string())
    }

    fn open_at(
        dir: libc::c_int,
        name: &std::ffi::OsStr,
        flags: libc::c_int,
    ) -> std::io::Result<File> {
        let name = CString::new(name.as_bytes()).map_err(|_| other("NUL in evidence name"))?;
        let fd = unsafe {
            libc::openat(
                dir,
                name.as_ptr(),
                flags | libc::O_CLOEXEC | libc::O_NOFOLLOW,
                0o600,
            )
        };
        if fd < 0 {
            return Err(std::io::Error::last_os_error());
        }
        Ok(unsafe { File::from_raw_fd(fd) })
    }

    /// Ancestors may be root-owned system directories; the journal itself is ours.
    fn trusted(meta: &std::fs::Metadata, leaf: bool) -> bool {
        let euid = unsafe { libc::geteuid() };
        meta.is_dir()
            && meta.mode() & 0o022 == 0
            && (meta.uid() == euid || (!leaf && meta.uid() == 0))
    }

    /// Exactly one normal path component, so `openat` can never walk elsewhere.
    pub(super) fn leaf(name: &str) -> std::io::Result<&std::ffi::OsStr> {
        let mut components = Path::new(name).components();
        match (components.next(), components.next()) {
            (Some(Component::Normal(part)), None) if part.as_bytes() == name.as_bytes() => Ok(part),
            _ => Err(other("evidence name is not a single component")),
        }
    }

    impl Dir {
        pub(super) fn open(path: &Path) -> std::io::Result<Self> {
            if !path.is_absolute() || path.canonicalize()? != path {
                return Err(other("noncanonical journal path"));
            }
            let root = CString::new("/").expect("static root");
            let fd = unsafe {
                libc::open(
                    root.as_ptr(),
                    libc::O_RDONLY | libc::O_DIRECTORY | libc::O_CLOEXEC,
                )
            };
            if fd < 0 {
                return Err(std::io::Error::last_os_error());
            }
            let mut current = unsafe { File::from_raw_fd(fd) };
            let parts: Vec<_> = path.components().skip(1).collect();
            let mut chain = Vec::with_capacity(parts.len() + 1);
            for index in 0..=parts.len() {
                if index > 0 {
                    let Component::Normal(name) = parts[index - 1] else {
                        return Err(other("journal path has a non-normal component"));
                    };
                    current = open_at(
                        current.as_raw_fd(),
                        name,
                        libc::O_RDONLY | libc::O_DIRECTORY,
                    )?;
                }
                let meta = current.metadata()?;
                if !trusted(&meta, index == parts.len()) {
                    return Err(other("untrusted journal ancestry owner/mode"));
                }
                chain.push((meta.dev(), meta.ino()));
            }
            Ok(Self {
                path: path.to_path_buf(),
                chain,
                fd: current,
            })
        }

        /// Re-walk from `/`: a renamed, replaced or symlinked ancestor changes the chain.
        pub(super) fn verify(&self) -> std::io::Result<()> {
            let fresh = Self::open(&self.path)?;
            let retained = self.fd.metadata()?;
            if fresh.chain != self.chain
                || !trusted(&retained, true)
                || self.chain.last() != Some(&(retained.dev(), retained.ino()))
            {
                return Err(other("journal ancestry replaced"));
            }
            Ok(())
        }

        /// Owned, single-link, bounded regular file read relative to the retained fd.
        pub(super) fn read(&self, name: &str) -> std::io::Result<Vec<u8>> {
            let name = leaf(name)?;
            let file = open_at(self.fd.as_raw_fd(), name, libc::O_RDONLY | libc::O_NONBLOCK)?;
            let before = file.metadata()?;
            if !before.is_file() || before.len() > super::MAX_EVIDENCE {
                return Err(other("unbounded or nonregular evidence"));
            }
            if before.uid() != unsafe { libc::geteuid() }
                || before.mode() & 0o022 != 0
                || before.nlink() != 1
            {
                return Err(other("untrusted evidence owner/mode/link"));
            }
            let mut raw = Vec::new();
            (&file)
                .take(super::MAX_EVIDENCE + 1)
                .read_to_end(&mut raw)?;
            let after = open_at(self.fd.as_raw_fd(), name, libc::O_RDONLY | libc::O_NONBLOCK)?
                .metadata()?;
            let identity = |m: &std::fs::Metadata| {
                (
                    m.dev(),
                    m.ino(),
                    m.len(),
                    m.mtime(),
                    m.mtime_nsec(),
                    m.ctime(),
                    m.ctime_nsec(),
                )
            };
            if identity(&before) != identity(&after) || raw.len() as u64 != before.len() {
                return Err(other("evidence replaced or changed during read"));
            }
            Ok(raw)
        }

        /// Create-new only; a failed or partial write still consumes the name.
        /// Nothing here ever unlinks: cleanup would need a path walk we do not trust.
        pub(super) fn write_once(&self, name: &str, bytes: &[u8]) -> std::io::Result<()> {
            self.verify()?;
            let name = leaf(name)?;
            let mut file = open_at(
                self.fd.as_raw_fd(),
                name,
                libc::O_WRONLY | libc::O_CREAT | libc::O_EXCL,
            )?;
            file.write_all(bytes)?;
            file.sync_all()?;
            self.fd.sync_all()
        }
    }
}

#[cfg(not(unix))]
mod jfs {
    use std::path::Path;

    /// The original CCC journal is POSIX-only; elsewhere the reader refuses.
    pub(super) struct Dir;

    impl Dir {
        pub(super) fn open(_: &Path) -> std::io::Result<Self> {
            Err(std::io::Error::other("original CCC journal requires unix"))
        }
        pub(super) fn verify(&self) -> std::io::Result<()> {
            unreachable!("never constructed")
        }
        pub(super) fn read(&self, _: &str) -> std::io::Result<Vec<u8>> {
            unreachable!("never constructed")
        }
        pub(super) fn write_once(&self, _: &str, _: &[u8]) -> std::io::Result<()> {
            unreachable!("never constructed")
        }
    }
}

/// An exact-byte pin named by the authority; any drift is a veto.
#[derive(Clone)]
struct Pin {
    path: PathBuf,
    sha256: String,
}

fn sha256_hex(bytes: &[u8]) -> String {
    format!("{:x}", Sha256::digest(bytes))
}

impl Pin {
    fn parse(value: &Value) -> anyhow::Result<Self> {
        let path = value["path"].as_str().map(PathBuf::from);
        let sha256 = value["sha256"].as_str().unwrap_or_default().to_string();
        anyhow::ensure!(
            value.as_object().is_some_and(|o| o.len() == 2)
                && path.as_ref().is_some_and(|p| p.is_absolute())
                && sha256.len() == 64
                && sha256
                    .bytes()
                    .all(|b| matches!(b, b'0'..=b'9' | b'a'..=b'f')),
            "malformed authority pin"
        );
        Ok(Self {
            path: path.expect("checked"),
            sha256,
        })
    }

    fn name(&self) -> Option<&str> {
        self.path.file_name().and_then(|s| s.to_str())
    }

    /// Owned/bounded read through a freshly verified parent; bytes must hash exactly.
    fn bytes(&self) -> anyhow::Result<Vec<u8>> {
        let parent = self
            .path
            .parent()
            .ok_or_else(|| anyhow::anyhow!("pin has no parent"))?;
        let name = self
            .name()
            .ok_or_else(|| anyhow::anyhow!("pin has no name"))?;
        let raw = jfs::Dir::open(parent)?.read(name)?;
        anyhow::ensure!(sha256_hex(&raw) == self.sha256, "pinned evidence drifted");
        Ok(raw)
    }

    fn json(&self) -> anyhow::Result<Value> {
        Ok(serde_json::from_slice(&self.bytes()?)?)
    }
}

fn exact_uuid(value: &Value) -> bool {
    value.as_str().is_some_and(|s| {
        uuid::Uuid::parse_str(s).is_ok_and(|id| {
            let lower = id.to_string();
            s == lower || s == lower.to_uppercase()
        })
    })
}

/// Positive PID, numeric [seconds, usec] birth and a nonempty tty.
fn process_ok(process: &Value) -> bool {
    process["pid"]
        .as_u64()
        .is_some_and(|pid| pid > 0 && pid <= i32::MAX as u64)
        && process["birth"].as_array().is_some_and(|birth| {
            birth.len() == 2
                && birth[0].as_u64().is_some_and(|s| s > 0)
                && birth[1].as_u64().is_some_and(|us| us < 1_000_000)
        })
        && process["tty"].as_str().is_some_and(|tty| !tty.is_empty())
}

fn same_process(left: &Value, right: &Value) -> bool {
    ["pid", "birth", "tty"]
        .iter()
        .all(|field| left[*field] == right[*field])
}

pub(super) struct OriginalIntent {
    journal: jfs::Dir,
    path: PathBuf,
    raw: Vec<u8>,
    authority_raw: Vec<u8>,
    value: Value,
    episode: Value,
    binding: Value,
    pins: Vec<Pin>,
    /// Original enrolled (model, effort) named by the raw authority.
    settings: (Value, Value),
    key: String,
}
impl OriginalIntent {
    pub(super) fn read(
        params: &ThreadCompactInterruptParams,
        rollout: &Path,
    ) -> anyhow::Result<Self> {
        let key = &params.attempt_id;
        anyhow::ensure!(
            uuid::Uuid::parse_str(&params.compaction_occurrence)
                .is_ok_and(|id| id.to_string() == params.compaction_occurrence),
            "invalid native compaction occurrence"
        );
        anyhow::ensure!(
            key.len() == 24 && key.bytes().all(|b| b.is_ascii_hexdigit()),
            "invalid original episode key"
        );
        let path = PathBuf::from(&params.intent_path);
        let intent_name = format!("{key}-interrupt.json");
        anyhow::ensure!(
            path.file_name().and_then(|s| s.to_str()) == Some(intent_name.as_str()),
            "wrong original intent filename"
        );
        let journal = jfs::Dir::open(
            path.parent()
                .ok_or_else(|| anyhow::anyhow!("intent has no journal"))?,
        )?;
        let raw = journal.read(&intent_name)?;
        let value: Value = serde_json::from_slice(&raw)?;
        let state: Value = serde_json::from_slice(&journal.read("state.json")?)?;
        let episode = state["episode"].clone();
        let now = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)?
            .as_secs_f64();
        anyhow::ensure!(
            value["kind"] == "interrupt"
                && value["session_id"] == params.thread_id
                && value["binding"]["pid"] == params.client_pid
                && value["params"]
                    == json!({"threadId":params.thread_id,"turnId":params.expected_turn_id})
                && value["client_request"] == serde_json::to_value(params)?,
            "legacy, UNKNOWN or different transport intent"
        );
        anyhow::ensure!(
            episode["key"] == *key
                && episode["phase"] == "control_pending"
                && episode["turn_id"] == params.expected_turn_id
                && episode["compaction_occurrence"] == params.compaction_occurrence
                && episode["input_token"] == value["input_token"]
                && episode["input_token"].is_string()
                && episode["attempt"].as_u64().is_some_and(|n| n < 2)
                && episode["started_at"]
                    .as_f64()
                    .is_some_and(|at| at.is_finite() && now >= at + 300.0),
            "episode deadline, budget or boundary changed"
        );
        anyhow::ensure!(
            episode["path"].as_str() == rollout.to_str()
                && value["facts"]["path"] == episode["path"]
                && value["facts"]["file_id"] == episode["file_id"]
                && value["facts"]["user_offset"] == episode["user_offset"],
            "original rollout boundary changed"
        );
        let stat = std::fs::symlink_metadata(rollout)?;
        #[cfg(unix)]
        {
            use std::os::unix::fs::MetadataExt;
            anyhow::ensure!(
                episode["file_id"] == json!([stat.dev(), stat.ino()]),
                "rollout inode changed"
            );
        }
        let authority_raw = journal.read(&format!("{key}-authority.json"))?;
        let authority: Value = serde_json::from_slice(&authority_raw)?;
        let (binding, pins, settings) = check_authority(params, &path, &value, &state, &authority)?;
        let original = Self {
            journal,
            path,
            raw,
            authority_raw,
            value,
            episode,
            binding,
            pins,
            settings,
            key: key.clone(),
        };
        original.revalidate()?;
        Ok(original)
    }

    /// Ancestry, raw intent, raw authority, original episode/binding and every pin.
    pub(super) fn revalidate(&self) -> anyhow::Result<()> {
        self.journal.verify()?;
        anyhow::ensure!(
            self.journal.read(&format!("{}-interrupt.json", self.key))? == self.raw,
            "original intent changed"
        );
        anyhow::ensure!(
            self.journal.read(&format!("{}-authority.json", self.key))? == self.authority_raw,
            "original authority changed"
        );
        let state: Value = serde_json::from_slice(&self.journal.read("state.json")?)?;
        anyhow::ensure!(state["episode"] == self.episode, "original episode changed");
        anyhow::ensure!(
            current_process(&state).is_some_and(|process| same_process(process, &self.binding)),
            "authenticated binding changed"
        );
        for pin in &self.pins {
            pin.bytes()?;
        }
        Ok(())
    }

    /// Full API Goal (seconds, as thread_goal_processor maps it) plus the persisted
    /// revision (goal_id + millis) so a same-second replace cannot pass as ABA.
    pub(super) fn check_goal(&self, goal: Option<&codex_state::ThreadGoal>) -> Result<(), String> {
        let (actual, revision) = match goal {
            Some(goal) => (
                json!({"threadId":goal.thread_id.to_string(),"objective":goal.objective,
                    "status":goal.status.as_str(),"tokenBudget":goal.token_budget,
                    "tokensUsed":goal.tokens_used,"timeUsedSeconds":goal.time_used_seconds,
                    "createdAt":goal.created_at.timestamp(),
                    "updatedAt":goal.updated_at.timestamp()}),
                json!({"goal_id":goal.goal_id,
                    "created_at_ms":goal.created_at.timestamp_millis(),
                    "updated_at_ms":goal.updated_at.timestamp_millis()}),
            ),
            None => (Value::Null, Value::Null),
        };
        // `get` so an absent goal_revision never matches an expected null Goal.
        if actual != self.episode["goal"] || self.value.get("goal_revision") != Some(&revision) {
            return Err("original Goal identity changed".into());
        }
        Ok(())
    }

    /// Final native gate: the thread's current model/effort must still be the
    /// original enrolled target's. `None` never matches a named effort.
    pub(super) fn check_settings(
        &self,
        model: &str,
        effort: Option<&codex_protocol::openai_models::ReasoningEffort>,
    ) -> Result<(), String> {
        let effort = effort.map_or(Value::Null, |effort| json!(effort.as_str()));
        if self.settings.0.as_str() != Some(model) || self.settings.1 != effort {
            return Err("original target model/effort changed".into());
        }
        Ok(())
    }

    /// Post-join Goal gate. Without join accounting the Goal must be unchanged. With
    /// the original turn's one-use receipt, its pre row must be exactly the pinned
    /// original Goal and the current row exactly what that accounting UPDATE returned;
    /// identity, objective, budget and active status never change. Any other row,
    /// however monotone, is an external edit and vetoes.
    pub(super) fn check_goal_after_join(
        &self,
        current: Option<&codex_state::ThreadGoal>,
        join: &codex_goal_extension::JoinAccounting,
        turn_id: &str,
        attempt_id: &str,
    ) -> Result<(), String> {
        let receipt = match join {
            codex_goal_extension::JoinAccounting::NotAccounted => return self.check_goal(current),
            codex_goal_extension::JoinAccounting::Accounted(receipt) => receipt,
        };
        // Defense in depth: finish already keys the fence, but the reader re-binds it.
        if receipt.turn_id != turn_id || receipt.attempt_id != attempt_id || attempt_id != self.key
        {
            return Err("Goal join receipt is for another turn or attempt".into());
        }
        self.check_goal(Some(&receipt.before))?;
        let (before, after) = (&receipt.before, &receipt.after);
        let active = codex_state::ThreadGoalStatus::Active;
        if current != Some(after)
            || after.thread_id != before.thread_id
            || after.goal_id != before.goal_id
            || after.objective != before.objective
            || after.token_budget != before.token_budget
            || after.created_at != before.created_at
            || before.status != active
            || after.status != active
            || after.tokens_used < before.tokens_used
            || after.time_used_seconds < before.time_used_seconds
            || (after.tokens_used, after.time_used_seconds)
                == (before.tokens_used, before.time_used_seconds)
        {
            return Err("Goal changed outside the original turn's join accounting".into());
        }
        Ok(())
    }

    /// Shape carried by the compact-started receipt so CCC can adopt exactly this
    /// accounting into its next episode; the original intent's goal stays unchanged.
    pub(super) fn join_accounting_json(join: &codex_goal_extension::JoinAccounting) -> Value {
        let revision = |goal: &codex_state::ThreadGoal| {
            json!({"goal_id":goal.goal_id,"tokens_used":goal.tokens_used,
                "time_used_seconds":goal.time_used_seconds,
                "created_at_ms":goal.created_at.timestamp_millis(),
                "updated_at_ms":goal.updated_at.timestamp_millis()})
        };
        match join {
            codex_goal_extension::JoinAccounting::NotAccounted => json!({"status":"not_accounted"}),
            codex_goal_extension::JoinAccounting::Accounted(receipt) => json!({
                "status":"accounted","turnId":receipt.turn_id,"attemptId":receipt.attempt_id,
                "before":revision(&receipt.before),"after":revision(&receipt.after)}),
        }
    }

    fn write_once(&self, name: &str, value: &Value) -> std::io::Result<()> {
        self.revalidate()
            .map_err(|error| std::io::Error::other(format!("CCC boundary changed: {error}")))?;
        self.journal
            .write_once(name, format!("{value}\n").as_bytes())
    }

    pub(super) fn claim(&self) -> std::io::Result<()> {
        self.receipt("client-claimed", &json!({"status":"UNKNOWN"}))
    }

    pub(super) fn receipt(&self, phase: &str, fields: &Value) -> std::io::Result<()> {
        self.write_once(
            &format!("{}-{phase}.json", self.key),
            &json!({"original_intent":self.path,"episode_key":self.key,"fields":fields}),
        )
    }

    pub(super) fn compact_intent(&self) -> std::io::Result<()> {
        let mut value = self.value.clone();
        value["kind"] = json!("compact");
        value["params"] = json!({"threadId": self.value["session_id"]});
        value["turn"]["status"] = json!("interrupted");
        value["client_interruption_receipt"] = json!(format!("{}-interrupted.json", self.key));
        self.write_once(&format!("{}-compact.json", self.key), &value)
    }
}

/// state.authenticated_binding.process after adoption, else the original target process.
fn current_process(state: &Value) -> Option<&Value> {
    match &state["authenticated_binding"] {
        Value::Null => state["target"]["process"]
            .as_object()
            .map(|_| &state["target"]["process"]),
        binding => binding["process"].as_object().map(|_| &binding["process"]),
    }
}

/// Canonical UUID text (ccc_compact_guard._uuid is upper-case str(UUID)).
fn canonical_uuid(value: &Value) -> Option<String> {
    uuid::Uuid::parse_str(value.as_str()?)
        .ok()
        .map(|id| id.to_string().to_uppercase())
}

/// Python `row.get(field, clear) is not clear`: absent is clear, any other value vetoes.
fn vetoes(row: &Value, field: &str, clear: bool) -> bool {
    row.get(field)
        .is_some_and(|value| *value != Value::Bool(clear))
}

/// Mirrors ccc_compact_guard._current_config_clear plus the enrolled target's
/// recovery_enabled (watchdog default True). UUIDs compare canonically; an
/// unparseable id in a list or rule fails closed instead of being skipped.
fn config_clear(config: &Value, target: &Value, enrolled: &Value) -> anyhow::Result<()> {
    let surface = canonical_uuid(&target["surface_id"])
        .ok_or_else(|| anyhow::anyhow!("authority surface is not a UUID"))?;
    let workspace = canonical_uuid(&target["workspace_id"])
        .ok_or_else(|| anyhow::anyhow!("authority workspace is not a UUID"))?;
    anyhow::ensure!(
        !vetoes(config, "global_paused", false)
            && config.get("mode").is_none_or(|mode| *mode == "armed"),
        "current CCC mode is paused or not armed"
    );
    let list = |value: &Value| -> anyhow::Result<Vec<Value>> {
        match value {
            Value::Null => Ok(Vec::new()),
            Value::Array(rows) => Ok(rows.clone()),
            _ => anyhow::bail!("CCC config list is malformed"),
        }
    };
    let ids = |value: &Value| -> anyhow::Result<Vec<String>> {
        list(value)?
            .iter()
            .map(|id| {
                canonical_uuid(id).ok_or_else(|| anyhow::anyhow!("CCC config id is not a UUID"))
            })
            .collect()
    };
    let mut selected = vec![enrolled.clone()];
    for row in list(&config["targets"])? {
        let id = canonical_uuid(&row["surface_id"])
            .ok_or_else(|| anyhow::anyhow!("CCC target surface is not a UUID"))?;
        if id == surface {
            selected.push(row);
        }
    }
    for row in list(&config["workspace_rules"])? {
        let id = canonical_uuid(&row["workspace_id"])
            .ok_or_else(|| anyhow::anyhow!("CCC workspace rule is not a UUID"))?;
        if id == workspace {
            anyhow::ensure!(
                !ids(&row["excluded_surface_ids"])?.contains(&surface),
                "current surface excluded from CCC continuation"
            );
            selected.push(row);
        }
    }
    anyhow::ensure!(
        !ids(&config["discovery_excluded_surface_ids"])?.contains(&surface),
        "current surface excluded from CCC discovery"
    );
    anyhow::ensure!(
        selected
            .iter()
            .all(|row| !vetoes(row, "paused", false) && !vetoes(row, "enabled", true)),
        "current CCC workspace or target paused"
    );
    anyhow::ensure!(
        !vetoes(enrolled, "recovery_enabled", true),
        "original enrolled target recovery disabled"
    );
    Ok(())
}

/// The authority only names evidence; each named file is re-read and checked here.
fn check_authority(
    params: &ThreadCompactInterruptParams,
    intent_path: &Path,
    value: &Value,
    state: &Value,
    authority: &Value,
) -> anyhow::Result<(Value, Vec<Pin>, (Value, Value))> {
    let target = &authority["target"];
    anyhow::ensure!(
        authority["schema"] == AUTHORITY_SCHEMA
            && authority["episode_key"] == params.attempt_id
            && authority["intent_path"].as_str() == intent_path.to_str()
            && authority["session_id"] == params.thread_id
            && authority["compaction_occurrence"] == params.compaction_occurrence,
        "authority is not for this original episode"
    );
    anyhow::ensure!(
        ["workspace_id", "pane_id", "surface_id", "session_id"]
            .iter()
            .all(|field| exact_uuid(&target[*field]))
            && target["session_id"] == params.thread_id,
        "authority target is not an exact UUID binding"
    );
    let process = &target["process"];
    let current = current_process(state)
        .ok_or_else(|| anyhow::anyhow!("no authenticated or original target process"))?;
    anyhow::ensure!(
        process_ok(process)
            && same_process(process, &value["binding"])
            && same_process(process, current),
        "authority process differs from original binding"
    );
    let client = &authority["client"];
    anyhow::ensure!(
        client["pid"] == params.client_pid
            && client["epoch"] == value["client_epoch"]
            && !value["client_epoch"].is_null()
            && client["thread_id"] == params.thread_id
            && client["capability"] == CAPABILITY,
        "authority client differs from original client"
    );
    let foreground = Pin::parse(&authority["foreground"])?;
    let published = foreground.json()?;
    anyhow::ensure!(
        published["schema"] == 1
            && published["purpose"] == "client_foreground_thread"
            && published["pid"] == params.client_pid
            && published["client_epoch"] == value["client_epoch"]
            && published["thread_id"] == params.thread_id
            && published["compact_interrupt_capability"] == CAPABILITY,
        "native foreground publication differs"
    );
    let enrollment = Pin::parse(&authority["enrollment"])?;
    let enrolled = enrollment.json()?;
    let designated: Vec<&Value> = enrolled["targets"]
        .as_array()
        .map(|targets| {
            targets
                .iter()
                .filter(|t| t["session_id"] == params.thread_id)
                .collect()
        })
        .unwrap_or_default();
    anyhow::ensure!(
        // Scope itself is the original explicit user authorization; no invented flag.
        ENROLLMENT_SCOPES.iter().any(|scope| enrolled["scope"] == *scope)
            && designated.len() == 1
            && ["surface_id", "workspace_id", "pane_id"]
                .iter()
                .all(|field| designated[0][*field] == target[*field])
            // Original model/effort come only from the one enrolled target; an absent
            // effort key is never the same as an explicit null effort.
            && ["model", "effort"]
                .iter()
                .all(|field| designated[0].get(*field).is_some_and(|v| target.get(*field) == Some(v)))
            && target["model"].as_str().is_some_and(|model| !model.is_empty())
            && (target["effort"].is_string() || target["effort"].is_null()),
        "original explicit enrollment does not designate this target"
    );
    let config = Pin::parse(&authority["config"])?;
    config_clear(&config.json()?, target, designated[0])?;
    let guard = &authority["input_guard"];
    anyhow::ensure!(
        guard["safe"] == true
            && guard["caught_up"] == true
            && guard["token"] == value["input_token"]
            && value["input_token"].is_string()
            && guard["pending"] == json!([])
            && guard["unknown"] == json!([]),
        "input guard is not the original caught-up empty guard"
    );
    let mut pins = vec![foreground, enrollment, config];
    let inputs = authority["pinned_inputs"]
        .as_array()
        .ok_or_else(|| anyhow::anyhow!("authority has no pinned inputs"))?;
    for input in inputs {
        let pin = Pin::parse(input)?;
        pin.bytes()?;
        pins.push(pin);
    }
    anyhow::ensure!(
        REQUIRED_INPUT_PINS
            .iter()
            .all(|name| pins[3..].iter().any(|pin| pin.name() == Some(*name))),
        "pending-inputs/native-input-intents not pinned"
    );
    Ok((
        process.clone(),
        pins,
        (target["model"].clone(), target["effort"].clone()),
    ))
}

#[cfg(all(test, unix))]
#[path = "compact_original_intent_tests.rs"]
mod tests;
