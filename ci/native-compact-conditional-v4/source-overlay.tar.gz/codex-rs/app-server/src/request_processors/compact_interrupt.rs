//! Two stages use the original CCC episode files, never an independent digest budget.
use super::*;
use codex_app_server_protocol::ThreadCompactInterruptParams;
use codex_app_server_protocol::ThreadCompactInterruptResponse;
use codex_goal_extension::GoalRuntimeHandle;

#[path = "compact_original_intent.rs"]
mod original;

impl ThreadRequestProcessor {
    pub(crate) async fn thread_compact_interrupt(
        &self,
        params: ThreadCompactInterruptParams,
    ) -> Result<Option<ClientResponsePayload>, JSONRPCErrorError> {
        let (thread_id, thread) = self.load_thread(&params.thread_id).await?;
        ensure_direct_input_allowed(thread.as_ref()).await?;
        self.config_manager
            .check_thread_model_provider(thread.config().await.as_ref())
            .await
            .map_err(|error| config_load_error(&error))?;
        let rollout = thread
            .rollout_path()
            .ok_or_else(|| invalid_request("original rollout unavailable"))?;
        let original = original::OriginalIntent::read(&params, &rollout)
            .map_err(|error| invalid_request(format!("original CCC intent rejected: {error}")))?;
        // The same runtime semaphore serializes external Goal edits with recovery.
        // It is held only around Goal read/compare/claim and around the post-join
        // recheck + compact start, never across the interrupt/join await: the joined
        // task's teardown and other Goal writers (stop_active_goal_for_turn,
        // continue_if_idle, external set/clear) take the same Semaphore(1).
        let goal_runtime = thread.thread_extension_data().get::<GoalRuntimeHandle>();
        // Set only after the original claim, when an existing Goal was pinned.
        let mut fence_armed = false;
        // Every exit (UNKNOWN, receipt I/O, permit or recheck error, false) releases this
        // attempt's fence; `finish_join_fence` already emptied it on the accepted path.
        let mut fence_guard = FenceGuard {
            runtime: None,
            turn_id: params.expected_turn_id.clone(),
            attempt_id: params.attempt_id.clone(),
        };
        let Some(db) = thread.state_db() else {
            return Err(invalid_request("Goal authority unavailable"));
        };
        {
            let _goal_guard = match goal_runtime.as_ref() {
                Some(runtime) => Some(runtime.goal_state_permit().await.map_err(|error| {
                    internal_error(format!("Goal boundary unavailable: {error}"))
                })?),
                None => None,
            };
            let goal = db
                .thread_goals()
                .get_thread_goal(thread_id)
                .await
                .map_err(|error| internal_error(format!("Goal read failed: {error}")))?;
            original
                .check_goal(goal.as_ref())
                .map_err(invalid_request)?;
            let settings = thread.thread_settings_snapshot().await;
            original
                .check_settings(&settings.model, settings.reasoning_effort.as_ref())
                .map_err(invalid_request)?;
            original.claim().map_err(|error| {
                invalid_request(format!("original attempt already consumed: {error}"))
            })?;
            if let (Some(runtime), Some(permit), Some(pre)) =
                (goal_runtime.as_ref(), _goal_guard.as_ref(), goal.as_ref())
            {
                runtime
                    .arm_join_fence(
                        permit,
                        &params.expected_turn_id,
                        &params.attempt_id,
                        pre.clone(),
                    )
                    .map_err(|error| {
                        invalid_request(format!("Goal join fence unavailable: {error}"))
                    })?;
                fence_armed = true;
                fence_guard.runtime = Some(runtime.clone());
            }
        }
        let interruption_completed = thread
            .interrupt_compaction_if_no_pending_input(
                &params.expected_turn_id,
                &params.attempt_id,
                &params.compaction_occurrence,
            )
            .await
            .map_err(|error| {
                internal_error(format!("original interrupt outcome UNKNOWN: {error}"))
            })?;
        let mut compact_turn_id = None;
        if interruption_completed {
            original
                .receipt(
                    "interrupted",
                    &serde_json::json!({"turnId": params.expected_turn_id}),
                )
                .map_err(|error| {
                    internal_error(format!("interruption receipt UNKNOWN: {error}"))
                })?;
            // Abort accounting can change status/budget. Never resume a changed Goal.
            // Re-take the permit after join so no Goal writer interleaves between the
            // recheck against the original episode identity and the compact start.
            let _goal_guard = match goal_runtime.as_ref() {
                Some(runtime) => Some(runtime.goal_state_permit().await.map_err(|error| {
                    internal_error(format!("Goal boundary unavailable: {error}"))
                })?),
                None => None,
            };
            let current_goal = db
                .thread_goals()
                .get_thread_goal(thread_id)
                .await
                .map_err(|error| internal_error(format!("Goal recheck failed: {error}")))?;
            // A deterministic denial after the interrupt is recorded once, bound to this
            // original request/turn/attempt; it never claims non-reception. If even that
            // receipt cannot be written (boundary changed, I/O), the outcome is UNKNOWN.
            let deny = |reason: original::DenyReason, detail: String| -> JSONRPCErrorError {
                let reason_text = reason.as_str();
                match original.deny(reason) {
                    Ok(()) => invalid_request(format!("{reason_text}: {detail}")),
                    Err(error) => internal_error(format!(
                        "{reason_text}: {detail}; denial receipt UNKNOWN: {error}"
                    )),
                }
            };
            let join = match (fence_armed, goal_runtime.as_ref(), _goal_guard.as_ref()) {
                (false, _, _) => codex_goal_extension::JoinAccounting::NotAccounted,
                (true, Some(runtime), Some(permit)) => runtime
                    .finish_join_fence(permit, &params.expected_turn_id, &params.attempt_id)
                    .map_err(|error| {
                        deny(original::DenyReason::GoalJoinAccountingRejected, error)
                    })?,
                (true, _, _) => return Err(internal_error("Goal join fence lost its runtime")),
            };
            original
                .check_goal_after_join(
                    current_goal.as_ref(),
                    &join,
                    &params.expected_turn_id,
                    &params.attempt_id,
                )
                .map_err(|error| deny(original::DenyReason::GoalChanged, error))?;
            let settings = thread.thread_settings_snapshot().await;
            original
                .check_settings(&settings.model, settings.reasoning_effort.as_ref())
                .map_err(|error| deny(original::DenyReason::SettingsChanged, error))?;
            // A changed CCC boundary cannot be receipted (receipt revalidates first): UNKNOWN.
            original
                .revalidate()
                .map_err(|error| invalid_request(format!("CCC boundary changed: {error}")))?;
            original.compact_intent().map_err(|error| {
                if error.kind() == std::io::ErrorKind::AlreadyExists {
                    deny(
                        original::DenyReason::CompactBudgetConsumed,
                        error.to_string(),
                    )
                } else {
                    internal_error(format!("original compact intent UNKNOWN: {error}"))
                }
            })?;
            compact_turn_id = thread
                .compact_after_interruption(&params.expected_turn_id, &params.attempt_id)
                .await
                .map_err(|error| {
                    internal_error(format!("original compact outcome UNKNOWN: {error}"))
                })?;
            drop(_goal_guard);
            original
                .receipt(
                    "compact-started",
                    &serde_json::json!({
                        "turnId": compact_turn_id,
                        "joinAccounting": original::OriginalIntent::join_accounting_json(&join),
                    }),
                )
                .map_err(|error| internal_error(format!("compact receipt UNKNOWN: {error}")))?;
        }
        if !interruption_completed {
            // Native proved no interruption (no abort ran, nothing accounted). Record the one
            // terminal outcome of this original attempt so CCC resolves it without replay. A
            // write failure is UNKNOWN (error), never a plain `false` that could permit input.
            original.not_interrupted().map_err(|error| {
                internal_error(format!("not-interrupted receipt UNKNOWN: {error}"))
            })?;
        }
        drop(fence_guard);
        Ok(Some(
            ThreadCompactInterruptResponse {
                attempt_id: params.attempt_id,
                expected_turn_id: params.expected_turn_id,
                interruption_completed,
                compact_turn_id,
            }
            .into(),
        ))
    }
}

/// Releases one attempt's Goal join fence when the request ends without consuming it.
struct FenceGuard {
    runtime: Option<std::sync::Arc<GoalRuntimeHandle>>,
    turn_id: String,
    attempt_id: String,
}

impl Drop for FenceGuard {
    fn drop(&mut self) {
        if let Some(runtime) = self.runtime.as_ref() {
            runtime.abandon_join_fence(&self.turn_id, &self.attempt_id);
        }
    }
}
