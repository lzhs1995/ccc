//! Two stages use the original CCC episode files, never an independent digest budget.
use super::*;
use codex_app_server_protocol::ThreadCompactInterruptParams;
use codex_app_server_protocol::ThreadCompactInterruptResponse;
use codex_goal_extension::GoalRuntimeHandle;

#[path = "compact_original_intent.rs"]
mod original;

impl ThreadRequestProcessor {
    pub(crate) async fn thread_compact_interrupt(
        &self,
        params: ThreadCompactInterruptParams,
    ) -> Result<Option<ClientResponsePayload>, JSONRPCErrorError> {
        let (thread_id, thread) = self.load_thread(&params.thread_id).await?;
        ensure_direct_input_allowed(thread.as_ref()).await?;
        self.config_manager
            .check_thread_model_provider(thread.config().await.as_ref())
            .await
            .map_err(|error| config_load_error(&error))?;
        let rollout = thread
            .rollout_path()
            .ok_or_else(|| invalid_request("original rollout unavailable"))?;
        let original = original::OriginalIntent::read(&params, &rollout)
            .map_err(|error| invalid_request(format!("original CCC intent rejected: {error}")))?;
        // The same runtime semaphore serializes external Goal edits with recovery.
        // It is held only around Goal read/compare/claim and around the post-join
        // recheck + compact start, never across the interrupt/join await: the joined
        // task's teardown and other Goal writers (stop_active_goal_for_turn,
        // continue_if_idle, external set/clear) take the same Semaphore(1).
        let goal_runtime = thread.thread_extension_data().get::<GoalRuntimeHandle>();
        let Some(db) = thread.state_db() else {
            return Err(invalid_request("Goal authority unavailable"));
        };
        {
            let _goal_guard = match goal_runtime.as_ref() {
                Some(runtime) => Some(runtime.goal_state_permit().await.map_err(|error| {
                    internal_error(format!("Goal boundary unavailable: {error}"))
                })?),
                None => None,
            };
            let goal = db
                .thread_goals()
                .get_thread_goal(thread_id)
                .await
                .map_err(|error| internal_error(format!("Goal read failed: {error}")))?;
            original
                .check_goal(goal.as_ref())
                .map_err(invalid_request)?;
            original.claim().map_err(|error| {
                invalid_request(format!("original attempt already consumed: {error}"))
            })?;
        }
        let interruption_completed = thread
            .interrupt_compaction_if_no_pending_input(
                &params.expected_turn_id,
                &params.attempt_id,
                &params.compaction_occurrence,
            )
            .await
            .map_err(|error| {
                internal_error(format!("original interrupt outcome UNKNOWN: {error}"))
            })?;
        let mut compact_turn_id = None;
        if interruption_completed {
            original
                .receipt(
                    "interrupted",
                    &serde_json::json!({"turnId": params.expected_turn_id}),
                )
                .map_err(|error| {
                    internal_error(format!("interruption receipt UNKNOWN: {error}"))
                })?;
            // Abort accounting can change status/budget. Never resume a changed Goal.
            // Re-take the permit after join so no Goal writer interleaves between the
            // recheck against the original episode identity and the compact start.
            let _goal_guard = match goal_runtime.as_ref() {
                Some(runtime) => Some(runtime.goal_state_permit().await.map_err(|error| {
                    internal_error(format!("Goal boundary unavailable: {error}"))
                })?),
                None => None,
            };
            let current_goal = db
                .thread_goals()
                .get_thread_goal(thread_id)
                .await
                .map_err(|error| internal_error(format!("Goal recheck failed: {error}")))?;
            original
                .check_goal(current_goal.as_ref())
                .map_err(invalid_request)?;
            original
                .revalidate()
                .map_err(|error| invalid_request(format!("CCC boundary changed: {error}")))?;
            original.compact_intent().map_err(|error| {
                invalid_request(format!("original compact budget consumed: {error}"))
            })?;
            compact_turn_id = thread
                .compact_after_interruption(&params.expected_turn_id, &params.attempt_id)
                .await
                .map_err(|error| {
                    internal_error(format!("original compact outcome UNKNOWN: {error}"))
                })?;
            drop(_goal_guard);
            original
                .receipt(
                    "compact-started",
                    &serde_json::json!({"turnId": compact_turn_id}),
                )
                .map_err(|error| internal_error(format!("compact receipt UNKNOWN: {error}")))?;
        }
        Ok(Some(
            ThreadCompactInterruptResponse {
                attempt_id: params.attempt_id,
                expected_turn_id: params.expected_turn_id,
                interruption_completed,
                compact_turn_id,
            }
            .into(),
        ))
    }
}
