//! Gate: real core Session + installed real Goal + a Notify-paused BeforeTaskRegistration
//! contributor, driven only through public CodexThread host paths and real events.
//!
//! Order under test (handlers.rs inline ops): an ordinary `start_or_steer_turn` submitted
//! while the committed compact's contributors are paused waits in `rx_sub` until the
//! compact op returns. It then meets the running compact task, which `steer_input` refuses
//! (`ActiveTurnNotSteerable{Compact}`), or a finished one. The test accepts only those two
//! truthful outcomes and proves the ordinary content then runs exactly once in its own
//! regular turn with its settings, start options and metadata intact.
use std::sync::Arc;
use std::sync::Mutex;
use std::sync::Weak;
use std::sync::atomic::AtomicBool;
use std::sync::atomic::AtomicUsize;
use std::sync::atomic::Ordering;
use std::time::Duration;

use codex_core::NotSubmittedReason;
use codex_core::TurnInputRequest;
use codex_core::TurnInputSubmission;
use codex_core::TurnStartOptions;
use codex_core::config::Config;
use codex_extension_api::ExtensionFuture;
use codex_extension_api::ExtensionRegistryBuilder;
use codex_extension_api::TurnLifecycleContributor;
use codex_extension_api::TurnStartInput;
use codex_goal_extension::GoalExtensionConfig;
use codex_goal_extension::GoalObjectiveUpdate;
use codex_goal_extension::GoalService;
use codex_goal_extension::GoalSetRequest;
use codex_goal_extension::GoalTokenBudgetUpdate;
use codex_protocol::items::TurnItem;
use codex_protocol::openai_models::ReasoningEffort;
use codex_protocol::protocol::EventMsg;
use codex_protocol::protocol::ItemStartedEvent;
use codex_protocol::protocol::NonSteerableTurnKind;
use codex_protocol::protocol::Op;
use codex_protocol::protocol::ThreadSettingsOverrides;
use codex_protocol::user_input::UserInput;
use core_test_support::responses::ev_assistant_message;
use core_test_support::responses::ev_completed_with_tokens;
use core_test_support::responses::ev_response_created;
use core_test_support::responses::sse;
use core_test_support::responses::sse_response;
use core_test_support::responses::start_mock_server;
use core_test_support::test_codex::test_codex;
use tokio::sync::Notify;
use wiremock::Mock;
use wiremock::Request;
use wiremock::Respond;
use wiremock::ResponseTemplate;
use wiremock::matchers::method;
use wiremock::matchers::path_regex;

/// Pauses the first BeforeTaskRegistration start after it is armed and records its turn id.
#[derive(Default)]
struct PauseNextStart {
    armed: Mutex<bool>,
    paused_turn: Mutex<Option<String>>,
    reached: Notify,
    release: Notify,
}

impl TurnLifecycleContributor for PauseNextStart {
    fn on_turn_start<'a>(&'a self, input: TurnStartInput<'a>) -> ExtensionFuture<'a, ()> {
        Box::pin(async move {
            let take = std::mem::take(&mut *self.armed.lock().unwrap());
            if take {
                *self.paused_turn.lock().unwrap() = Some(input.turn_id.to_string());
                self.reached.notify_one();
                self.release.notified().await;
            }
        })
    }
}

/// Content-routed model: the ordinary request (identified by its own text) gets a fixed,
/// known token usage; other requests are scripted. The first is the first turn. While
/// `hold` is set every later one is the original manual compact and is held past the
/// 301 s wait; that includes its single CompactionDeadline timeout retry (compact.rs),
/// which is armed before the ItemStarted that starts the 300 s interruption gate. The test
/// clears `hold` only after the interruption is accepted, so the conditional compact
/// answers at once.
struct Script {
    others: AtomicUsize,
    hold: Arc<AtomicBool>,
}

const HELD_COMPACT_DELAY: Duration = Duration::from_secs(420);
const INTERRUPTION_GATE_WAIT: Duration = Duration::from_secs(301);
const TEST_STREAM_IDLE_TIMEOUT_MS: u64 = 600_000;

const ORDINARY_TEXT: &str = "ordinary-A";
const ORDINARY_TOKENS: i64 = 777;
const SCHEMA_MARKER: &str = "native_compact_goal_f1_schema_marker";
const METADATA_MARKER: &str = "native-compact-goal-f1-metadata";

impl Respond for Script {
    fn respond(&self, request: &Request) -> ResponseTemplate {
        let body = |id: &str, text: &str, tokens: i64| {
            sse(vec![
                ev_response_created(id),
                ev_assistant_message(&format!("{id}-msg"), text),
                ev_completed_with_tokens(id, tokens),
            ])
        };
        if String::from_utf8_lossy(&request.body).contains(ORDINARY_TEXT) {
            return sse_response(body("ordinary", "ordinary reply", ORDINARY_TOKENS));
        }
        let n = self.others.fetch_add(1, Ordering::SeqCst);
        if n == 0 {
            return sse_response(body("r0", "first turn done", 100));
        }
        if self.hold.load(Ordering::SeqCst) {
            return sse_response(body(&format!("r{n}"), "held compact summary", 120))
                .set_delay(HELD_COMPACT_DELAY);
        }
        sse_response(body(&format!("r{n}"), &format!("reply-{n}"), 140))
    }
}

/// The exact ordinary request: content, explicit thread settings, start options whose
/// effect is visible in the request body, and Responses metadata.
fn ordinary_request() -> TurnInputRequest {
    let mut metadata = std::collections::HashMap::new();
    metadata.insert("gate".to_string(), METADATA_MARKER.to_string());
    TurnInputRequest::user_input(vec![UserInput::Text {
        text: ORDINARY_TEXT.into(),
        text_elements: Vec::new(),
    }])
    .with_thread_settings(ThreadSettingsOverrides {
        effort: Some(Some(ReasoningEffort::High)),
        ..Default::default()
    })
    .on_start(TurnStartOptions {
        turn_trigger: Some("native-compact-goal-f1".to_string()),
        final_output_json_schema: Some(serde_json::json!({
            "type": "object",
            "properties": { "native_compact_goal_f1_schema_marker": { "type": "string" } },
            "required": [SCHEMA_MARKER],
            "additionalProperties": false
        })),
        ..Default::default()
    })
    .with_responses_metadata(Some(metadata))
}

async fn next_matching(
    codex: &codex_core::CodexThread,
    mut seen: impl FnMut(&EventMsg) -> bool,
    log: &mut Vec<EventMsg>,
) -> EventMsg {
    loop {
        let event = tokio::time::timeout(Duration::from_secs(30), codex.next_event())
            .await
            .expect("event within 30 s")
            .expect("event stream open");
        log.push(event.msg.clone());
        if seen(&event.msg) {
            return event.msg;
        }
    }
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn ordinary_input_during_committed_compact_is_truthful_and_keeps_real_goal_accounting()
-> anyhow::Result<()> {
    let server = start_mock_server().await;
    let hold = Arc::new(AtomicBool::new(true));
    Mock::given(method("POST"))
        .and(path_regex(".*/responses$"))
        .respond_with(Script {
            others: AtomicUsize::new(0),
            hold: Arc::clone(&hold),
        })
        .mount(&server)
        .await;
    // Real Goal on the thread's own state backend: the same codex home, opened through
    // the same `init_state_db` the TestCodex runtime calls (test_codex.rs:784).
    let home = Arc::new(tempfile::TempDir::new()?);
    let base_config = core_test_support::load_default_config_for_test(&home).await;
    let state_db = codex_core::init_state_db(&base_config)
        .await
        .ok_or_else(|| anyhow::anyhow!("state db unavailable for the test home"))?;
    let goal_service = Arc::new(GoalService::new());
    let pause = Arc::new(PauseNextStart::default());
    let mut builder = ExtensionRegistryBuilder::<Config>::new();
    codex_goal_extension::install_with_backend(
        &mut builder,
        state_db.clone(),
        codex_analytics::AnalyticsEventsClient::disabled(),
        /*metrics_client*/ None,
        Weak::new(),
        Arc::clone(&goal_service),
        |_: &Config| GoalExtensionConfig {
            enabled: true,
            max_goal_token_budget: None,
        },
    );
    builder.turn_lifecycle_contributor(pause.clone());
    // TestCodexBuilder inherits built_in["openai"] (test_codex.rs prepare_config), and
    // is_openai() selects RemoteCompactionSupport::V2 (model-provider provider.rs). Use the
    // local compact path this scripted /responses mock serves: a non-OpenAI provider name
    // (same pattern as core suite compact.rs non_openai_model_provider) and no TokenBudget
    // manual compaction (tasks/compact.rs run).
    let test = test_codex()
        .with_config(|config| {
            config.model_provider.name = "OpenAI (native compact gate)".into();
            // Test provider only: the default 300 s stream idle timeout must not end the
            // held compact stream before the 301 s gate wait.
            config.model_provider.stream_idle_timeout_ms = Some(TEST_STREAM_IDLE_TIMEOUT_MS);
            config
                .features
                .disable(codex_features::Feature::TokenBudget)
                .expect("disable token budget");
        })
        .with_home(Arc::clone(&home))
        .with_extensions(Arc::new(builder.build()))
        .build(&server)
        .await?;
    let codex = Arc::clone(&test.codex);
    let thread_id = test.session_configured.thread_id;
    assert!(
        !test.config.model_provider.is_openai(),
        "local compaction path selected"
    );
    // Shared backend, not a second store: the thread's handle sees our Goal write.
    let thread_db = codex
        .state_db()
        .ok_or_else(|| anyhow::anyhow!("thread has no state db"))?;
    goal_service
        .set_thread_goal(
            state_db.as_ref(),
            GoalSetRequest {
                thread_id,
                objective: GoalObjectiveUpdate::Set("native compact gate"),
                status: Some(codex_protocol::protocol::ThreadGoalStatus::Active),
                token_budget: GoalTokenBudgetUpdate::Set(None),
                max_goal_token_budget: None,
            },
        )
        .await
        .map_err(|error| anyhow::anyhow!("{error:?}"))?;
    let pinned = thread_db
        .thread_goals()
        .get_thread_goal(thread_id)
        .await?
        .ok_or_else(|| anyhow::anyhow!("goal not visible through the thread's state db"))?;

    let mut log = Vec::new();
    codex
        .start_or_steer_turn(TurnInputRequest::user_input(vec![UserInput::Text {
            text: "first".into(),
            text_elements: Vec::new(),
        }]))
        .await?;
    next_matching(&codex, |e| matches!(e, EventMsg::TurnComplete(_)), &mut log).await;

    // Original manual compact, held in flight while `hold` is set.
    let compact_turn = codex.submit(Op::Compact).await?;
    let EventMsg::ItemStarted(ItemStartedEvent {
        item: TurnItem::ContextCompaction(item),
        ..
    }) = next_matching(
        &codex,
        |e| {
            matches!(
                e,
                EventMsg::ItemStarted(ItemStartedEvent {
                    item: TurnItem::ContextCompaction(_),
                    ..
                })
            )
        },
        &mut log,
    )
    .await
    else {
        unreachable!("matched above");
    };
    let attempt = "0123456789abcdef01234567";
    // Zero control: inside the native 300 s minimum (extension_interruption.rs
    // while_compacting_for, std Instant) the same request must be refused.
    assert!(
        !codex
            .interrupt_compaction_if_no_pending_input(&compact_turn, attempt, &item.id)
            .await?,
        "native must refuse to interrupt a compaction younger than 300 s"
    );
    // Real wall-clock wait past the gate; the held original compact (and its single
    // deadline retry) is still outstanding.
    tokio::time::sleep(INTERRUPTION_GATE_WAIT).await;
    assert!(
        codex
            .interrupt_compaction_if_no_pending_input(&compact_turn, attempt, &item.id)
            .await?,
        "native must interrupt the original in-flight compaction"
    );
    // The original task is joined: nothing held is still sending. Later compacts answer.
    hold.store(false, Ordering::SeqCst);

    // Conditional compact: its BeforeTaskRegistration contributors pause on the Notify.
    *pause.armed.lock().unwrap() = true;
    let compacting = {
        let codex = Arc::clone(&codex);
        let turn = compact_turn.clone();
        tokio::spawn(async move { codex.compact_after_interruption(&turn, attempt).await })
    };
    tokio::time::timeout(Duration::from_secs(30), pause.reached.notified()).await?;
    let paused_turn = pause
        .paused_turn
        .lock()
        .unwrap()
        .clone()
        .expect("paused turn id");

    // Baseline while the conditional compact is paused (no ordinary work has run yet).
    let baseline = thread_db
        .thread_goals()
        .get_thread_goal(thread_id)
        .await?
        .expect("goal");

    // Ordinary input submitted during the committed preparation, through the real loop.
    let ordinary = {
        let codex = Arc::clone(&codex);
        tokio::spawn(async move { codex.start_or_steer_turn(ordinary_request()).await })
    };
    pause.release.notify_one();
    let started = tokio::time::timeout(Duration::from_secs(30), compacting).await???;
    assert_eq!(
        started.as_deref(),
        Some(paused_turn.as_str()),
        "committed compact installs"
    );
    let first = tokio::time::timeout(Duration::from_secs(30), ordinary).await???;

    // Truthful result. The loop handles the input only after the compact op returns
    // (handlers.rs inline order), so it meets either the running compact task, which
    // `steer_input` refuses (turn_input.rs: TaskKind::Compact => ActiveTurnNotSteerable),
    // or an already finished compact. It must never be Steered into the compact.
    let ordinary_turn = match first {
        TurnInputSubmission::Started { turn_id } => turn_id,
        TurnInputSubmission::NotSubmitted {
            reason:
                NotSubmittedReason::ActiveTurnNotSteerable {
                    turn_kind: NonSteerableTurnKind::Compact,
                },
        } => {
            // Refused, not stranded: nothing reached the model and nothing was applied.
            let requests = server.received_requests().await.unwrap_or_default();
            assert!(
                !requests
                    .iter()
                    .any(|r| String::from_utf8_lossy(&r.body).contains(ORDINARY_TEXT))
            );
            assert_ne!(
                Some(ReasoningEffort::High),
                codex.thread_settings_snapshot().await.reasoning_effort
            );
            next_matching(
                &codex,
                |e| matches!(e, EventMsg::TurnComplete(c) if c.turn_id == paused_turn),
                &mut log,
            )
            .await;
            match codex.start_or_steer_turn(ordinary_request()).await? {
                TurnInputSubmission::Started { turn_id } => turn_id,
                other => anyhow::bail!("resubmitted ordinary input after compact: {other:?}"),
            }
        }
        other => anyhow::bail!("ordinary input during committed compact: {other:?}"),
    };
    assert_ne!(
        ordinary_turn, paused_turn,
        "ordinary content runs in its own regular turn"
    );
    next_matching(
        &codex,
        |e| matches!(e, EventMsg::TurnComplete(c) if c.turn_id == ordinary_turn),
        &mut log,
    )
    .await;

    // Lifecycle balance from real events.
    let aborted = |turn: &str| {
        log.iter()
            .filter(|e| matches!(e, EventMsg::TurnAborted(a) if a.turn_id.as_deref() == Some(turn)))
            .count()
    };
    let started_count = |turn: &str| {
        log.iter()
            .filter(|e| matches!(e, EventMsg::TurnStarted(s) if s.turn_id == turn))
            .count()
    };
    assert_eq!(
        1,
        aborted(&compact_turn),
        "original compact aborted exactly once"
    );
    assert_eq!(
        0,
        aborted(&paused_turn),
        "committed compact was not replaced"
    );
    assert_eq!(
        1,
        started_count(&paused_turn),
        "conditional compact started once"
    );
    assert_eq!(
        (1, 0),
        (started_count(&ordinary_turn), aborted(&ordinary_turn)),
        "ordinary turn ran once"
    );

    // Exact content once, with its start options and Responses metadata, in the request body.
    let requests = server.received_requests().await.unwrap_or_default();
    let ordinary_bodies: Vec<String> = requests
        .iter()
        .map(|r| String::from_utf8_lossy(&r.body).into_owned())
        .filter(|body| body.contains(ORDINARY_TEXT))
        .collect();
    assert_eq!(
        1,
        ordinary_bodies.len(),
        "ordinary content sampled exactly once"
    );
    assert!(
        ordinary_bodies[0].contains(SCHEMA_MARKER),
        "final_output_json_schema from on_start"
    );
    assert!(
        ordinary_bodies[0].contains(METADATA_MARKER),
        "Responses client metadata"
    );
    // Explicit thread settings were applied by the accepted request.
    assert_eq!(
        Some(ReasoningEffort::High),
        codex.thread_settings_snapshot().await.reasoning_effort
    );

    // Real Goal: same active goal; the ordinary turn's known usage is accounted. The only
    // other response after the baseline is the conditional compact's (140 tokens).
    let goal = thread_db
        .thread_goals()
        .get_thread_goal(thread_id)
        .await?
        .expect("goal");
    assert_eq!(
        (goal.goal_id.as_str(), goal.status),
        (
            pinned.goal_id.as_str(),
            codex_state::ThreadGoalStatus::Active
        )
    );
    let delta = goal.tokens_used - baseline.tokens_used;
    assert!(
        (ORDINARY_TOKENS..=ORDINARY_TOKENS + 140).contains(&delta),
        "goal token delta {delta}"
    );
    Ok(())
}
