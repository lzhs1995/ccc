use super::*;
use crate::session::tests::HeldStepTask;
use crate::session::tests::make_session_and_context_with_rx;
use crate::state::TaskKind;
use codex_protocol::protocol::TurnAbortReason;
use pretty_assertions::assert_eq;
use tokio::sync::Notify;

#[tokio::test]
async fn joined_receipt_is_not_retargetable_or_reusable() {
    let (session, _context, _events) = make_session_and_context_with_rx().await;
    session
        .services
        .thread_extension_data
        .insert(JoinedCompaction {
            turn_id: "original".into(),
            attempt_id: "original-attempt".into(),
            activity: session.input_queue.subscribe_activity(None).await.0,
        });
    let (_tx, rx) = async_channel::bounded(4);
    assert!(
        !session
            .compact_after_interruption("new-turn", "original-attempt", &rx, "compact".into())
            .await
    );
    assert!(
        session
            .services
            .thread_extension_data
            .get::<JoinedCompaction>()
            .is_none()
    );
    assert!(
        !session
            .compact_after_interruption("original", "original-attempt", &rx, "compact".into())
            .await
    );
}

#[tokio::test]
async fn reserved_compact_installs_only_original_idle_reservation() {
    let (session, context, _events) = make_session_and_context_with_rx().await;
    let (_tx, rx) = async_channel::bounded(4);
    session.state.lock().await.last_started_turn_id = Some("original".into());
    let condition = reserve_original(&session, rx).await;
    assert!(
        session
            .start_reserved_compact(
                Arc::clone(&context),
                HeldStepTask {
                    kind: TaskKind::Compact,
                    finish: Arc::new(Notify::new()),
                },
                condition
            )
            .await
    );
    assert_eq!(
        session
            .active_turn
            .lock()
            .await
            .as_ref()
            .unwrap()
            .task
            .as_ref()
            .unwrap()
            .kind,
        TaskKind::Compact
    );
    session.abort_all_tasks(TurnAbortReason::Interrupted).await;
}

#[tokio::test]
async fn replacement_reservation_is_never_overwritten() {
    let (session, context, _events) = make_session_and_context_with_rx().await;
    let (_tx, rx) = async_channel::bounded(4);
    session.state.lock().await.last_started_turn_id = Some("original".into());
    let condition = reserve_original(&session, rx).await;
    let replacement = ActiveTurn::default();
    let replacement_state = Arc::clone(&replacement.turn_state);
    *session.active_turn.lock().await = Some(replacement);
    assert!(
        !session
            .start_reserved_compact(
                context,
                HeldStepTask {
                    kind: TaskKind::Compact,
                    finish: Arc::new(Notify::new()),
                },
                condition
            )
            .await
    );
    let active = session.active_turn.lock().await;
    assert!(Arc::ptr_eq(
        &active.as_ref().unwrap().turn_state,
        &replacement_state
    ));
    assert!(active.as_ref().unwrap().task.is_none());
}

use crate::session::InputQueueActivity;
use crate::session::TurnInput;
use crate::session::turn_context::TurnContext;
use crate::tasks::SessionTask;
use crate::tasks::SessionTaskResult;
use codex_extension_api::ExtensionFuture;
use codex_extension_api::ExtensionRegistryBuilder;
use codex_extension_api::TurnAbortInput;
use codex_extension_api::TurnLifecycleContributor;
use codex_extension_api::TurnStartInput;
use codex_protocol::user_input::UserInput;
use std::sync::atomic::AtomicUsize;
use tokio_util::sync::CancellationToken;

/// Reserves the original attempt's slot through the production constructor.
async fn reserve_original(
    session: &Arc<Session>,
    submissions: async_channel::Receiver<Submission>,
) -> CompactReservation {
    let joined = Arc::new(JoinedCompaction {
        turn_id: "original".into(),
        attempt_id: "attempt".into(),
        activity: session.input_queue.subscribe_activity(None).await.0,
    });
    let mut active = session.active_turn.lock().await;
    CompactReservation::reserve(&mut active, joined, submissions)
}

/// Records turn starts/aborts; optionally pauses the named turn's start (deterministic barrier).
struct Recorder {
    starts: Arc<std::sync::Mutex<Vec<String>>>,
    aborts: Arc<AtomicUsize>,
    pause_turn: Option<String>,
    entered: Arc<Notify>,
    release: Arc<Notify>,
}

impl TurnLifecycleContributor for Recorder {
    fn on_turn_start<'a>(&'a self, input: TurnStartInput<'a>) -> ExtensionFuture<'a, ()> {
        Box::pin(async move {
            self.starts
                .lock()
                .expect("starts")
                .push(input.turn_id.to_string());
            if self.pause_turn.as_deref() == Some(input.turn_id) {
                self.entered.notify_one();
                self.release.notified().await;
            }
        })
    }

    fn on_turn_abort<'a>(&'a self, _input: TurnAbortInput<'a>) -> ExtensionFuture<'a, ()> {
        Box::pin(async move {
            self.aborts.fetch_add(1, Ordering::SeqCst);
        })
    }
}

struct Harness {
    session: Arc<Session>,
    starts: Arc<std::sync::Mutex<Vec<String>>>,
    aborts: Arc<AtomicUsize>,
    entered: Arc<Notify>,
    release: Arc<Notify>,
}

async fn harness(pause_turn: Option<&str>) -> Harness {
    let (mut session, _context) = crate::session::tests::make_session_and_context().await;
    let starts = Arc::new(std::sync::Mutex::new(Vec::new()));
    let aborts = Arc::new(AtomicUsize::new(0));
    let entered = Arc::new(Notify::new());
    let release = Arc::new(Notify::new());
    let mut builder = ExtensionRegistryBuilder::<crate::config::Config>::new();
    builder.turn_lifecycle_contributor(Arc::new(Recorder {
        starts: Arc::clone(&starts),
        aborts: Arc::clone(&aborts),
        pause_turn: pause_turn.map(str::to_string),
        entered: Arc::clone(&entered),
        release: Arc::clone(&release),
    }));
    session.services.extensions = Arc::new(builder.build());
    session.state.lock().await.last_started_turn_id = Some("original".into());
    Harness {
        session: Arc::new(session),
        starts,
        aborts,
        entered,
        release,
    }
}

impl Harness {
    async fn turn(&self, sub_id: &str) -> Arc<TurnContext> {
        self.session
            .new_turn_with_default_settings(sub_id.into(), Default::default())
            .await
    }
    fn starts(&self) -> Vec<String> {
        self.starts.lock().expect("starts").clone()
    }
}

fn held_compact() -> HeldStepTask {
    HeldStepTask {
        kind: TaskKind::Compact,
        finish: Arc::new(Notify::new()),
    }
}

fn user_text(text: &str) -> TurnInput {
    TurnInput::UserInput {
        content: vec![UserInput::Text {
            text: text.into(),
            text_elements: Vec::new(),
        }],
        client_id: None,
        metadata: Default::default(),
    }
}

/// Regular task that records the input it actually ran with.
struct RecordingTask {
    seen: Arc<std::sync::Mutex<Vec<Vec<TurnInput>>>>,
    ran: Arc<Notify>,
}

impl SessionTask for RecordingTask {
    fn kind(&self) -> TaskKind {
        TaskKind::Regular
    }

    fn span_name(&self) -> &'static str {
        "session_task.compact_recovery_recording_test"
    }

    async fn run(
        self: Arc<Self>,
        _session: Arc<Session>,
        _turn: Arc<TurnContext>,
        input: Vec<TurnInput>,
        cancellation_token: CancellationToken,
    ) -> SessionTaskResult {
        self.seen.lock().expect("seen").push(input);
        self.ran.notify_one();
        cancellation_token.cancelled().await;
        Ok(None)
    }
}
// (a) spawn_task vs an UNCOMMITTED slot: newer ordinary work wins, compact has zero side effects.
#[tokio::test]
async fn spawn_task_replaces_uncommitted_slot_with_zero_compact_side_effects() {
    let h = harness(None).await;
    let (_tx, rx) = async_channel::bounded(4);
    let condition = reserve_original(&h.session, rx).await;
    let reserved_state = Arc::clone(&condition.turn_state);
    h.session
        .spawn_task(
            h.turn("regular-1").await,
            vec![user_text("hello")],
            HeldStepTask {
                kind: TaskKind::Regular,
                finish: Arc::new(Notify::new()),
            },
        )
        .await;
    assert!(
        !h.session
            .start_reserved_compact(h.turn("compact-1").await, held_compact(), condition)
            .await
    );
    assert_eq!(
        h.starts(),
        vec!["regular-1".to_string()],
        "compact contributor never ran"
    );
    assert_eq!(
        h.aborts.load(Ordering::SeqCst),
        0,
        "uncommitted denial needs no abort"
    );
    {
        let active = h.session.active_turn.lock().await;
        let turn = active.as_ref().unwrap();
        assert!(
            !Arc::ptr_eq(&turn.turn_state, &reserved_state) && turn.compact_reservation.is_none()
        );
        assert_eq!(turn.task.as_ref().unwrap().kind, TaskKind::Regular);
    }
    assert_eq!(
        h.session.state.lock().await.last_started_turn_id.as_deref(),
        Some("regular-1")
    );
    h.session
        .abort_all_tasks(TurnAbortReason::Interrupted)
        .await;
}

/// Mirrors Goal's thread-scoped bookkeeping (ext/goal extension.rs:242-252, :367-394): start
/// awaits (the DB call) and then overwrites current/options; abort removes options
/// unconditionally and clears current only if it names the aborted turn. Test simplification:
/// the aborted turn is the oldest started-not-aborted one.
struct GoalLike {
    events: Arc<std::sync::Mutex<Vec<String>>>,
    open: Arc<std::sync::Mutex<Vec<String>>>,
    current: Arc<std::sync::Mutex<Option<String>>>,
    options: Arc<std::sync::Mutex<Option<String>>>,
    pause_turn: Option<String>,
    entered: Arc<Notify>,
    release: Arc<Notify>,
}

impl TurnLifecycleContributor for GoalLike {
    fn on_turn_start<'a>(&'a self, input: TurnStartInput<'a>) -> ExtensionFuture<'a, ()> {
        Box::pin(async move {
            let id = input.turn_id.to_string();
            self.events
                .lock()
                .expect("events")
                .push(format!("start:{id}"));
            self.open.lock().expect("open").push(id.clone());
            if self.pause_turn.as_deref() == Some(id.as_str()) {
                self.entered.notify_one();
                self.release.notified().await;
            }
            *self.current.lock().expect("current") = Some(id.clone());
            *self.options.lock().expect("options") = Some(id);
        })
    }

    fn on_turn_abort<'a>(&'a self, _input: TurnAbortInput<'a>) -> ExtensionFuture<'a, ()> {
        Box::pin(async move {
            let id = self.open.lock().expect("open").remove(0);
            self.events
                .lock()
                .expect("events")
                .push(format!("abort:{id}"));
            *self.options.lock().expect("options") = None;
            let mut current = self.current.lock().expect("current");
            if current.as_deref() == Some(id.as_str()) {
                *current = None;
            }
        })
    }
}

struct GoalHarness {
    session: Arc<Session>,
    goal: Arc<GoalLike>,
}

async fn goal_harness(pause_turn: &str) -> GoalHarness {
    let (mut session, _context) = crate::session::tests::make_session_and_context().await;
    let goal = Arc::new(GoalLike {
        events: Arc::default(),
        open: Arc::default(),
        current: Arc::default(),
        options: Arc::default(),
        pause_turn: Some(pause_turn.to_string()),
        entered: Arc::new(Notify::new()),
        release: Arc::new(Notify::new()),
    });
    let mut builder = ExtensionRegistryBuilder::<crate::config::Config>::new();
    builder.turn_lifecycle_contributor(Arc::clone(&goal) as Arc<dyn TurnLifecycleContributor>);
    session.services.extensions = Arc::new(builder.build());
    session.state.lock().await.last_started_turn_id = Some("original".into());
    GoalHarness {
        session: Arc::new(session),
        goal,
    }
}

impl GoalHarness {
    async fn turn(&self, sub_id: &str) -> Arc<TurnContext> {
        self.session
            .new_turn_with_default_settings(sub_id.into(), Default::default())
            .await
    }
    fn events(&self) -> Vec<String> {
        self.goal.events.lock().expect("events").clone()
    }
    fn current(&self) -> Option<String> {
        self.goal.current.lock().expect("current").clone()
    }
    fn options(&self) -> Option<String> {
        self.goal.options.lock().expect("options").clone()
    }
}

/// Runs A's F1 interleaving (optionally with an explicit Interrupted first) through the real
/// start_reserved_compact / spawn_task / abort_all_tasks. Frozen v4 records
/// [start:compact-1, start:regular-1, abort:compact-1] and leaves current/options = None.
async fn run_f1(interrupt_first: bool) {
    let g = goal_harness("compact-1").await;
    let (_tx, rx) = async_channel::bounded(4);
    let condition = reserve_original(&g.session, rx).await;
    let seen = Arc::new(std::sync::Mutex::new(Vec::new()));
    let ran = Arc::new(Notify::new());
    let compact = g.turn("compact-1").await;
    let regular = g.turn("regular-1").await;
    let (installed, ()) = tokio::join!(
        g.session
            .start_reserved_compact(compact, held_compact(), condition),
        async {
            g.goal.entered.notified().await; // committed; Goal-like start paused before start_turn
            if interrupt_first {
                g.session
                    .abort_all_tasks(TurnAbortReason::Interrupted)
                    .await;
            }
            g.session
                .spawn_task(
                    regular,
                    vec![user_text("queued")],
                    RecordingTask {
                        seen: Arc::clone(&seen),
                        ran: Arc::clone(&ran),
                    },
                )
                .await;
            g.goal.release.notify_one();
        }
    );
    assert!(!installed, "compact yields; it never runs");
    ran.notified().await;
    let seen = seen.lock().expect("seen").clone();
    assert_eq!(seen.len(), 1, "the ordinary task runs exactly once");
    assert!(
        matches!(&seen[0][..], [TurnInput::UserInput { content, .. }]
        if matches!(&content[..], [UserInput::Text { text, .. }] if text == "queued"))
    );
    assert_eq!(
        g.events(),
        vec!["start:compact-1", "abort:compact-1", "start:regular-1"],
        "no overlap"
    );
    assert_eq!(
        g.current(),
        Some("regular-1".to_string()),
        "regular Goal current_turn_id intact"
    );
    assert_eq!(
        g.options(),
        Some("regular-1".to_string()),
        "regular TurnStartOptions intact"
    );
    {
        let active = g.session.active_turn.lock().await;
        let turn = active.as_ref().expect("regular slot");
        assert!(turn.compact_reservation.is_none());
        assert_eq!(turn.task.as_ref().expect("task").kind, TaskKind::Regular);
    }
    assert_eq!(
        g.session.state.lock().await.last_started_turn_id.as_deref(),
        Some("regular-1")
    );
    g.session
        .abort_all_tasks(TurnAbortReason::Interrupted)
        .await;
}

#[tokio::test]
async fn a_f1_spawn_during_committed_preparation_keeps_regular_goal_state() {
    run_f1(false).await;
}

#[tokio::test]
async fn explicit_abort_then_spawn_during_committed_preparation_does_not_overlap() {
    run_f1(true).await;
}

// (a)+(c) spawn_task vs a COMMITTED slot while its contributor is paused: the ordinary start is
// deferred (not stealing the marker); compact yields with one balancing abort, then the queued
// user input becomes exactly one regular turn.
#[tokio::test]
async fn spawn_task_defers_behind_committed_preparation_and_runs_user_input_once() {
    let h = harness(Some("compact-1")).await;
    let (_tx, rx) = async_channel::bounded(4);
    let condition = reserve_original(&h.session, rx).await;
    let seen = Arc::new(std::sync::Mutex::new(Vec::new()));
    let ran = Arc::new(Notify::new());
    let compact = h.turn("compact-1").await;
    let regular = h.turn("regular-1").await;
    let (installed, ()) = tokio::join!(
        h.session
            .start_reserved_compact(compact, held_compact(), condition),
        async {
            h.entered.notified().await; // compact committed; its contributor is paused, no lock held
            h.session
                .spawn_task(
                    regular,
                    vec![user_text("queued")],
                    RecordingTask {
                        seen: Arc::clone(&seen),
                        ran: Arc::clone(&ran),
                    },
                )
                .await;
            h.release.notify_one();
        }
    );
    assert!(!installed, "cancelled preparation is not installed");
    ran.notified().await;
    let seen = seen.lock().expect("seen").clone();
    assert_eq!(seen.len(), 1, "exactly one regular turn ran");
    assert!(
        matches!(&seen[0][..], [TurnInput::UserInput { content, .. }]
        if matches!(&content[..], [UserInput::Text { text, .. }] if text == "queued"))
    );
    assert_eq!(
        h.starts(),
        vec!["compact-1".to_string(), "regular-1".to_string()]
    );
    assert_eq!(
        h.aborts.load(Ordering::SeqCst),
        1,
        "one start of compact-1 balanced by one abort"
    );
    assert_eq!(
        h.session
            .active_turn
            .lock()
            .await
            .as_ref()
            .unwrap()
            .task
            .as_ref()
            .unwrap()
            .kind,
        TaskKind::Regular
    );
    h.session
        .abort_all_tasks(TurnAbortReason::Interrupted)
        .await;
}

// (b) contributor paused, then a plain cancel: start/abort balanced, slot gone, no task installed.
#[tokio::test]
async fn cancel_during_paused_contributor_balances_start_and_abort() {
    let h = harness(Some("compact-1")).await;
    let (_tx, rx) = async_channel::bounded(4);
    let condition = reserve_original(&h.session, rx).await;
    let compact = h.turn("compact-1").await;
    let (installed, ()) = tokio::join!(
        h.session
            .start_reserved_compact(compact, held_compact(), condition),
        async {
            h.entered.notified().await;
            h.session
                .abort_all_tasks(TurnAbortReason::Interrupted)
                .await;
            h.release.notify_one();
        }
    );
    assert!(!installed);
    assert_eq!(h.starts(), vec!["compact-1".to_string()]);
    assert_eq!(h.aborts.load(Ordering::SeqCst), 1);
    assert!(h.session.active_turn.lock().await.is_none());
}

// accepted path: contributor once, marker consumed, no abort.
#[tokio::test]
async fn accepted_reserved_compact_runs_contributor_once_and_consumes_marker() {
    let h = harness(None).await;
    let (_tx, rx) = async_channel::bounded(4);
    let condition = reserve_original(&h.session, rx).await;
    assert!(
        h.session
            .start_reserved_compact(h.turn("compact-1").await, held_compact(), condition)
            .await
    );
    assert_eq!(h.starts(), vec!["compact-1".to_string()]);
    assert_eq!(h.aborts.load(Ordering::SeqCst), 0);
    {
        let active = h.session.active_turn.lock().await;
        let turn = active.as_ref().unwrap();
        assert!(turn.compact_reservation.is_none());
        assert_eq!(turn.task.as_ref().unwrap().kind, TaskKind::Compact);
    }
    h.session
        .abort_all_tasks(TurnAbortReason::Interrupted)
        .await;
}

// (d1) activity-only veto: no pending input, no submission; only the watched activity moved.
#[tokio::test]
async fn activity_only_change_vetoes_before_contributors() {
    let h = harness(None).await;
    let (_tx, rx) = async_channel::bounded(4);
    let (activity_tx, activity) = tokio::sync::watch::channel(InputQueueActivity::Mailbox);
    activity_tx.send_replace(InputQueueActivity::Steer);
    let joined = Arc::new(JoinedCompaction {
        turn_id: "original".into(),
        attempt_id: "attempt".into(),
        activity,
    });
    let condition = {
        let mut active = h.session.active_turn.lock().await;
        CompactReservation::reserve(&mut active, joined, rx)
    };
    let (turn_state, generation) = (Arc::clone(&condition.turn_state), condition.generation);
    assert!(turn_state.lock().await.pending_input.is_empty());
    assert!(
        !h.session
            .start_reserved_compact(h.turn("compact-1").await, held_compact(), condition)
            .await
    );
    assert!(h.starts().is_empty() && h.aborts.load(Ordering::SeqCst) == 0);
    assert_eq!(
        h.session.state.lock().await.last_started_turn_id.as_deref(),
        Some("original")
    );
    h.session
        .clear_compact_reservation(&turn_state, generation)
        .await;
    assert!(
        h.session.active_turn.lock().await.is_none(),
        "own empty slot cleared"
    );
    drop(activity_tx);
}

// (d2) pending-input-only veto: activity watcher subscribed after the input, so unchanged.
#[tokio::test]
async fn pending_input_only_vetoes_and_keeps_the_input() {
    let h = harness(None).await;
    let (_tx, rx) = async_channel::bounded(4);
    let slot = ActiveTurn::default();
    let turn_state = Arc::clone(&slot.turn_state);
    *h.session.active_turn.lock().await = Some(slot);
    h.session
        .input_queue
        .extend_pending_input_for_turn_state(turn_state.as_ref(), vec![user_text("keep")])
        .await;
    let joined = Arc::new(JoinedCompaction {
        turn_id: "original".into(),
        attempt_id: "attempt".into(),
        activity: h.session.input_queue.subscribe_activity(None).await.0,
    });
    assert!(matches!(joined.activity.has_changed(), Ok(false)));
    let condition = {
        let mut active = h.session.active_turn.lock().await;
        CompactReservation::reserve(&mut active, joined, rx)
    };
    let generation = condition.generation;
    assert!(Arc::ptr_eq(&condition.turn_state, &turn_state));
    assert!(
        !h.session
            .start_reserved_compact(h.turn("compact-1").await, held_compact(), condition)
            .await
    );
    assert!(h.starts().is_empty() && h.aborts.load(Ordering::SeqCst) == 0);
    h.session
        .clear_compact_reservation(&turn_state, generation)
        .await;
    let active = h.session.active_turn.lock().await;
    let turn = active.as_ref().expect("slot with queued input kept");
    assert!(turn.compact_reservation.is_none() && Arc::ptr_eq(&turn.turn_state, &turn_state));
    assert!(
        !turn_state.lock().await.pending_input.is_empty(),
        "input not dropped"
    );
}

// other-turn veto, also before contributors.
#[tokio::test]
async fn other_turn_vetoes_before_contributors() {
    let h = harness(None).await;
    let (_tx, rx) = async_channel::bounded(4);
    let condition = reserve_original(&h.session, rx).await;
    h.session.state.lock().await.last_started_turn_id = Some("other".into());
    assert!(
        !h.session
            .start_reserved_compact(h.turn("compact-1").await, held_compact(), condition)
            .await
    );
    assert!(h.starts().is_empty() && h.aborts.load(Ordering::SeqCst) == 0);
}

// (e) foreign reservation cleanup is untouched: other generation, and unmarked ordinary slot.
fn recording(
    seen: &Arc<std::sync::Mutex<Vec<Vec<TurnInput>>>>,
    ran: &Arc<Notify>,
) -> RecordingTask {
    RecordingTask {
        seen: Arc::clone(seen),
        ran: Arc::clone(ran),
    }
}

// start_if_idle's reserved slot, claimed by a direct start_task, survives its own
// clear_reserved_idle_turn and an abort_all_tasks(Replaced) while contributors run; queued mail
// drained into it stays with the installed task. V5 erased the plain slot here (mail lost).
#[tokio::test]
async fn claimed_reserved_slot_survives_idle_cleanup_and_replace_abort() {
    let h = harness(Some("regular-1")).await;
    let reserved = {
        let mut active = h.session.active_turn.lock().await;
        Arc::clone(&active.get_or_insert_with(ActiveTurn::default).turn_state)
    };
    let mail = codex_protocol::protocol::InterAgentCommunication::new(
        codex_protocol::AgentPath::root()
            .join("worker")
            .expect("worker path"),
        codex_protocol::AgentPath::root(),
        Vec::new(),
        "child done".to_owned(),
        /*trigger_turn*/ false,
    );
    h.session
        .input_queue
        .enqueue_mailbox_communication(mail, Default::default())
        .await;
    let seen = Arc::new(std::sync::Mutex::new(Vec::new()));
    let ran = Arc::new(Notify::new());
    let regular = h.turn("regular-1").await;
    tokio::join!(
        h.session
            .start_task(regular, vec![user_text("hi")], recording(&seen, &ran)),
        async {
            h.entered.notified().await;
            h.session.clear_reserved_idle_turn(&reserved).await;
            h.session.abort_all_tasks(TurnAbortReason::Replaced).await;
            h.release.notify_one();
        }
    );
    ran.notified().await;
    {
        let active = h.session.active_turn.lock().await;
        let turn = active.as_ref().expect("slot kept");
        assert!(
            Arc::ptr_eq(&turn.turn_state, &reserved),
            "same reserved slot installed"
        );
        assert!(
            turn.ordinary_claim.is_none(),
            "claim released at installation"
        );
        assert_eq!(turn.task.as_ref().expect("task").kind, TaskKind::Regular);
    }
    assert!(
        !reserved.lock().await.pending_input.is_empty(),
        "drained mail kept on the installed slot"
    );
    assert_eq!(
        h.aborts.load(Ordering::SeqCst),
        0,
        "Replaced never takes a slot under preparation"
    );
    h.session
        .abort_all_tasks(TurnAbortReason::Interrupted)
        .await;
}

// An explicit Interrupted during an ordinary start's contributors is applied after installation
// (one balanced abort, no task left). V5 lost it: the task was installed and kept running.
#[tokio::test]
async fn interrupt_during_ordinary_preparation_is_applied_after_install() {
    let h = harness(Some("regular-1")).await;
    let seen = Arc::new(std::sync::Mutex::new(Vec::new()));
    let ran = Arc::new(Notify::new());
    let regular = h.turn("regular-1").await;
    tokio::join!(
        h.session
            .spawn_task(regular, vec![user_text("hi")], recording(&seen, &ran)),
        async {
            h.entered.notified().await;
            h.session
                .abort_all_tasks(TurnAbortReason::Interrupted)
                .await;
            h.release.notify_one();
        }
    );
    assert_eq!(h.starts(), vec!["regular-1".to_string()]);
    assert_eq!(
        h.aborts.load(Ordering::SeqCst),
        1,
        "start balanced by exactly one abort"
    );
    assert!(
        h.session
            .active_turn
            .lock()
            .await
            .as_ref()
            .is_none_or(|turn| turn.task.is_none())
    );
}

// Two spawns accepted during a committed compact preparation replay in FIFO order through
// spawn_task: compact yields once, A starts, B replaces A with A's own balanced abort.
#[tokio::test]
async fn two_deferred_spawns_replay_fifo_with_balanced_lifecycles() {
    let h = harness(Some("compact-1")).await;
    let (_tx, rx) = async_channel::bounded(4);
    let condition = reserve_original(&h.session, rx).await;
    let seen_a = Arc::new(std::sync::Mutex::new(Vec::new()));
    let seen_b = Arc::new(std::sync::Mutex::new(Vec::new()));
    let (ran_a, ran_b) = (Arc::new(Notify::new()), Arc::new(Notify::new()));
    let compact = h.turn("compact-1").await;
    let (a, b) = (h.turn("regular-a").await, h.turn("regular-b").await);
    let (installed, ()) = tokio::join!(
        h.session
            .start_reserved_compact(compact, held_compact(), condition),
        async {
            h.entered.notified().await;
            h.session
                .spawn_task(a, vec![user_text("a")], recording(&seen_a, &ran_a))
                .await;
            h.session
                .spawn_task(b, vec![user_text("b")], recording(&seen_b, &ran_b))
                .await;
            h.release.notify_one();
        }
    );
    assert!(!installed);
    ran_b.notified().await;
    assert_eq!(h.starts(), vec!["compact-1", "regular-a", "regular-b"]);
    assert_eq!(
        h.aborts.load(Ordering::SeqCst),
        2,
        "compact-1 and regular-a each aborted once"
    );
    assert_eq!(seen_b.lock().expect("seen").len(), 1, "B ran exactly once");
    assert_eq!(
        h.session.state.lock().await.last_started_turn_id.as_deref(),
        Some("regular-b")
    );
    h.session
        .abort_all_tasks(TurnAbortReason::Interrupted)
        .await;
}

// Mail arriving during a committed preparation neither vetoes nor joins the compact; it stays
// queued (with its start options) and is what the following ordinary turn starts with.
#[tokio::test]
async fn mailbox_arrival_during_committed_preparation_waits_for_ordinary_turn() {
    let h = harness(Some("compact-1")).await;
    let (_tx, rx) = async_channel::bounded(4);
    let condition = reserve_original(&h.session, rx).await;
    let compact = h.turn("compact-1").await;
    let (installed, ()) = tokio::join!(
        h.session
            .start_reserved_compact(compact, held_compact(), condition),
        async {
            h.entered.notified().await;
            let mail = codex_protocol::protocol::InterAgentCommunication::new(
                codex_protocol::AgentPath::root()
                    .join("worker")
                    .expect("worker path"),
                codex_protocol::AgentPath::root(),
                Vec::new(),
                "wake".to_owned(),
                /*trigger_turn*/ true,
            );
            h.session
                .input_queue
                .enqueue_mailbox_communication(mail, Default::default())
                .await;
            h.release.notify_one();
        }
    );
    assert!(installed, "the single committed decision stands");
    assert!(
        h.session.input_queue.has_trigger_turn_mailbox_items().await,
        "mail still queued"
    );
    h.session
        .abort_all_tasks(TurnAbortReason::Interrupted)
        .await; // -> maybe_start_turn_for_pending_work
    assert_eq!(
        h.starts().len(),
        2,
        "compact, then one ordinary turn for the mail"
    );
    assert!(
        !h.session.input_queue.has_trigger_turn_mailbox_items().await,
        "mail consumed by that turn"
    );
    h.session
        .abort_all_tasks(TurnAbortReason::Interrupted)
        .await;
}

// R1: maybe_start/start_if_idle reserved an idle slot; spawn A took it and installed. The later
// direct start is refused by checked admission: no lifecycle, same A, mail moved to A.
// V6 claimed A's running slot here (debug_assert panic / release overwrite of A).
#[tokio::test]
async fn direct_start_after_spawn_took_reserved_slot_is_refused_without_side_effects() {
    let h = harness(None).await;
    let reserved = {
        let mut active = h.session.active_turn.lock().await;
        Arc::clone(&active.get_or_insert_with(ActiveTurn::default).turn_state)
    };
    let seen = Arc::new(std::sync::Mutex::new(Vec::new()));
    let ran = Arc::new(Notify::new());
    h.session
        .spawn_task(
            h.turn("regular-a").await,
            vec![user_text("a")],
            recording(&seen, &ran),
        )
        .await;
    ran.notified().await;
    let a_state = {
        let active = h.session.active_turn.lock().await;
        let turn = active.as_ref().expect("A installed");
        assert_eq!(
            turn.task.as_ref().expect("task").turn_context.sub_id,
            "regular-a"
        );
        Arc::clone(&turn.turn_state)
    };
    assert!(
        !Arc::ptr_eq(&a_state, &reserved),
        "spawn replaced the idle reservation"
    );
    // Mail the reservation had already drained before its start.
    h.session
        .input_queue
        .extend_pending_input_for_turn_state(reserved.as_ref(), vec![user_text("mail")])
        .await;
    let late = h.turn("direct-1").await;
    assert!(
        !h.session
            .start_task_if_admitted(late, Vec::new(), crate::tasks::RegularTask::new())
            .await
    );
    h.session.redeliver_orphaned_pending_input(&reserved).await;
    assert_eq!(
        h.starts(),
        vec!["regular-a".to_string()],
        "zero extra lifecycle"
    );
    assert_eq!(h.aborts.load(Ordering::SeqCst), 0);
    {
        let active = h.session.active_turn.lock().await;
        let turn = active.as_ref().expect("A kept");
        assert!(Arc::ptr_eq(&turn.turn_state, &a_state), "same A slot");
        assert_eq!(
            turn.task.as_ref().expect("task").turn_context.sub_id,
            "regular-a"
        );
        assert!(turn.ordinary_claim.is_none());
    }
    assert!(
        !a_state.lock().await.pending_input.is_empty(),
        "mail moved to A"
    );
    assert!(reserved.lock().await.pending_input.is_empty());
    assert_eq!(seen.lock().expect("seen").len(), 1, "A ran once");
    h.session
        .abort_all_tasks(TurnAbortReason::Interrupted)
        .await;
}

fn user_request(text: &str, client: &str) -> codex_protocol::turn_input::TurnInputRequest {
    codex_protocol::turn_input::TurnInputRequest {
        input: codex_protocol::turn_input::TurnInput::UserInput {
            content: vec![UserInput::Text {
                text: text.into(),
                text_elements: Vec::new(),
            }],
            client_id: Some(client.into()),
        },
        thread_settings: Default::default(),
        start: Default::default(),
        additional_context: Default::default(),
        responsesapi_client_metadata: Some(std::collections::HashMap::from([(
            "client".to_string(),
            client.to_string(),
        )])),
        trace: None,
    }
}

async fn deferred_len(session: &Arc<Session>) -> usize {
    let active = session.active_turn.lock().await;
    active
        .as_ref()
        .and_then(ActiveTurn::preparation)
        .map_or(0, |(_, deferred)| deferred.len())
}

// R2: two user inputs (different client metadata) accepted while a committed compact prepares
// replay through the real start_or_steer decision: A starts the one RegularTask and B steers
// into it. No Replaced abort of A; both callers get truthful results. V6 returned Started for B
// and replaced A (aborts == 2).
#[tokio::test]
async fn deferred_user_inputs_replay_admission_and_steer_into_one_regular_turn() {
    use codex_protocol::turn_input::TurnInputMode;
    use codex_protocol::turn_input::TurnInputSubmission;
    let h = harness(Some("compact-1")).await;
    let (_tx, rx) = async_channel::bounded(4);
    let condition = reserve_original(&h.session, rx).await;
    let compact = h.turn("compact-1").await;
    let session = Arc::clone(&h.session);
    let (installed, (a, b)) = tokio::join!(
        h.session
            .start_reserved_compact(compact, held_compact(), condition),
        async {
            h.entered.notified().await;
            let sa = Arc::clone(&session);
            let a = tokio::spawn(async move {
                crate::session::turn_input::handle(
                    &sa,
                    user_request("a", "client-a"),
                    TurnInputMode::StartOrSteer,
                    "regular-a".into(),
                )
                .await
            });
            for _ in 0..1000 {
                if deferred_len(&session).await >= 1 {
                    break;
                }
                tokio::task::yield_now().await;
            }
            let sb = Arc::clone(&session);
            let b = tokio::spawn(async move {
                crate::session::turn_input::handle(
                    &sb,
                    user_request("b", "client-b"),
                    TurnInputMode::StartOrSteer,
                    "regular-b".into(),
                )
                .await
            });
            for _ in 0..1000 {
                if deferred_len(&session).await >= 2 {
                    break;
                }
                tokio::task::yield_now().await;
            }
            assert_eq!(
                deferred_len(&session).await,
                2,
                "both inputs queued behind the preparation"
            );
            h.release.notify_one();
            (a.await.expect("a joined"), b.await.expect("b joined"))
        }
    );
    assert!(!installed, "compact yields to the accepted input");
    assert_eq!(
        a.expect("a ok"),
        TurnInputSubmission::Started {
            turn_id: "regular-a".into()
        }
    );
    assert_eq!(
        b.expect("b ok"),
        TurnInputSubmission::Steered {
            turn_id: "regular-a".into()
        }
    );
    assert_eq!(
        h.starts(),
        vec!["compact-1".to_string(), "regular-a".to_string()],
        "one RegularTask"
    );
    assert_eq!(
        h.aborts.load(Ordering::SeqCst),
        1,
        "only compact-1 aborted; A never Replaced"
    );
    {
        let active = h.session.active_turn.lock().await;
        let task = active
            .as_ref()
            .and_then(|turn| turn.task.as_ref())
            .expect("A running");
        assert_eq!(task.turn_context.sub_id, "regular-a");
        assert_eq!(task.kind, TaskKind::Regular);
    }
    h.session
        .abort_all_tasks(TurnAbortReason::Interrupted)
        .await;
}

#[tokio::test]
async fn clear_compact_reservation_ignores_foreign_generation_and_ordinary_slot() {
    let h = harness(None).await;
    let (_tx, rx) = async_channel::bounded(4);
    let condition = reserve_original(&h.session, rx).await;
    h.session
        .clear_compact_reservation(&condition.turn_state, condition.generation + 1)
        .await;
    {
        let active = h.session.active_turn.lock().await;
        assert!(active.as_ref().is_some_and(|turn| {
            turn.compact_reservation
                .as_ref()
                .is_some_and(|t| t.generation == condition.generation)
        }));
    }
    let ordinary = ActiveTurn::default();
    let ordinary_state = Arc::clone(&ordinary.turn_state);
    *h.session.active_turn.lock().await = Some(ordinary);
    h.session
        .clear_compact_reservation(&ordinary_state, condition.generation)
        .await;
    assert!(
        h.session.active_turn.lock().await.is_some(),
        "unmarked slot must not clear"
    );
}
