use super::*;
use crate::session::tests::HeldStepTask;
use crate::session::tests::make_session_and_context_with_rx;
use crate::state::TaskKind;
use codex_protocol::protocol::TurnAbortReason;
use pretty_assertions::assert_eq;
use tokio::sync::Notify;

#[tokio::test]
async fn joined_receipt_is_not_retargetable_or_reusable() {
    let (session, _context, _events) = make_session_and_context_with_rx().await;
    session
        .services
        .thread_extension_data
        .insert(JoinedCompaction {
            turn_id: "original".into(),
            attempt_id: "original-attempt".into(),
            activity: session.input_queue.subscribe_activity(None).await.0,
        });
    let (_tx, rx) = async_channel::bounded(4);
    assert!(
        !session
            .compact_after_interruption("new-turn", "original-attempt", &rx, "compact".into())
            .await
    );
    assert!(
        session
            .services
            .thread_extension_data
            .get::<JoinedCompaction>()
            .is_none()
    );
    assert!(
        !session
            .compact_after_interruption("original", "original-attempt", &rx, "compact".into())
            .await
    );
}

#[tokio::test]
async fn reserved_compact_installs_only_original_idle_reservation() {
    let (session, context, _events) = make_session_and_context_with_rx().await;
    let (_tx, rx) = async_channel::bounded(4);
    session.state.lock().await.last_started_turn_id = Some("original".into());
    let condition = reserve_original(&session, rx).await;
    assert!(
        session
            .start_reserved_compact(
                Arc::clone(&context),
                HeldStepTask {
                    kind: TaskKind::Compact,
                    finish: Arc::new(Notify::new()),
                },
                condition
            )
            .await
    );
    assert_eq!(
        session
            .active_turn
            .lock()
            .await
            .as_ref()
            .unwrap()
            .task
            .as_ref()
            .unwrap()
            .kind,
        TaskKind::Compact
    );
    session.abort_all_tasks(TurnAbortReason::Interrupted).await;
}

#[tokio::test]
async fn replacement_reservation_is_never_overwritten() {
    let (session, context, _events) = make_session_and_context_with_rx().await;
    let (_tx, rx) = async_channel::bounded(4);
    session.state.lock().await.last_started_turn_id = Some("original".into());
    let condition = reserve_original(&session, rx).await;
    let replacement = ActiveTurn::default();
    let replacement_state = Arc::clone(&replacement.turn_state);
    *session.active_turn.lock().await = Some(replacement);
    assert!(
        !session
            .start_reserved_compact(
                context,
                HeldStepTask {
                    kind: TaskKind::Compact,
                    finish: Arc::new(Notify::new()),
                },
                condition
            )
            .await
    );
    let active = session.active_turn.lock().await;
    assert!(Arc::ptr_eq(
        &active.as_ref().unwrap().turn_state,
        &replacement_state
    ));
    assert!(active.as_ref().unwrap().task.is_none());
}

use crate::session::InputQueueActivity;
use crate::session::TurnInput;
use crate::session::turn_context::TurnContext;
use crate::tasks::SessionTask;
use crate::tasks::SessionTaskResult;
use codex_extension_api::ExtensionFuture;
use codex_extension_api::ExtensionRegistryBuilder;
use codex_extension_api::TurnAbortInput;
use codex_extension_api::TurnLifecycleContributor;
use codex_extension_api::TurnStartInput;
use codex_protocol::user_input::UserInput;
use std::sync::atomic::AtomicUsize;
use tokio_util::sync::CancellationToken;

/// Reserves the original attempt's slot through the production constructor.
async fn reserve_original(
    session: &Arc<Session>,
    submissions: async_channel::Receiver<Submission>,
) -> CompactReservation {
    let joined = Arc::new(JoinedCompaction {
        turn_id: "original".into(),
        attempt_id: "attempt".into(),
        activity: session.input_queue.subscribe_activity(None).await.0,
    });
    let mut active = session.active_turn.lock().await;
    CompactReservation::reserve(&mut active, joined, submissions)
}

/// Records turn starts/aborts; optionally pauses the named turn's start (deterministic barrier).
struct Recorder {
    starts: Arc<std::sync::Mutex<Vec<String>>>,
    aborts: Arc<AtomicUsize>,
    pause_turn: Option<String>,
    entered: Arc<Notify>,
    release: Arc<Notify>,
}

impl TurnLifecycleContributor for Recorder {
    fn on_turn_start<'a>(&'a self, input: TurnStartInput<'a>) -> ExtensionFuture<'a, ()> {
        Box::pin(async move {
            self.starts
                .lock()
                .expect("starts")
                .push(input.turn_id.to_string());
            if self.pause_turn.as_deref() == Some(input.turn_id) {
                self.entered.notify_one();
                self.release.notified().await;
            }
        })
    }

    fn on_turn_abort<'a>(&'a self, _input: TurnAbortInput<'a>) -> ExtensionFuture<'a, ()> {
        Box::pin(async move {
            self.aborts.fetch_add(1, Ordering::SeqCst);
        })
    }
}

struct Harness {
    session: Arc<Session>,
    starts: Arc<std::sync::Mutex<Vec<String>>>,
    aborts: Arc<AtomicUsize>,
    entered: Arc<Notify>,
    release: Arc<Notify>,
}

async fn harness(pause_turn: Option<&str>) -> Harness {
    let (mut session, _context) = crate::session::tests::make_session_and_context().await;
    let starts = Arc::new(std::sync::Mutex::new(Vec::new()));
    let aborts = Arc::new(AtomicUsize::new(0));
    let entered = Arc::new(Notify::new());
    let release = Arc::new(Notify::new());
    let mut builder = ExtensionRegistryBuilder::<crate::config::Config>::new();
    builder.turn_lifecycle_contributor(Arc::new(Recorder {
        starts: Arc::clone(&starts),
        aborts: Arc::clone(&aborts),
        pause_turn: pause_turn.map(str::to_string),
        entered: Arc::clone(&entered),
        release: Arc::clone(&release),
    }));
    session.services.extensions = Arc::new(builder.build());
    session.state.lock().await.last_started_turn_id = Some("original".into());
    Harness {
        session: Arc::new(session),
        starts,
        aborts,
        entered,
        release,
    }
}

impl Harness {
    async fn turn(&self, sub_id: &str) -> Arc<TurnContext> {
        self.session
            .new_turn_with_default_settings(sub_id.into(), Default::default())
            .await
    }
    fn starts(&self) -> Vec<String> {
        self.starts.lock().expect("starts").clone()
    }
}

fn held_compact() -> HeldStepTask {
    HeldStepTask {
        kind: TaskKind::Compact,
        finish: Arc::new(Notify::new()),
    }
}

fn user_text(text: &str) -> TurnInput {
    TurnInput::UserInput {
        content: vec![UserInput::Text {
            text: text.into(),
            text_elements: Vec::new(),
        }],
        client_id: None,
        metadata: Default::default(),
    }
}

/// Regular task that records the input it actually ran with.
struct RecordingTask {
    seen: Arc<std::sync::Mutex<Vec<Vec<TurnInput>>>>,
    ran: Arc<Notify>,
}

impl SessionTask for RecordingTask {
    fn kind(&self) -> TaskKind {
        TaskKind::Regular
    }

    fn span_name(&self) -> &'static str {
        "session_task.compact_recovery_recording_test"
    }

    async fn run(
        self: Arc<Self>,
        _session: Arc<Session>,
        _turn: Arc<TurnContext>,
        input: Vec<TurnInput>,
        cancellation_token: CancellationToken,
    ) -> SessionTaskResult {
        self.seen.lock().expect("seen").push(input);
        self.ran.notify_one();
        cancellation_token.cancelled().await;
        Ok(None)
    }
}
// (a) spawn_task vs an UNCOMMITTED slot: newer ordinary work wins, compact has zero side effects.
#[tokio::test]
async fn spawn_task_replaces_uncommitted_slot_with_zero_compact_side_effects() {
    let h = harness(None).await;
    let (_tx, rx) = async_channel::bounded(4);
    let condition = reserve_original(&h.session, rx).await;
    let reserved_state = Arc::clone(&condition.turn_state);
    h.session
        .spawn_task(
            h.turn("regular-1").await,
            vec![user_text("hello")],
            HeldStepTask {
                kind: TaskKind::Regular,
                finish: Arc::new(Notify::new()),
            },
        )
        .await;
    assert!(
        !h.session
            .start_reserved_compact(h.turn("compact-1").await, held_compact(), condition)
            .await
    );
    assert_eq!(
        h.starts(),
        vec!["regular-1".to_string()],
        "compact contributor never ran"
    );
    assert_eq!(
        h.aborts.load(Ordering::SeqCst),
        0,
        "uncommitted denial needs no abort"
    );
    {
        let active = h.session.active_turn.lock().await;
        let turn = active.as_ref().unwrap();
        assert!(
            !Arc::ptr_eq(&turn.turn_state, &reserved_state) && turn.compact_reservation.is_none()
        );
        assert_eq!(turn.task.as_ref().unwrap().kind, TaskKind::Regular);
    }
    assert_eq!(
        h.session.state.lock().await.last_started_turn_id.as_deref(),
        Some("regular-1")
    );
    h.session
        .abort_all_tasks(TurnAbortReason::Interrupted)
        .await;
}

/// Mirrors Goal's thread-scoped bookkeeping (ext/goal extension.rs:242-252, :367-394): start
/// awaits (the DB call) and then overwrites current/options; abort removes options
/// unconditionally and clears current only if it names the aborted turn. Test simplification:
/// the aborted turn is the oldest started-not-aborted one.
struct GoalLike {
    events: Arc<std::sync::Mutex<Vec<String>>>,
    open: Arc<std::sync::Mutex<Vec<String>>>,
    current: Arc<std::sync::Mutex<Option<String>>>,
    options: Arc<std::sync::Mutex<Option<String>>>,
    pause_turn: Option<String>,
    entered: Arc<Notify>,
    release: Arc<Notify>,
}

impl TurnLifecycleContributor for GoalLike {
    fn on_turn_start<'a>(&'a self, input: TurnStartInput<'a>) -> ExtensionFuture<'a, ()> {
        Box::pin(async move {
            let id = input.turn_id.to_string();
            self.events
                .lock()
                .expect("events")
                .push(format!("start:{id}"));
            self.open.lock().expect("open").push(id.clone());
            if self.pause_turn.as_deref() == Some(id.as_str()) {
                self.entered.notify_one();
                self.release.notified().await;
            }
            *self.current.lock().expect("current") = Some(id.clone());
            *self.options.lock().expect("options") = Some(id);
        })
    }

    fn on_turn_abort<'a>(&'a self, _input: TurnAbortInput<'a>) -> ExtensionFuture<'a, ()> {
        Box::pin(async move {
            let id = self.open.lock().expect("open").remove(0);
            self.events
                .lock()
                .expect("events")
                .push(format!("abort:{id}"));
            *self.options.lock().expect("options") = None;
            let mut current = self.current.lock().expect("current");
            if current.as_deref() == Some(id.as_str()) {
                *current = None;
            }
        })
    }
}

struct GoalHarness {
    session: Arc<Session>,
    goal: Arc<GoalLike>,
}

async fn goal_harness(pause_turn: &str) -> GoalHarness {
    let (mut session, _context) = crate::session::tests::make_session_and_context().await;
    let goal = Arc::new(GoalLike {
        events: Arc::default(),
        open: Arc::default(),
        current: Arc::default(),
        options: Arc::default(),
        pause_turn: Some(pause_turn.to_string()),
        entered: Arc::new(Notify::new()),
        release: Arc::new(Notify::new()),
    });
    let mut builder = ExtensionRegistryBuilder::<crate::config::Config>::new();
    builder.turn_lifecycle_contributor(Arc::clone(&goal) as Arc<dyn TurnLifecycleContributor>);
    session.services.extensions = Arc::new(builder.build());
    session.state.lock().await.last_started_turn_id = Some("original".into());
    GoalHarness {
        session: Arc::new(session),
        goal,
    }
}

impl GoalHarness {
    async fn turn(&self, sub_id: &str) -> Arc<TurnContext> {
        self.session
            .new_turn_with_default_settings(sub_id.into(), Default::default())
            .await
    }
    fn events(&self) -> Vec<String> {
        self.goal.events.lock().expect("events").clone()
    }
    fn current(&self) -> Option<String> {
        self.goal.current.lock().expect("current").clone()
    }
    fn options(&self) -> Option<String> {
        self.goal.options.lock().expect("options").clone()
    }
}

/// Runs A's F1 interleaving (optionally with an explicit Interrupted first) through the real
/// start_reserved_compact / spawn_task / abort_all_tasks. Frozen v4 records
/// [start:compact-1, start:regular-1, abort:compact-1] and leaves current/options = None.
async fn run_f1(interrupt_first: bool) {
    let g = goal_harness("compact-1").await;
    let (_tx, rx) = async_channel::bounded(4);
    let condition = reserve_original(&g.session, rx).await;
    let seen = Arc::new(std::sync::Mutex::new(Vec::new()));
    let ran = Arc::new(Notify::new());
    let compact = g.turn("compact-1").await;
    let regular = g.turn("regular-1").await;
    let (installed, ()) = tokio::join!(
        g.session
            .start_reserved_compact(compact, held_compact(), condition),
        async {
            g.goal.entered.notified().await; // committed; Goal-like start paused before start_turn
            if interrupt_first {
                g.session
                    .abort_all_tasks(TurnAbortReason::Interrupted)
                    .await;
            }
            g.session
                .spawn_task(
                    regular,
                    vec![user_text("queued")],
                    RecordingTask {
                        seen: Arc::clone(&seen),
                        ran: Arc::clone(&ran),
                    },
                )
                .await;
            g.goal.release.notify_one();
        }
    );
    assert!(!installed, "compact yields; it never runs");
    ran.notified().await;
    let seen = seen.lock().expect("seen").clone();
    assert_eq!(seen.len(), 1, "the ordinary task runs exactly once");
    assert!(
        matches!(&seen[0][..], [TurnInput::UserInput { content, .. }]
        if matches!(&content[..], [UserInput::Text { text, .. }] if text == "queued"))
    );
    assert_eq!(
        g.events(),
        vec!["start:compact-1", "abort:compact-1", "start:regular-1"],
        "no overlap"
    );
    assert_eq!(
        g.current(),
        Some("regular-1".to_string()),
        "regular Goal current_turn_id intact"
    );
    assert_eq!(
        g.options(),
        Some("regular-1".to_string()),
        "regular TurnStartOptions intact"
    );
    {
        let active = g.session.active_turn.lock().await;
        let turn = active.as_ref().expect("regular slot");
        assert!(turn.compact_reservation.is_none());
        assert_eq!(turn.task.as_ref().expect("task").kind, TaskKind::Regular);
    }
    assert_eq!(
        g.session.state.lock().await.last_started_turn_id.as_deref(),
        Some("regular-1")
    );
    g.session
        .abort_all_tasks(TurnAbortReason::Interrupted)
        .await;
}

#[tokio::test]
async fn a_f1_spawn_during_committed_preparation_keeps_regular_goal_state() {
    run_f1(false).await;
}

#[tokio::test]
async fn explicit_abort_then_spawn_during_committed_preparation_does_not_overlap() {
    run_f1(true).await;
}

// (a)+(c) spawn_task vs a COMMITTED slot while its contributor is paused: the ordinary start is
// deferred (not stealing the marker); compact yields with one balancing abort, then the queued
// user input becomes exactly one regular turn.
#[tokio::test]
async fn spawn_task_defers_behind_committed_preparation_and_runs_user_input_once() {
    let h = harness(Some("compact-1")).await;
    let (_tx, rx) = async_channel::bounded(4);
    let condition = reserve_original(&h.session, rx).await;
    let seen = Arc::new(std::sync::Mutex::new(Vec::new()));
    let ran = Arc::new(Notify::new());
    let compact = h.turn("compact-1").await;
    let regular = h.turn("regular-1").await;
    let (installed, ()) = tokio::join!(
        h.session
            .start_reserved_compact(compact, held_compact(), condition),
        async {
            h.entered.notified().await; // compact committed; its contributor is paused, no lock held
            h.session
                .spawn_task(
                    regular,
                    vec![user_text("queued")],
                    RecordingTask {
                        seen: Arc::clone(&seen),
                        ran: Arc::clone(&ran),
                    },
                )
                .await;
            h.release.notify_one();
        }
    );
    assert!(!installed, "cancelled preparation is not installed");
    ran.notified().await;
    let seen = seen.lock().expect("seen").clone();
    assert_eq!(seen.len(), 1, "exactly one regular turn ran");
    assert!(
        matches!(&seen[0][..], [TurnInput::UserInput { content, .. }]
        if matches!(&content[..], [UserInput::Text { text, .. }] if text == "queued"))
    );
    assert_eq!(
        h.starts(),
        vec!["compact-1".to_string(), "regular-1".to_string()]
    );
    assert_eq!(
        h.aborts.load(Ordering::SeqCst),
        1,
        "one start of compact-1 balanced by one abort"
    );
    assert_eq!(
        h.session
            .active_turn
            .lock()
            .await
            .as_ref()
            .unwrap()
            .task
            .as_ref()
            .unwrap()
            .kind,
        TaskKind::Regular
    );
    h.session
        .abort_all_tasks(TurnAbortReason::Interrupted)
        .await;
}

// (b) contributor paused, then a plain cancel: start/abort balanced, slot gone, no task installed.
#[tokio::test]
async fn cancel_during_paused_contributor_balances_start_and_abort() {
    let h = harness(Some("compact-1")).await;
    let (_tx, rx) = async_channel::bounded(4);
    let condition = reserve_original(&h.session, rx).await;
    let compact = h.turn("compact-1").await;
    let (installed, ()) = tokio::join!(
        h.session
            .start_reserved_compact(compact, held_compact(), condition),
        async {
            h.entered.notified().await;
            h.session
                .abort_all_tasks(TurnAbortReason::Interrupted)
                .await;
            h.release.notify_one();
        }
    );
    assert!(!installed);
    assert_eq!(h.starts(), vec!["compact-1".to_string()]);
    assert_eq!(h.aborts.load(Ordering::SeqCst), 1);
    assert!(h.session.active_turn.lock().await.is_none());
}

// accepted path: contributor once, marker consumed, no abort.
#[tokio::test]
async fn accepted_reserved_compact_runs_contributor_once_and_consumes_marker() {
    let h = harness(None).await;
    let (_tx, rx) = async_channel::bounded(4);
    let condition = reserve_original(&h.session, rx).await;
    assert!(
        h.session
            .start_reserved_compact(h.turn("compact-1").await, held_compact(), condition)
            .await
    );
    assert_eq!(h.starts(), vec!["compact-1".to_string()]);
    assert_eq!(h.aborts.load(Ordering::SeqCst), 0);
    {
        let active = h.session.active_turn.lock().await;
        let turn = active.as_ref().unwrap();
        assert!(turn.compact_reservation.is_none());
        assert_eq!(turn.task.as_ref().unwrap().kind, TaskKind::Compact);
    }
    h.session
        .abort_all_tasks(TurnAbortReason::Interrupted)
        .await;
}

// (d1) activity-only veto: no pending input, no submission; only the watched activity moved.
#[tokio::test]
async fn activity_only_change_vetoes_before_contributors() {
    let h = harness(None).await;
    let (_tx, rx) = async_channel::bounded(4);
    let (activity_tx, activity) = tokio::sync::watch::channel(InputQueueActivity::Mailbox);
    activity_tx.send_replace(InputQueueActivity::Steer);
    let joined = Arc::new(JoinedCompaction {
        turn_id: "original".into(),
        attempt_id: "attempt".into(),
        activity,
    });
    let condition = {
        let mut active = h.session.active_turn.lock().await;
        CompactReservation::reserve(&mut active, joined, rx)
    };
    let (turn_state, generation) = (Arc::clone(&condition.turn_state), condition.generation);
    assert!(turn_state.lock().await.pending_input.is_empty());
    assert!(
        !h.session
            .start_reserved_compact(h.turn("compact-1").await, held_compact(), condition)
            .await
    );
    assert!(h.starts().is_empty() && h.aborts.load(Ordering::SeqCst) == 0);
    assert_eq!(
        h.session.state.lock().await.last_started_turn_id.as_deref(),
        Some("original")
    );
    h.session
        .clear_compact_reservation(&turn_state, generation)
        .await;
    assert!(
        h.session.active_turn.lock().await.is_none(),
        "own empty slot cleared"
    );
    drop(activity_tx);
}

// (d2) pending-input-only veto: activity watcher subscribed after the input, so unchanged.
#[tokio::test]
async fn pending_input_only_vetoes_and_keeps_the_input() {
    let h = harness(None).await;
    let (_tx, rx) = async_channel::bounded(4);
    let slot = ActiveTurn::default();
    let turn_state = Arc::clone(&slot.turn_state);
    *h.session.active_turn.lock().await = Some(slot);
    h.session
        .input_queue
        .extend_pending_input_for_turn_state(turn_state.as_ref(), vec![user_text("keep")])
        .await;
    let joined = Arc::new(JoinedCompaction {
        turn_id: "original".into(),
        attempt_id: "attempt".into(),
        activity: h.session.input_queue.subscribe_activity(None).await.0,
    });
    assert!(matches!(joined.activity.has_changed(), Ok(false)));
    let condition = {
        let mut active = h.session.active_turn.lock().await;
        CompactReservation::reserve(&mut active, joined, rx)
    };
    let generation = condition.generation;
    assert!(Arc::ptr_eq(&condition.turn_state, &turn_state));
    assert!(
        !h.session
            .start_reserved_compact(h.turn("compact-1").await, held_compact(), condition)
            .await
    );
    assert!(h.starts().is_empty() && h.aborts.load(Ordering::SeqCst) == 0);
    h.session
        .clear_compact_reservation(&turn_state, generation)
        .await;
    let active = h.session.active_turn.lock().await;
    let turn = active.as_ref().expect("slot with queued input kept");
    assert!(turn.compact_reservation.is_none() && Arc::ptr_eq(&turn.turn_state, &turn_state));
    assert!(
        !turn_state.lock().await.pending_input.is_empty(),
        "input not dropped"
    );
}

// other-turn veto, also before contributors.
#[tokio::test]
async fn other_turn_vetoes_before_contributors() {
    let h = harness(None).await;
    let (_tx, rx) = async_channel::bounded(4);
    let condition = reserve_original(&h.session, rx).await;
    h.session.state.lock().await.last_started_turn_id = Some("other".into());
    assert!(
        !h.session
            .start_reserved_compact(h.turn("compact-1").await, held_compact(), condition)
            .await
    );
    assert!(h.starts().is_empty() && h.aborts.load(Ordering::SeqCst) == 0);
}

// (e) foreign reservation cleanup is untouched: other generation, and unmarked ordinary slot.
fn recording(
    seen: &Arc<std::sync::Mutex<Vec<Vec<TurnInput>>>>,
    ran: &Arc<Notify>,
) -> RecordingTask {
    RecordingTask {
        seen: Arc::clone(seen),
        ran: Arc::clone(ran),
    }
}

// start_if_idle's reserved slot, claimed by a direct start_task, survives its own
// clear_reserved_idle_turn and an abort_all_tasks(Replaced) while contributors run; queued mail
// drained into it stays with the installed task. V5 erased the plain slot here (mail lost).
#[tokio::test]
async fn claimed_reserved_slot_survives_idle_cleanup_and_replace_abort() {
    let h = harness(Some("regular-1")).await;
    let reserved = {
        let mut active = h.session.active_turn.lock().await;
        Arc::clone(&active.get_or_insert_with(ActiveTurn::default).turn_state)
    };
    let mail = codex_protocol::protocol::InterAgentCommunication::new(
        codex_protocol::AgentPath::root()
            .join("worker")
            .expect("worker path"),
        codex_protocol::AgentPath::root(),
        Vec::new(),
        "child done".to_owned(),
        /*trigger_turn*/ false,
    );
    h.session
        .input_queue
        .enqueue_mailbox_communication(mail, Default::default())
        .await;
    let seen = Arc::new(std::sync::Mutex::new(Vec::new()));
    let ran = Arc::new(Notify::new());
    let regular = h.turn("regular-1").await;
    tokio::join!(
        h.session
            .start_task(regular, vec![user_text("hi")], recording(&seen, &ran)),
        async {
            h.entered.notified().await;
            h.session.clear_reserved_idle_turn(&reserved).await;
            h.session.abort_all_tasks(TurnAbortReason::Replaced).await;
            h.release.notify_one();
        }
    );
    ran.notified().await;
    {
        let active = h.session.active_turn.lock().await;
        let turn = active.as_ref().expect("slot kept");
        assert!(
            Arc::ptr_eq(&turn.turn_state, &reserved),
            "same reserved slot installed"
        );
        assert!(
            turn.ordinary_claim.is_none(),
            "claim released at installation"
        );
        assert_eq!(turn.task.as_ref().expect("task").kind, TaskKind::Regular);
    }
    assert!(
        !reserved.lock().await.pending_input.is_empty(),
        "drained mail kept on the installed slot"
    );
    assert_eq!(
        h.aborts.load(Ordering::SeqCst),
        0,
        "Replaced never takes a slot under preparation"
    );
    h.session
        .abort_all_tasks(TurnAbortReason::Interrupted)
        .await;
}

// An explicit Interrupted during an ordinary start's contributors is applied after installation
// (one balanced abort, no task left). V5 lost it: the task was installed and kept running.
#[tokio::test]
async fn interrupt_during_ordinary_preparation_is_applied_after_install() {
    let h = harness(Some("regular-1")).await;
    let seen = Arc::new(std::sync::Mutex::new(Vec::new()));
    let ran = Arc::new(Notify::new());
    let regular = h.turn("regular-1").await;
    tokio::join!(
        h.session
            .spawn_task(regular, vec![user_text("hi")], recording(&seen, &ran)),
        async {
            h.entered.notified().await;
            h.session
                .abort_all_tasks(TurnAbortReason::Interrupted)
                .await;
            h.release.notify_one();
        }
    );
    assert_eq!(h.starts(), vec!["regular-1".to_string()]);
    assert_eq!(
        h.aborts.load(Ordering::SeqCst),
        1,
        "start balanced by exactly one abort"
    );
    assert!(
        h.session
            .active_turn
            .lock()
            .await
            .as_ref()
            .is_none_or(|turn| turn.task.is_none())
    );
}

// Two spawns accepted during a committed compact preparation replay in FIFO order through
// spawn_task: compact yields once, A starts, B replaces A with A's own balanced abort.
#[tokio::test]
async fn two_deferred_spawns_replay_fifo_with_balanced_lifecycles() {
    let h = harness(Some("compact-1")).await;
    let (_tx, rx) = async_channel::bounded(4);
    let condition = reserve_original(&h.session, rx).await;
    let seen_a = Arc::new(std::sync::Mutex::new(Vec::new()));
    let seen_b = Arc::new(std::sync::Mutex::new(Vec::new()));
    let (ran_a, ran_b) = (Arc::new(Notify::new()), Arc::new(Notify::new()));
    let compact = h.turn("compact-1").await;
    let (a, b) = (h.turn("regular-a").await, h.turn("regular-b").await);
    let (installed, ()) = tokio::join!(
        h.session
            .start_reserved_compact(compact, held_compact(), condition),
        async {
            h.entered.notified().await;
            h.session
                .spawn_task(a, vec![user_text("a")], recording(&seen_a, &ran_a))
                .await;
            h.session
                .spawn_task(b, vec![user_text("b")], recording(&seen_b, &ran_b))
                .await;
            h.release.notify_one();
        }
    );
    assert!(!installed);
    ran_b.notified().await;
    assert_eq!(h.starts(), vec!["compact-1", "regular-a", "regular-b"]);
    assert_eq!(
        h.aborts.load(Ordering::SeqCst),
        2,
        "compact-1 and regular-a each aborted once"
    );
    assert_eq!(seen_b.lock().expect("seen").len(), 1, "B ran exactly once");
    assert_eq!(
        h.session.state.lock().await.last_started_turn_id.as_deref(),
        Some("regular-b")
    );
    h.session
        .abort_all_tasks(TurnAbortReason::Interrupted)
        .await;
}

// Mail arriving during a committed preparation neither vetoes nor joins the compact; it stays
// queued (with its start options) and is what the following ordinary turn starts with.
#[tokio::test]
async fn mailbox_arrival_during_committed_preparation_waits_for_ordinary_turn() {
    let h = harness(Some("compact-1")).await;
    let (_tx, rx) = async_channel::bounded(4);
    let condition = reserve_original(&h.session, rx).await;
    let compact = h.turn("compact-1").await;
    let (installed, ()) = tokio::join!(
        h.session
            .start_reserved_compact(compact, held_compact(), condition),
        async {
            h.entered.notified().await;
            let mail = codex_protocol::protocol::InterAgentCommunication::new(
                codex_protocol::AgentPath::root()
                    .join("worker")
                    .expect("worker path"),
                codex_protocol::AgentPath::root(),
                Vec::new(),
                "wake".to_owned(),
                /*trigger_turn*/ true,
            );
            h.session
                .input_queue
                .enqueue_mailbox_communication(mail, Default::default())
                .await;
            h.release.notify_one();
        }
    );
    assert!(installed, "the single committed decision stands");
    assert!(
        h.session.input_queue.has_trigger_turn_mailbox_items().await,
        "mail still queued"
    );
    h.session
        .abort_all_tasks(TurnAbortReason::Interrupted)
        .await; // -> maybe_start_turn_for_pending_work
    assert_eq!(
        h.starts().len(),
        2,
        "compact, then one ordinary turn for the mail"
    );
    assert!(
        !h.session.input_queue.has_trigger_turn_mailbox_items().await,
        "mail consumed by that turn"
    );
    h.session
        .abort_all_tasks(TurnAbortReason::Interrupted)
        .await;
}

// R1: maybe_start/start_if_idle reserved an idle slot; spawn A took it and installed. The later
// direct start is refused by checked admission: no lifecycle, same A, mail moved to A.
// V6 claimed A's running slot here (debug_assert panic / release overwrite of A).
#[tokio::test]
async fn direct_start_after_spawn_took_reserved_slot_is_refused_without_side_effects() {
    let h = harness(None).await;
    let reserved = {
        let mut active = h.session.active_turn.lock().await;
        Arc::clone(&active.get_or_insert_with(ActiveTurn::default).turn_state)
    };
    let seen = Arc::new(std::sync::Mutex::new(Vec::new()));
    let ran = Arc::new(Notify::new());
    h.session
        .spawn_task(
            h.turn("regular-a").await,
            vec![user_text("a")],
            recording(&seen, &ran),
        )
        .await;
    ran.notified().await;
    let a_state = {
        let active = h.session.active_turn.lock().await;
        let turn = active.as_ref().expect("A installed");
        assert_eq!(
            turn.task.as_ref().expect("task").turn_context.sub_id,
            "regular-a"
        );
        Arc::clone(&turn.turn_state)
    };
    assert!(
        !Arc::ptr_eq(&a_state, &reserved),
        "spawn replaced the idle reservation"
    );
    // Mail the reservation had already drained before its start.
    h.session
        .input_queue
        .extend_pending_input_for_turn_state(reserved.as_ref(), vec![user_text("mail")])
        .await;
    let late = h.turn("direct-1").await;
    // Production callers now claim first (start_if_idle/maybe_start); a bare refused start still
    // touches nothing, including the orphaned reservation's mail.
    assert!(
        !h.session
            .start_task_if_admitted(late, Vec::new(), crate::tasks::RegularTask::new())
            .await
    );
    assert_eq!(
        h.starts(),
        vec!["regular-a".to_string()],
        "zero extra lifecycle"
    );
    assert_eq!(h.aborts.load(Ordering::SeqCst), 0);
    {
        let active = h.session.active_turn.lock().await;
        let turn = active.as_ref().expect("A kept");
        assert!(Arc::ptr_eq(&turn.turn_state, &a_state), "same A slot");
        assert_eq!(
            turn.task.as_ref().expect("task").turn_context.sub_id,
            "regular-a"
        );
        assert!(turn.ordinary_claim.is_none());
    }
    assert!(a_state.lock().await.pending_input.is_empty(), "A untouched");
    assert!(
        !reserved.lock().await.pending_input.is_empty(),
        "refused start erased nothing"
    );
    assert_eq!(seen.lock().expect("seen").len(), 1, "A ran once");
    h.session
        .abort_all_tasks(TurnAbortReason::Interrupted)
        .await;
}

fn user_request(text: &str, client: &str) -> codex_protocol::turn_input::TurnInputRequest {
    codex_protocol::turn_input::TurnInputRequest {
        input: codex_protocol::turn_input::TurnInput::UserInput {
            content: vec![UserInput::Text {
                text: text.into(),
                text_elements: Vec::new(),
            }],
            client_id: Some(client.into()),
        },
        thread_settings: Default::default(),
        start: Default::default(),
        additional_context: Default::default(),
        responsesapi_client_metadata: Some(std::collections::HashMap::from([(
            "client".to_string(),
            client.to_string(),
        )])),
        trace: None,
    }
}

async fn deferred_len(session: &Arc<Session>) -> usize {
    let active = session.active_turn.lock().await;
    active
        .as_ref()
        .and_then(ActiveTurn::preparation)
        .map_or(0, |(_, deferred)| deferred.len())
}

/// Holds the real RegularTask at its RegularTaskStart phase (before sampling reads pending input)
/// until cancelled, so tests can inspect exactly what was steered into it.
struct HoldRegularStart {
    turn: String,
    entered: Arc<Notify>,
}

impl TurnLifecycleContributor for HoldRegularStart {
    fn turn_start_phase(
        &self,
        _thread_store: &codex_extension_api::ExtensionData,
    ) -> codex_extension_api::TurnStartPhase {
        codex_extension_api::TurnStartPhase::RegularTaskStart
    }

    fn on_turn_start<'a>(&'a self, input: TurnStartInput<'a>) -> ExtensionFuture<'a, ()> {
        Box::pin(async move {
            if input.turn_id == self.turn {
                self.entered.notify_one();
                std::future::pending::<()>().await;
            }
        })
    }
}

/// `harness` plus a RegularTaskStart hold on `hold_turn`.
async fn harness_with_hold(pause_turn: &str, hold_turn: &str) -> (Harness, Arc<Notify>) {
    let (mut session, _context) = crate::session::tests::make_session_and_context().await;
    let starts = Arc::new(std::sync::Mutex::new(Vec::new()));
    let aborts = Arc::new(AtomicUsize::new(0));
    let entered = Arc::new(Notify::new());
    let release = Arc::new(Notify::new());
    let held = Arc::new(Notify::new());
    let mut builder = ExtensionRegistryBuilder::<crate::config::Config>::new();
    builder.turn_lifecycle_contributor(Arc::new(Recorder {
        starts: Arc::clone(&starts),
        aborts: Arc::clone(&aborts),
        pause_turn: Some(pause_turn.to_string()),
        entered: Arc::clone(&entered),
        release: Arc::clone(&release),
    }));
    builder.turn_lifecycle_contributor(Arc::new(HoldRegularStart {
        turn: hold_turn.into(),
        entered: Arc::clone(&held),
    }));
    session.services.extensions = Arc::new(builder.build());
    session.state.lock().await.last_started_turn_id = Some("original".into());
    (
        Harness {
            session: Arc::new(session),
            starts,
            aborts,
            entered,
            release,
        },
        held,
    )
}

async fn spin_until(session: &Arc<Session>, want: usize) {
    for _ in 0..10_000 {
        if deferred_len(session).await >= want {
            return;
        }
        tokio::task::yield_now().await;
    }
}

// R2 (reachable loop shape): an ordinary start A holds the claimed slot in its contributors; the
// next actual start_or_steer B (different client id/metadata) is deferred before any effect, is
// replayed through the real decision after A installs, and steers into A exactly once. A's real
// RegularTask is held before sampling, so B's exact input is still pending on A. No Replaced abort.
#[tokio::test]
async fn deferred_start_or_steer_replays_and_steers_exact_input_into_installed_turn() {
    use codex_protocol::turn_input::TurnInputMode;
    use codex_protocol::turn_input::TurnInputSubmission;
    let (h, held) = harness_with_hold("regular-a", "regular-a").await;
    let s = Arc::clone(&h.session);
    let a = tokio::spawn(async move {
        crate::session::turn_input::handle(
            &s,
            user_request("a", "client-a"),
            TurnInputMode::StartOrSteer,
            "regular-a".into(),
        )
        .await
    });
    h.entered.notified().await; // A claimed and is inside its BeforeTaskRegistration contributors
    let s = Arc::clone(&h.session);
    let b = tokio::spawn(async move {
        crate::session::turn_input::handle(
            &s,
            user_request("b", "client-b"),
            TurnInputMode::StartOrSteer,
            "regular-b".into(),
        )
        .await
    });
    spin_until(&h.session, 1).await;
    assert_eq!(
        deferred_len(&h.session).await,
        1,
        "B queued behind A's claim before any effect"
    );
    h.release.notify_one();
    let a = a.await.expect("a joined").expect("a ok");
    let b = b.await.expect("b joined").expect("b ok");
    held.notified().await; // A's real task is at RegularTaskStart, before sampling
    assert_eq!(
        a,
        TurnInputSubmission::Started {
            turn_id: "regular-a".into()
        }
    );
    assert_eq!(
        b,
        TurnInputSubmission::Steered {
            turn_id: "regular-a".into()
        }
    );
    assert_eq!(
        h.starts(),
        vec!["regular-a".to_string()],
        "one RegularTask; B started nothing"
    );
    assert_eq!(h.aborts.load(Ordering::SeqCst), 0, "A never Replaced");
    let a_state = {
        let active = h.session.active_turn.lock().await;
        let turn = active.as_ref().expect("A installed");
        assert_eq!(
            turn.task.as_ref().expect("task").turn_context.sub_id,
            "regular-a"
        );
        Arc::clone(&turn.turn_state)
    };
    let pending = h
        .session
        .input_queue
        .take_pending_input_for_turn_state(&a_state)
        .await;
    assert!(
        matches!(&pending[..], [TurnInput::UserInput { content, client_id, .. }]
        if client_id.as_deref() == Some("client-b")
            && matches!(&content[..], [UserInput::Text { text, .. }] if text == "b")),
        "exactly B's input steered once: {pending:?}"
    );
    h.session
        .abort_all_tasks(TurnAbortReason::Interrupted)
        .await;
}

// Item 1: start_if_idle claims its exact reservation before any effect. Idle cleanup is a no-op
// and a racing spawn defers behind the claim (never takes the slot or overwrites a task); after
// the idle start installs, the deferred spawn replaces it with A's own balanced abort.
#[tokio::test]
async fn start_if_idle_claims_reservation_before_effects_and_spawn_defers() {
    use codex_protocol::turn_input::TurnInputMode;
    use codex_protocol::turn_input::TurnInputSubmission;
    let (h, _held) = harness_with_hold("idle-1", "idle-1").await;
    let s = Arc::clone(&h.session);
    let idle = tokio::spawn(async move {
        crate::session::turn_input::handle(
            &s,
            user_request("idle", "client-idle"),
            TurnInputMode::StartIfIdle,
            "idle-1".into(),
        )
        .await
    });
    h.entered.notified().await;
    let reserved = {
        let active = h.session.active_turn.lock().await;
        let turn = active.as_ref().expect("claimed reservation");
        assert!(turn.ordinary_claim.is_some() && turn.task.is_none());
        Arc::clone(&turn.turn_state)
    };
    h.session.clear_reserved_idle_turn(&reserved).await; // must not erase the claimed slot
    let seen = Arc::new(std::sync::Mutex::new(Vec::new()));
    let ran = Arc::new(Notify::new());
    let racer = h.turn("spawn-b").await;
    let s = Arc::clone(&h.session);
    let rec = recording(&seen, &ran);
    let spawn = tokio::spawn(async move { s.spawn_task(racer, vec![user_text("b")], rec).await });
    spin_until(&h.session, 1).await;
    assert_eq!(
        deferred_len(&h.session).await,
        1,
        "spawn deferred behind the claim"
    );
    h.release.notify_one();
    assert_eq!(
        idle.await.expect("idle joined").expect("idle ok"),
        TurnInputSubmission::Started {
            turn_id: "idle-1".into()
        }
    );
    spawn.await.expect("spawn joined");
    ran.notified().await;
    assert_eq!(
        h.starts(),
        vec!["idle-1".to_string(), "spawn-b".to_string()]
    );
    assert_eq!(
        h.aborts.load(Ordering::SeqCst),
        1,
        "idle-1 replaced once, balanced"
    );
    assert_eq!(seen.lock().expect("seen").len(), 1);
    h.session
        .abort_all_tasks(TurnAbortReason::Interrupted)
        .await;
}

// Item 2: releasing an owned claim returns mail already drained into it to the mailbox (exact
// content, order), removes only its own slot and replays starts deferred behind it.
#[tokio::test]
async fn release_ordinary_claim_requeues_drained_mail_and_replays_deferred() {
    let h = harness(None).await;
    let (turn_state, claim) = {
        let mut active = h.session.active_turn.lock().await;
        let state = Arc::clone(&active.get_or_insert_with(ActiveTurn::default).turn_state);
        (
            state,
            Session::claim_reserved_slot(&mut active).expect("claim"),
        )
    };
    let mail = |text: &str| {
        codex_protocol::protocol::InterAgentCommunication::new(
            codex_protocol::AgentPath::root()
                .join("worker")
                .expect("worker path"),
            codex_protocol::AgentPath::root(),
            Vec::new(),
            text.to_owned(),
            /*trigger_turn*/ true,
        )
    };
    h.session
        .input_queue
        .extend_pending_input_for_turn_state(
            turn_state.as_ref(),
            vec![
                TurnInput::InterAgentCommunication(mail("m1")),
                TurnInput::InterAgentCommunication(mail("m2")),
            ],
        )
        .await;
    let seen = Arc::new(std::sync::Mutex::new(Vec::new()));
    let ran = Arc::new(Notify::new());
    h.session
        .spawn_task(
            h.turn("after").await,
            vec![user_text("x")],
            recording(&seen, &ran),
        )
        .await;
    assert_eq!(
        deferred_len(&h.session).await,
        1,
        "spawn deferred behind the claim"
    );
    h.session
        .release_ordinary_claim(&turn_state, &claim, None)
        .await;
    ran.notified().await;
    // GHA39509774268 failed here with drain == [] because the replayed spawn's admission
    // (start_task_checked, non-reservation path) already drained the requeued mail into its own
    // slot. The mail was delivered, not lost: assert exactly-once, in-order delivery there.
    {
        let active = h.session.active_turn.lock().await;
        let turn = active.as_ref().expect("deferred spawn installed");
        assert!(
            !Arc::ptr_eq(&turn.turn_state, &turn_state),
            "released slot removed"
        );
        assert_eq!(
            turn.task.as_ref().expect("task").turn_context.sub_id,
            "after"
        );
    }
    let after_state = {
        let active = h.session.active_turn.lock().await;
        Arc::clone(&active.as_ref().expect("after installed").turn_state)
    };
    let delivered: Vec<String> = h
        .session
        .input_queue
        .take_pending_input_for_turn_state(&after_state)
        .await
        .iter()
        .filter_map(|item| match item {
            TurnInput::InterAgentCommunication(mail) => Some(mail.content.clone()),
            _ => None,
        })
        .collect();
    assert_eq!(
        delivered,
        vec!["m1".to_string(), "m2".to_string()],
        "delivered once, in order"
    );
    assert!(
        h.session
            .input_queue
            .drain_mailbox_input_items()
            .await
            .0
            .is_empty(),
        "no duplicate left in the mailbox"
    );
    // A stale release never touches the unrelated running turn.
    h.session
        .release_ordinary_claim(&turn_state, &claim, None)
        .await;
    assert!(
        h.session
            .active_turn
            .lock()
            .await
            .as_ref()
            .is_some_and(|turn| turn.task.is_some())
    );
    h.session
        .abort_all_tasks(TurnAbortReason::Interrupted)
        .await;
}

// V10 negative: a deferred start_or_steer B whose settings differ from the installed A
// (final_output_json_schema) is replayed through the real steer decision and rejected with
// NotSubmitted(ActiveTurnOutputSchemaMismatch); it is not merged into A, nothing is aborted.
#[tokio::test]
async fn deferred_start_or_steer_with_different_schema_is_not_merged_into_installed_turn() {
    use codex_protocol::turn_input::NotSubmittedReason;
    use codex_protocol::turn_input::TurnInputMode;
    use codex_protocol::turn_input::TurnInputSubmission;
    let (h, held) = harness_with_hold("regular-a", "regular-a").await;
    let s = Arc::clone(&h.session);
    let a = tokio::spawn(async move {
        crate::session::turn_input::handle(
            &s,
            user_request("a", "client-a"),
            TurnInputMode::StartOrSteer,
            "regular-a".into(),
        )
        .await
    });
    h.entered.notified().await;
    let mut b_request = user_request("b", "client-b");
    b_request.start.final_output_json_schema = Some(serde_json::json!({"type": "object"}));
    let s = Arc::clone(&h.session);
    let b = tokio::spawn(async move {
        crate::session::turn_input::handle(
            &s,
            b_request,
            TurnInputMode::StartOrSteer,
            "regular-b".into(),
        )
        .await
    });
    spin_until(&h.session, 1).await;
    assert_eq!(
        deferred_len(&h.session).await,
        1,
        "B queued before any effect"
    );
    h.release.notify_one();
    let a = a.await.expect("a joined").expect("a ok");
    let b = b.await.expect("b joined").expect("b ok");
    held.notified().await;
    assert_eq!(
        a,
        TurnInputSubmission::Started {
            turn_id: "regular-a".into()
        }
    );
    assert_eq!(
        b,
        TurnInputSubmission::NotSubmitted {
            reason: NotSubmittedReason::ActiveTurnOutputSchemaMismatch
        }
    );
    assert_eq!(h.starts(), vec!["regular-a".to_string()]);
    assert_eq!(h.aborts.load(Ordering::SeqCst), 0);
    let a_state = {
        let active = h.session.active_turn.lock().await;
        Arc::clone(&active.as_ref().expect("A installed").turn_state)
    };
    assert!(
        h.session
            .input_queue
            .take_pending_input_for_turn_state(&a_state)
            .await
            .is_empty(),
        "B's mismatched input was not merged into A"
    );
    h.session
        .abort_all_tasks(TurnAbortReason::Interrupted)
        .await;
}

fn lineage_mail(
    text: &str,
    parent: Option<&str>,
    root: Option<&str>,
) -> (
    codex_protocol::protocol::InterAgentCommunication,
    codex_protocol::turn_input::TurnStartOptions,
) {
    let mail = codex_protocol::protocol::InterAgentCommunication::new(
        codex_protocol::AgentPath::root()
            .join("worker")
            .expect("worker path"),
        codex_protocol::AgentPath::root(),
        Vec::new(),
        text.to_owned(),
        /*trigger_turn*/ true,
    );
    let mut options = codex_protocol::turn_input::TurnStartOptions::default();
    options.parent_turn_id = parent.map(str::to_string);
    options.root_turn_id = root.map(str::to_string);
    options.turn_trigger = Some(format!("trigger-{text}"));
    (mail, options)
}

fn contents(items: &[TurnInput]) -> Vec<String> {
    items
        .iter()
        .filter_map(|item| match item {
            TurnInput::InterAgentCommunication(mail) => Some(mail.content.clone()),
            _ => None,
        })
        .collect()
}

/// Claims an idle slot and drains the mailbox into it exactly as maybe_start does.
async fn claimed_drain(
    h: &Harness,
) -> (
    Arc<Mutex<TurnState>>,
    crate::state::OrdinaryClaim,
    Vec<TurnInput>,
    codex_protocol::turn_input::TurnStartOptions,
    crate::session::DrainedMailBatch,
) {
    let (turn_state, claim) = {
        let mut active = h.session.active_turn.lock().await;
        let state = Arc::clone(&active.get_or_insert_with(ActiveTurn::default).turn_state);
        (
            state,
            Session::claim_reserved_slot(&mut active).expect("claim"),
        )
    };
    let (input, options, batch) = h
        .session
        .input_queue
        .get_pending_input_with_mail_batch(&h.session.active_turn)
        .await;
    h.session
        .input_queue
        .extend_pending_input_for_turn_state(turn_state.as_ref(), input.clone())
        .await;
    (turn_state, claim, input, options, batch)
}

// V11: two trigger mails with disagreeing lineage, drained into an owned claim, then cancelled
// (Interrupted recorded on the claim) and released with the drained batch: the redrain is the
// same items and merged options. RED on V9: requeue with the one merged options gave root=None
// on redrain while the first drain kept root "r1" (and every mail lost its own trigger).
#[tokio::test]
async fn cancelled_claim_requeue_preserves_disagreeing_lineage_and_per_mail_options() {
    let h = harness(None).await;
    for (text, parent, root) in [
        ("m1", Some("p1"), Some("r1")),
        ("m2", Some("p2"), Some("r2")),
    ] {
        let (mail, options) = lineage_mail(text, parent, root);
        h.session
            .input_queue
            .enqueue_mailbox_communication(mail, options)
            .await;
    }
    let (turn_state, claim, first, first_options, batch) = claimed_drain(&h).await;
    assert_eq!(contents(&first), vec!["m1".to_string(), "m2".to_string()]);
    assert_eq!(first_options.parent_turn_id, None, "parents disagree");
    assert_eq!(
        first_options.root_turn_id.as_deref(),
        Some("r1"),
        "first trigger's root"
    );
    assert_eq!(
        first_options.turn_trigger.as_deref(),
        Some("trigger-m2"),
        "last trigger wins"
    );
    h.session
        .abort_all_tasks(TurnAbortReason::Interrupted)
        .await; // recorded on the claim
    assert!(claim.is_cancelled());
    h.session
        .release_ordinary_claim(&turn_state, &claim, Some(batch))
        .await;
    assert!(
        h.session.active_turn.lock().await.is_none(),
        "own slot removed"
    );
    let (again, again_options) = h.session.input_queue.drain_mailbox_input_items().await;
    assert_eq!(
        contents(&again),
        contents(&first),
        "same content and order, no duplicate"
    );
    assert_eq!(again_options.parent_turn_id, first_options.parent_turn_id);
    assert_eq!(
        again_options.root_turn_id, first_options.root_turn_id,
        "first root kept"
    );
    assert_eq!(again_options.turn_trigger, first_options.turn_trigger);
}

// V11: mail that arrives while the claimed preparation is paused stays after the older requeued
// mail. RED on V9: requeue appended, so the redrain was [m3, m1, m2].
#[tokio::test]
async fn newer_mail_during_preparation_stays_after_requeued_older_mail() {
    let h = harness(None).await;
    for text in ["m1", "m2"] {
        let (mail, options) = lineage_mail(text, None, None);
        h.session
            .input_queue
            .enqueue_mailbox_communication(mail, options)
            .await;
    }
    let (turn_state, claim, _first, _options, batch) = claimed_drain(&h).await;
    let (newer, newer_options) = lineage_mail("m3", None, None);
    h.session
        .input_queue
        .enqueue_mailbox_communication(newer, newer_options)
        .await;
    h.session
        .abort_all_tasks(TurnAbortReason::Interrupted)
        .await;
    h.session
        .release_ordinary_claim(&turn_state, &claim, Some(batch))
        .await;
    let (again, _) = h.session.input_queue.drain_mailbox_input_items().await;
    assert_eq!(
        contents(&again),
        vec!["m1".to_string(), "m2".to_string(), "m3".to_string()]
    );
}

// V11: a release whose claim no longer owns the slot (test fixture: the slot was replaced and a
// different turn A is installed) neither erases nor requeues A's mail nor touches A; only the
// releaser's own orphaned batch returns. RED on V9: the not-owned release returned early and
// the orphaned batch's mail was lost.
#[tokio::test]
async fn foreign_slot_release_cannot_erase_or_requeue_another_turn() {
    let h = harness(None).await;
    let (mail, options) = lineage_mail("m1", None, None);
    h.session
        .input_queue
        .enqueue_mailbox_communication(mail, options)
        .await;
    let (turn_state, claim, _first, _options, batch) = claimed_drain(&h).await;
    *h.session.active_turn.lock().await = None; // fixture: our slot is gone
    let seen = Arc::new(std::sync::Mutex::new(Vec::new()));
    let ran = Arc::new(Notify::new());
    h.session
        .spawn_task(
            h.turn("turn-a").await,
            vec![user_text("a")],
            recording(&seen, &ran),
        )
        .await;
    ran.notified().await;
    let a_state = {
        let active = h.session.active_turn.lock().await;
        let turn = active.as_ref().expect("A installed");
        assert_eq!(
            turn.task.as_ref().expect("task").turn_context.sub_id,
            "turn-a"
        );
        Arc::clone(&turn.turn_state)
    };
    let (a_mail, _) = lineage_mail("a-mail", None, None);
    h.session
        .input_queue
        .extend_pending_input_for_turn_state(
            a_state.as_ref(),
            vec![TurnInput::InterAgentCommunication(a_mail)],
        )
        .await;
    h.session
        .release_ordinary_claim(&turn_state, &claim, Some(batch))
        .await;
    {
        let active = h.session.active_turn.lock().await;
        let turn = active.as_ref().expect("A kept");
        assert!(Arc::ptr_eq(&turn.turn_state, &a_state));
        assert_eq!(
            turn.task.as_ref().expect("task").turn_context.sub_id,
            "turn-a"
        );
    }
    assert_eq!(
        contents(
            &h.session
                .input_queue
                .take_pending_input_for_turn_state(&a_state)
                .await
        ),
        vec!["a-mail".to_string()],
        "A's mail untouched"
    );
    assert_eq!(
        contents(&h.session.input_queue.drain_mailbox_input_items().await.0),
        vec!["m1".to_string()],
        "only own orphaned batch returned"
    );
    assert_eq!(seen.lock().expect("seen").len(), 1);
    h.session
        .abort_all_tasks(TurnAbortReason::Interrupted)
        .await;
}

#[tokio::test]
async fn clear_compact_reservation_ignores_foreign_generation_and_ordinary_slot() {
    let h = harness(None).await;
    let (_tx, rx) = async_channel::bounded(4);
    let condition = reserve_original(&h.session, rx).await;
    h.session
        .clear_compact_reservation(&condition.turn_state, condition.generation + 1)
        .await;
    {
        let active = h.session.active_turn.lock().await;
        assert!(active.as_ref().is_some_and(|turn| {
            turn.compact_reservation
                .as_ref()
                .is_some_and(|t| t.generation == condition.generation)
        }));
    }
    let ordinary = ActiveTurn::default();
    let ordinary_state = Arc::clone(&ordinary.turn_state);
    *h.session.active_turn.lock().await = Some(ordinary);
    h.session
        .clear_compact_reservation(&ordinary_state, condition.generation)
        .await;
    assert!(
        h.session.active_turn.lock().await.is_some(),
        "unmarked slot must not clear"
    );
}
