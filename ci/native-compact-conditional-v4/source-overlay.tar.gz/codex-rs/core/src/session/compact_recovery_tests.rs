use super::*;
use crate::session::tests::HeldStepTask;
use crate::session::tests::make_session_and_context_with_rx;
use crate::state::TaskKind;
use codex_protocol::protocol::TurnAbortReason;
use pretty_assertions::assert_eq;
use tokio::sync::Notify;

#[tokio::test]
async fn joined_receipt_is_not_retargetable_or_reusable() {
    let (session, _context, _events) = make_session_and_context_with_rx().await;
    session
        .services
        .thread_extension_data
        .insert(JoinedCompaction {
            turn_id: "original".into(),
            attempt_id: "original-attempt".into(),
            activity: session.input_queue.subscribe_activity(None).await.0,
        });
    let (_tx, rx) = async_channel::bounded(4);
    assert!(
        !session
            .compact_after_interruption("new-turn", "original-attempt", &rx, "compact".into())
            .await
    );
    assert!(
        session
            .services
            .thread_extension_data
            .get::<JoinedCompaction>()
            .is_none()
    );
    assert!(
        !session
            .compact_after_interruption("original", "original-attempt", &rx, "compact".into())
            .await
    );
}

#[tokio::test]
async fn reserved_compact_installs_only_original_idle_reservation() {
    let (session, context, _events) = make_session_and_context_with_rx().await;
    let (_tx, rx) = async_channel::bounded(4);
    session.state.lock().await.last_started_turn_id = Some("original".into());
    let condition = reserve_original(&session, rx).await;
    assert!(
        session
            .start_reserved_compact(
                Arc::clone(&context),
                HeldStepTask {
                    kind: TaskKind::Compact,
                    finish: Arc::new(Notify::new()),
                },
                condition
            )
            .await
    );
    assert_eq!(
        session
            .active_turn
            .lock()
            .await
            .as_ref()
            .unwrap()
            .task
            .as_ref()
            .unwrap()
            .kind,
        TaskKind::Compact
    );
    session.abort_all_tasks(TurnAbortReason::Interrupted).await;
}

#[tokio::test]
async fn replacement_reservation_is_never_overwritten() {
    let (session, context, _events) = make_session_and_context_with_rx().await;
    let (_tx, rx) = async_channel::bounded(4);
    session.state.lock().await.last_started_turn_id = Some("original".into());
    let condition = reserve_original(&session, rx).await;
    let replacement = ActiveTurn::default();
    let replacement_state = Arc::clone(&replacement.turn_state);
    *session.active_turn.lock().await = Some(replacement);
    assert!(
        !session
            .start_reserved_compact(
                context,
                HeldStepTask {
                    kind: TaskKind::Compact,
                    finish: Arc::new(Notify::new()),
                },
                condition
            )
            .await
    );
    let active = session.active_turn.lock().await;
    assert!(Arc::ptr_eq(
        &active.as_ref().unwrap().turn_state,
        &replacement_state
    ));
    assert!(active.as_ref().unwrap().task.is_none());
}

use crate::session::InputQueueActivity;
use crate::session::TurnInput;
use crate::session::turn_context::TurnContext;
use crate::tasks::SessionTask;
use crate::tasks::SessionTaskResult;
use codex_extension_api::ExtensionFuture;
use codex_extension_api::ExtensionRegistryBuilder;
use codex_extension_api::TurnAbortInput;
use codex_extension_api::TurnLifecycleContributor;
use codex_extension_api::TurnStartInput;
use codex_protocol::user_input::UserInput;
use std::sync::atomic::AtomicUsize;
use tokio_util::sync::CancellationToken;

/// Reserves the original attempt's slot through the production constructor.
async fn reserve_original(
    session: &Arc<Session>,
    submissions: async_channel::Receiver<Submission>,
) -> CompactReservation {
    let joined = Arc::new(JoinedCompaction {
        turn_id: "original".into(),
        attempt_id: "attempt".into(),
        activity: session.input_queue.subscribe_activity(None).await.0,
    });
    let mut active = session.active_turn.lock().await;
    CompactReservation::reserve(&mut active, joined, submissions)
}

/// Records turn starts/aborts; optionally pauses the named turn's start (deterministic barrier).
struct Recorder {
    starts: Arc<std::sync::Mutex<Vec<String>>>,
    aborts: Arc<AtomicUsize>,
    pause_turn: Option<String>,
    entered: Arc<Notify>,
    release: Arc<Notify>,
}

impl TurnLifecycleContributor for Recorder {
    fn on_turn_start<'a>(&'a self, input: TurnStartInput<'a>) -> ExtensionFuture<'a, ()> {
        Box::pin(async move {
            self.starts
                .lock()
                .expect("starts")
                .push(input.turn_id.to_string());
            if self.pause_turn.as_deref() == Some(input.turn_id) {
                self.entered.notify_one();
                self.release.notified().await;
            }
        })
    }

    fn on_turn_abort<'a>(&'a self, _input: TurnAbortInput<'a>) -> ExtensionFuture<'a, ()> {
        Box::pin(async move {
            self.aborts.fetch_add(1, Ordering::SeqCst);
        })
    }
}

struct Harness {
    session: Arc<Session>,
    starts: Arc<std::sync::Mutex<Vec<String>>>,
    aborts: Arc<AtomicUsize>,
    entered: Arc<Notify>,
    release: Arc<Notify>,
}

async fn harness(pause_turn: Option<&str>) -> Harness {
    let (mut session, _context) = crate::session::tests::make_session_and_context().await;
    let starts = Arc::new(std::sync::Mutex::new(Vec::new()));
    let aborts = Arc::new(AtomicUsize::new(0));
    let entered = Arc::new(Notify::new());
    let release = Arc::new(Notify::new());
    let mut builder = ExtensionRegistryBuilder::<crate::config::Config>::new();
    builder.turn_lifecycle_contributor(Arc::new(Recorder {
        starts: Arc::clone(&starts),
        aborts: Arc::clone(&aborts),
        pause_turn: pause_turn.map(str::to_string),
        entered: Arc::clone(&entered),
        release: Arc::clone(&release),
    }));
    session.services.extensions = Arc::new(builder.build());
    session.state.lock().await.last_started_turn_id = Some("original".into());
    Harness {
        session: Arc::new(session),
        starts,
        aborts,
        entered,
        release,
    }
}

impl Harness {
    async fn turn(&self, sub_id: &str) -> Arc<TurnContext> {
        self.session
            .new_turn_with_default_settings(sub_id.into(), Default::default())
            .await
    }
    fn starts(&self) -> Vec<String> {
        self.starts.lock().expect("starts").clone()
    }
}

fn held_compact() -> HeldStepTask {
    HeldStepTask {
        kind: TaskKind::Compact,
        finish: Arc::new(Notify::new()),
    }
}

fn user_text(text: &str) -> TurnInput {
    TurnInput::UserInput {
        content: vec![UserInput::Text {
            text: text.into(),
            text_elements: Vec::new(),
        }],
        client_id: None,
        metadata: Default::default(),
    }
}

/// Regular task that records the input it actually ran with.
struct RecordingTask {
    seen: Arc<std::sync::Mutex<Vec<Vec<TurnInput>>>>,
    ran: Arc<Notify>,
}

impl SessionTask for RecordingTask {
    fn kind(&self) -> TaskKind {
        TaskKind::Regular
    }

    fn span_name(&self) -> &'static str {
        "session_task.compact_recovery_recording_test"
    }

    async fn run(
        self: Arc<Self>,
        _session: Arc<Session>,
        _turn: Arc<TurnContext>,
        input: Vec<TurnInput>,
        cancellation_token: CancellationToken,
    ) -> SessionTaskResult {
        self.seen.lock().expect("seen").push(input);
        self.ran.notify_one();
        cancellation_token.cancelled().await;
        Ok(None)
    }
}
// (a) spawn_task vs an UNCOMMITTED slot: newer ordinary work wins, compact has zero side effects.
#[tokio::test]
async fn spawn_task_replaces_uncommitted_slot_with_zero_compact_side_effects() {
    let h = harness(None).await;
    let (_tx, rx) = async_channel::bounded(4);
    let condition = reserve_original(&h.session, rx).await;
    let reserved_state = Arc::clone(&condition.turn_state);
    h.session
        .spawn_task(
            h.turn("regular-1").await,
            vec![user_text("hello")],
            HeldStepTask {
                kind: TaskKind::Regular,
                finish: Arc::new(Notify::new()),
            },
        )
        .await;
    assert!(
        !h.session
            .start_reserved_compact(h.turn("compact-1").await, held_compact(), condition)
            .await
    );
    assert_eq!(
        h.starts(),
        vec!["regular-1".to_string()],
        "compact contributor never ran"
    );
    assert_eq!(
        h.aborts.load(Ordering::SeqCst),
        0,
        "uncommitted denial needs no abort"
    );
    {
        let active = h.session.active_turn.lock().await;
        let turn = active.as_ref().unwrap();
        assert!(
            !Arc::ptr_eq(&turn.turn_state, &reserved_state) && turn.compact_reservation.is_none()
        );
        assert_eq!(turn.task.as_ref().unwrap().kind, TaskKind::Regular);
    }
    assert_eq!(
        h.session.state.lock().await.last_started_turn_id.as_deref(),
        Some("regular-1")
    );
    h.session
        .abort_all_tasks(TurnAbortReason::Interrupted)
        .await;
}

// (a)+(c) spawn_task vs a COMMITTED slot while its contributor is paused: the queued user input
// becomes exactly one regular turn; compact is cancelled with exactly one balancing abort.
#[tokio::test]
async fn spawn_task_cancels_committed_preparation_and_runs_user_input_once() {
    let h = harness(Some("compact-1")).await;
    let (_tx, rx) = async_channel::bounded(4);
    let condition = reserve_original(&h.session, rx).await;
    let seen = Arc::new(std::sync::Mutex::new(Vec::new()));
    let ran = Arc::new(Notify::new());
    let compact = h.turn("compact-1").await;
    let regular = h.turn("regular-1").await;
    let (installed, ()) = tokio::join!(
        h.session
            .start_reserved_compact(compact, held_compact(), condition),
        async {
            h.entered.notified().await; // compact committed; its contributor is paused, no lock held
            h.session
                .spawn_task(
                    regular,
                    vec![user_text("queued")],
                    RecordingTask {
                        seen: Arc::clone(&seen),
                        ran: Arc::clone(&ran),
                    },
                )
                .await;
            h.release.notify_one();
        }
    );
    assert!(!installed, "cancelled preparation is not installed");
    ran.notified().await;
    let seen = seen.lock().expect("seen").clone();
    assert_eq!(seen.len(), 1, "exactly one regular turn ran");
    assert!(
        matches!(&seen[0][..], [TurnInput::UserInput { content, .. }]
        if matches!(&content[..], [UserInput::Text { text, .. }] if text == "queued"))
    );
    assert_eq!(
        h.starts(),
        vec!["compact-1".to_string(), "regular-1".to_string()]
    );
    assert_eq!(
        h.aborts.load(Ordering::SeqCst),
        1,
        "one start of compact-1 balanced by one abort"
    );
    assert_eq!(
        h.session
            .active_turn
            .lock()
            .await
            .as_ref()
            .unwrap()
            .task
            .as_ref()
            .unwrap()
            .kind,
        TaskKind::Regular
    );
    h.session
        .abort_all_tasks(TurnAbortReason::Interrupted)
        .await;
}

// (b) contributor paused, then a plain cancel: start/abort balanced, slot gone, no task installed.
#[tokio::test]
async fn cancel_during_paused_contributor_balances_start_and_abort() {
    let h = harness(Some("compact-1")).await;
    let (_tx, rx) = async_channel::bounded(4);
    let condition = reserve_original(&h.session, rx).await;
    let compact = h.turn("compact-1").await;
    let (installed, ()) = tokio::join!(
        h.session
            .start_reserved_compact(compact, held_compact(), condition),
        async {
            h.entered.notified().await;
            h.session
                .abort_all_tasks(TurnAbortReason::Interrupted)
                .await;
            h.release.notify_one();
        }
    );
    assert!(!installed);
    assert_eq!(h.starts(), vec!["compact-1".to_string()]);
    assert_eq!(h.aborts.load(Ordering::SeqCst), 1);
    assert!(h.session.active_turn.lock().await.is_none());
}

// accepted path: contributor once, marker consumed, no abort.
#[tokio::test]
async fn accepted_reserved_compact_runs_contributor_once_and_consumes_marker() {
    let h = harness(None).await;
    let (_tx, rx) = async_channel::bounded(4);
    let condition = reserve_original(&h.session, rx).await;
    assert!(
        h.session
            .start_reserved_compact(h.turn("compact-1").await, held_compact(), condition)
            .await
    );
    assert_eq!(h.starts(), vec!["compact-1".to_string()]);
    assert_eq!(h.aborts.load(Ordering::SeqCst), 0);
    {
        let active = h.session.active_turn.lock().await;
        let turn = active.as_ref().unwrap();
        assert!(turn.compact_reservation.is_none());
        assert_eq!(turn.task.as_ref().unwrap().kind, TaskKind::Compact);
    }
    h.session
        .abort_all_tasks(TurnAbortReason::Interrupted)
        .await;
}

// (d1) activity-only veto: no pending input, no submission; only the watched activity moved.
#[tokio::test]
async fn activity_only_change_vetoes_before_contributors() {
    let h = harness(None).await;
    let (_tx, rx) = async_channel::bounded(4);
    let (activity_tx, activity) = tokio::sync::watch::channel(InputQueueActivity::Mailbox);
    activity_tx.send_replace(InputQueueActivity::Steer);
    let joined = Arc::new(JoinedCompaction {
        turn_id: "original".into(),
        attempt_id: "attempt".into(),
        activity,
    });
    let condition = {
        let mut active = h.session.active_turn.lock().await;
        CompactReservation::reserve(&mut active, joined, rx)
    };
    let (turn_state, generation) = (Arc::clone(&condition.turn_state), condition.generation);
    assert!(turn_state.lock().await.pending_input.is_empty());
    assert!(
        !h.session
            .start_reserved_compact(h.turn("compact-1").await, held_compact(), condition)
            .await
    );
    assert!(h.starts().is_empty() && h.aborts.load(Ordering::SeqCst) == 0);
    assert_eq!(
        h.session.state.lock().await.last_started_turn_id.as_deref(),
        Some("original")
    );
    h.session
        .clear_compact_reservation(&turn_state, generation)
        .await;
    assert!(
        h.session.active_turn.lock().await.is_none(),
        "own empty slot cleared"
    );
    drop(activity_tx);
}

// (d2) pending-input-only veto: activity watcher subscribed after the input, so unchanged.
#[tokio::test]
async fn pending_input_only_vetoes_and_keeps_the_input() {
    let h = harness(None).await;
    let (_tx, rx) = async_channel::bounded(4);
    let slot = ActiveTurn::default();
    let turn_state = Arc::clone(&slot.turn_state);
    *h.session.active_turn.lock().await = Some(slot);
    h.session
        .input_queue
        .extend_pending_input_for_turn_state(turn_state.as_ref(), vec![user_text("keep")])
        .await;
    let joined = Arc::new(JoinedCompaction {
        turn_id: "original".into(),
        attempt_id: "attempt".into(),
        activity: h.session.input_queue.subscribe_activity(None).await.0,
    });
    assert!(matches!(joined.activity.has_changed(), Ok(false)));
    let condition = {
        let mut active = h.session.active_turn.lock().await;
        CompactReservation::reserve(&mut active, joined, rx)
    };
    let generation = condition.generation;
    assert!(Arc::ptr_eq(&condition.turn_state, &turn_state));
    assert!(
        !h.session
            .start_reserved_compact(h.turn("compact-1").await, held_compact(), condition)
            .await
    );
    assert!(h.starts().is_empty() && h.aborts.load(Ordering::SeqCst) == 0);
    h.session
        .clear_compact_reservation(&turn_state, generation)
        .await;
    let active = h.session.active_turn.lock().await;
    let turn = active.as_ref().expect("slot with queued input kept");
    assert!(turn.compact_reservation.is_none() && Arc::ptr_eq(&turn.turn_state, &turn_state));
    assert!(
        !turn_state.lock().await.pending_input.is_empty(),
        "input not dropped"
    );
}

// other-turn veto, also before contributors.
#[tokio::test]
async fn other_turn_vetoes_before_contributors() {
    let h = harness(None).await;
    let (_tx, rx) = async_channel::bounded(4);
    let condition = reserve_original(&h.session, rx).await;
    h.session.state.lock().await.last_started_turn_id = Some("other".into());
    assert!(
        !h.session
            .start_reserved_compact(h.turn("compact-1").await, held_compact(), condition)
            .await
    );
    assert!(h.starts().is_empty() && h.aborts.load(Ordering::SeqCst) == 0);
}

// (e) foreign reservation cleanup is untouched: other generation, and unmarked ordinary slot.
#[tokio::test]
async fn clear_compact_reservation_ignores_foreign_generation_and_ordinary_slot() {
    let h = harness(None).await;
    let (_tx, rx) = async_channel::bounded(4);
    let condition = reserve_original(&h.session, rx).await;
    h.session
        .clear_compact_reservation(&condition.turn_state, condition.generation + 1)
        .await;
    {
        let active = h.session.active_turn.lock().await;
        assert!(active.as_ref().is_some_and(|turn| {
            turn.compact_reservation
                .as_ref()
                .is_some_and(|t| t.generation == condition.generation)
        }));
    }
    let ordinary = ActiveTurn::default();
    let ordinary_state = Arc::clone(&ordinary.turn_state);
    *h.session.active_turn.lock().await = Some(ordinary);
    h.session
        .clear_compact_reservation(&ordinary_state, condition.generation)
        .await;
    assert!(
        h.session.active_turn.lock().await.is_some(),
        "unmarked slot must not clear"
    );
}
