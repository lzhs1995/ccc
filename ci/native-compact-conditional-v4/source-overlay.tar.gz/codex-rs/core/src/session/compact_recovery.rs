//! A one-use continuation of a joined conditional compaction interruption.
use super::session::Session;
use crate::codex_thread::CodexThread;
use crate::session::Submission;
use crate::state::ActiveTurn;
use crate::state::CompactSlotToken;
use crate::state::TurnState;
use crate::tasks::CompactTask;
use codex_protocol::error::CodexErr;
use codex_protocol::error::Result as CodexResult;
use codex_protocol::protocol::Op;
use std::sync::Arc;
use std::sync::atomic::AtomicU64;
use std::sync::atomic::Ordering;
use tokio::sync::Mutex;
use tokio::sync::watch;

pub(crate) struct JoinedCompaction {
    pub(crate) turn_id: String,
    pub(crate) attempt_id: String,
    pub(crate) activity: watch::Receiver<super::input_queue::InputQueueActivity>,
}

static NEXT_COMPACT_GENERATION: AtomicU64 = AtomicU64::new(1);

pub(crate) struct CompactReservation {
    pub(crate) turn_state: Arc<Mutex<TurnState>>,
    pub(crate) joined: Arc<JoinedCompaction>,
    pub(crate) submissions: async_channel::Receiver<Submission>,
    pub(crate) generation: u64,
    /// The preparer's handle on the slot token's cancellation record.
    pub(crate) cancelled: Arc<std::sync::Mutex<Option<codex_protocol::protocol::TurnAbortReason>>>,
}

impl CompactReservation {
    /// Installs an exclusive, uncommitted marker into an empty slot owned by this attempt.
    pub(crate) fn reserve(
        active: &mut Option<ActiveTurn>,
        joined: Arc<JoinedCompaction>,
        submissions: async_channel::Receiver<Submission>,
    ) -> Self {
        let generation = NEXT_COMPACT_GENERATION.fetch_add(1, Ordering::Relaxed);
        let turn = active.get_or_insert_with(ActiveTurn::default);
        let cancelled = Arc::new(std::sync::Mutex::new(None));
        turn.compact_reservation = Some(CompactSlotToken {
            attempt_id: joined.attempt_id.clone(),
            generation,
            committed: false,
            cancelled: Arc::clone(&cancelled),
        });
        Self {
            turn_state: Arc::clone(&turn.turn_state),
            joined,
            submissions,
            generation,
            cancelled,
        }
    }

    /// The slot is still this attempt's, by turn state identity and marker generation.
    pub(crate) fn owns(&self, active: Option<&ActiveTurn>) -> bool {
        active.is_some_and(|turn| {
            turn.task.is_none()
                && Arc::ptr_eq(&turn.turn_state, &self.turn_state)
                && turn.compact_reservation.as_ref().is_some_and(|token| {
                    token.generation == self.generation
                        && token.attempt_id == self.joined.attempt_id
                })
        })
    }

    /// Why a committed preparation lost its slot (Replaced when no taker recorded one).
    pub(crate) fn cancel_reason(&self) -> codex_protocol::protocol::TurnAbortReason {
        self.cancelled
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
            .clone()
            .unwrap_or(codex_protocol::protocol::TurnAbortReason::Replaced)
    }

    /// Veto inputs for the single committed decision (before any contributor).
    pub(crate) fn unchanged(&self, active: Option<&ActiveTurn>) -> bool {
        self.submissions.is_empty()
            && matches!(self.joined.activity.has_changed(), Ok(false))
            && self.owns(active)
            && active
                .and_then(|turn| turn.compact_reservation.as_ref())
                .is_some_and(|token| !token.committed)
    }
}

impl CodexThread {
    /// Consumes only the completion receipt for the named original interruption.
    pub async fn compact_after_interruption(
        &self,
        turn_id: &str,
        attempt_id: &str,
    ) -> CodexResult<Option<String>> {
        let (reply, result) = tokio::sync::oneshot::channel();
        let compact_turn_id = self
            .submit(Op::CompactAfterInterruption {
                turn_id: turn_id.to_owned(),
                attempt_id: attempt_id.to_owned(),
                reply,
            })
            .await?;
        result
            .await
            .map(|started| started.then_some(compact_turn_id))
            .map_err(|_| CodexErr::InternalAgentDied)
    }
}

impl Session {
    /// Compare the previous turn while the caller retains the active-turn reservation lock.
    pub(crate) async fn last_started_turn_matches(&self, expected: &str) -> bool {
        self.state.lock().await.last_started_turn_id.as_deref() == Some(expected)
    }

    #[expect(
        clippy::await_holding_invalid_type,
        reason = "compare original turn and reserve idle atomically"
    )]
    pub(crate) async fn compact_after_interruption(
        self: &Arc<Self>,
        turn_id: &str,
        attempt_id: &str,
        submissions: &async_channel::Receiver<Submission>,
        sub_id: String,
    ) -> bool {
        let Some(joined) = self
            .services
            .thread_extension_data
            .remove::<JoinedCompaction>()
        else {
            return false;
        };
        if joined.turn_id != turn_id
            || joined.attempt_id != attempt_id
            || submissions.len() != 0
            || !matches!(joined.activity.has_changed(), Ok(false))
        {
            return false;
        }
        let reservation = {
            let mut active = self.active_turn.lock().await;
            if active.is_some()
                || self.state.lock().await.last_started_turn_id.as_deref() != Some(turn_id)
                || self.input_queue.has_pending_mailbox_items().await
            {
                return false;
            }
            CompactReservation::reserve(&mut active, joined, submissions.clone())
        };
        let turn_context = self
            .new_turn_with_default_settings(sub_id, Default::default())
            .await;
        let turn_state = Arc::clone(&reservation.turn_state);
        let generation = reservation.generation;
        let started = self
            .start_reserved_compact(turn_context, CompactTask, reservation)
            .await;
        if !started {
            self.clear_compact_reservation(&turn_state, generation)
                .await;
            self.maybe_start_turn_for_pending_work().await;
        }
        started
    }

    /// Denial/cancellation cleanup touches only this attempt's still-empty slot.
    /// Queued input on that slot is kept: the marker is removed, the slot is not.
    #[expect(
        clippy::await_holding_invalid_type,
        reason = "slot identity and pending emptiness are checked atomically under the slot lock"
    )]
    pub(crate) async fn clear_compact_reservation(
        &self,
        turn_state: &Arc<Mutex<TurnState>>,
        generation: u64,
    ) {
        let mut active = self.active_turn.lock().await;
        let Some(turn) = active.as_mut() else {
            return;
        };
        if turn.task.is_some()
            || !Arc::ptr_eq(&turn.turn_state, turn_state)
            || turn
                .compact_reservation
                .as_ref()
                .is_none_or(|token| token.generation != generation)
        {
            return;
        }
        if turn.turn_state.lock().await.pending_input.is_empty() {
            *active = None;
        } else {
            turn.compact_reservation = None;
        }
    }
}

#[cfg(test)]
#[path = "compact_recovery_tests.rs"]
mod tests;
