use std::sync::Arc;
use std::sync::Weak;
use std::sync::atomic::AtomicBool;
use std::sync::atomic::Ordering;

use codex_core::StartIfIdleSubmission;
use codex_core::ThreadManager;
use codex_core::TurnInput;
use codex_core::TurnInputRequest;
use codex_core::TurnStartOptions;
use codex_protocol::ThreadId;
use codex_protocol::models::ResponseItem;
use codex_protocol::protocol::ThreadGoal;

use crate::accounting::BudgetLimitedGoalDisposition;
use crate::accounting::GoalAccountingState;
use crate::analytics::GoalAnalytics;
use crate::analytics::GoalEventAttribution;
use crate::events::GoalEventEmitter;
use crate::metrics::GoalMetrics;
use crate::steering::continuation_steering_item;
use crate::steering::objective_updated_steering_item;
use crate::tool::protocol_goal_from_state;
use tokio::sync::Semaphore;
use tokio::sync::SemaphorePermit;

#[derive(Clone)]
pub struct GoalRuntimeHandle {
    inner: Arc<GoalRuntimeInner>,
}

pub(crate) struct GoalRuntimeConfig {
    pub(crate) analytics: GoalAnalytics,
    pub(crate) enabled: bool,
    pub(crate) tools_available_for_thread: bool,
    pub(crate) tools_visible_for_thread: bool,
    pub(crate) root_accounting_state: Option<Arc<GoalAccountingState>>,
}

pub(crate) enum ActiveGoalStopReason {
    TurnError,
    UsageLimit,
    ExecutionUnavailable { expected_goal_id: String },
    EmptyResponse,
}

struct GoalRuntimeInner {
    thread_id: ThreadId,
    state_dbs: Arc<codex_state::StateRuntime>,
    analytics: GoalAnalytics,
    event_emitter: GoalEventEmitter,
    metrics: GoalMetrics,
    thread_manager: Weak<ThreadManager>,
    accounting_state: Arc<GoalAccountingState>,
    root_accounting_state: Option<Arc<GoalAccountingState>>,
    enabled: AtomicBool,
    tools_available_for_thread: bool,
    tools_visible_for_thread: bool,
    goal_state_lock: Semaphore,
    join_fence: std::sync::Mutex<JoinFenceSlot>,
}

pub(crate) struct AccountedGoalProgress {
    pub(crate) goal: ThreadGoal,
    /// The exact native row returned by the accounting UPDATE.
    pub(crate) state_goal: codex_state::ThreadGoal,
    pub(crate) goal_id: String,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct PreviousGoalSnapshot {
    pub goal_id: String,
    pub status: codex_state::ThreadGoalStatus,
    pub objective: String,
}

impl From<&codex_state::ThreadGoal> for PreviousGoalSnapshot {
    fn from(goal: &codex_state::ThreadGoal) -> Self {
        Self {
            goal_id: goal.goal_id.clone(),
            status: goal.status,
            objective: goal.objective.clone(),
        }
    }
}

impl std::fmt::Debug for GoalRuntimeHandle {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("GoalRuntimeHandle").finish_non_exhaustive()
    }
}

impl GoalRuntimeHandle {
    pub(crate) fn new(
        thread_id: ThreadId,
        state_dbs: Arc<codex_state::StateRuntime>,
        event_emitter: GoalEventEmitter,
        metrics: GoalMetrics,
        thread_manager: Weak<ThreadManager>,
        accounting_state: Arc<GoalAccountingState>,
        config: GoalRuntimeConfig,
    ) -> Self {
        Self {
            inner: Arc::new(GoalRuntimeInner {
                thread_id,
                state_dbs,
                analytics: config.analytics,
                event_emitter,
                metrics,
                thread_manager,
                accounting_state,
                root_accounting_state: config.root_accounting_state,
                enabled: AtomicBool::new(config.enabled),
                tools_available_for_thread: config.tools_available_for_thread,
                tools_visible_for_thread: config.tools_visible_for_thread,
                goal_state_lock: Semaphore::new(/*permits*/ 1),
                join_fence: std::sync::Mutex::new(JoinFenceSlot::default()),
            }),
        }
    }

    pub(crate) fn set_enabled(&self, enabled: bool) {
        self.inner.enabled.store(enabled, Ordering::Relaxed);
    }

    pub(crate) fn is_enabled(&self) -> bool {
        self.inner.enabled.load(Ordering::Relaxed)
    }

    pub(crate) fn tools_visible(&self) -> bool {
        self.is_enabled() && self.inner.tools_visible_for_thread
    }

    pub(crate) fn tools_available(&self) -> bool {
        self.is_enabled() && self.inner.tools_available_for_thread
    }

    pub(crate) fn thread_id(&self) -> ThreadId {
        self.inner.thread_id
    }

    pub(crate) fn accounting_state(&self) -> Arc<GoalAccountingState> {
        Arc::clone(&self.inner.accounting_state)
    }

    pub(crate) fn root_accounting_state(&self) -> Option<Arc<GoalAccountingState>> {
        self.inner.root_accounting_state.clone()
    }

    pub(crate) async fn clear_pending_turn_start_options(&self) {
        let Some(thread_manager) = self.inner.thread_manager.upgrade() else {
            return;
        };
        let Ok(thread) = thread_manager.get_thread(self.inner.thread_id).await else {
            return;
        };
        thread.thread_extension_data().remove::<TurnStartOptions>();
    }

    /// Arms the one attempt-bound join fence. The caller must hold `goal_state_permit`
    /// and have already consumed the original CCC claim; `pre` is the exact native row
    /// that its Goal check accepted. Never supersedes another pending fence.
    pub fn arm_join_fence(
        &self,
        _permit: &SemaphorePermit<'_>,
        turn_id: &str,
        attempt_id: &str,
        pre: codex_state::ThreadGoal,
    ) -> Result<(), String> {
        self.join_fence_slot().arm(turn_id, attempt_id, pre)
    }

    /// Takes the fence result once, under the caller's `goal_state_permit`. A missing,
    /// foreign or bypassed fence is an error; the caller then denies.
    pub fn finish_join_fence(
        &self,
        _permit: &SemaphorePermit<'_>,
        turn_id: &str,
        attempt_id: &str,
    ) -> Result<JoinAccounting, String> {
        self.join_fence_slot().finish(turn_id, attempt_id)
    }

    /// Releases this attempt's fence on any exit that did not `finish` it (UNKNOWN or error),
    /// so one failed attempt can never deny every later attempt on this thread. Only the
    /// exact turn/attempt is released; a concurrent abort's late complete/bypass then no-ops.
    pub fn abandon_join_fence(&self, turn_id: &str, attempt_id: &str) {
        self.join_fence_slot().abandon(turn_id, attempt_id);
    }

    fn join_fence_slot(&self) -> std::sync::MutexGuard<'_, JoinFenceSlot> {
        self.inner
            .join_fence
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
    }

    /// Turn-abort accounting. Only a fence armed for this exact turn is resolved, and
    /// only while this abort itself holds `goal_state_permit` (`try_acquire`: the
    /// app-server may hold it across the join and must never wait on us). The fenced
    /// UPDATE is a full-row CAS against the pinned pre-join row, so any other write
    /// since arming turns into an ordinary, bypassed accounting.
    pub(crate) async fn account_turn_abort(&self, turn_id: &str) -> Result<(), String> {
        let event_id = format!("{turn_id}:turn-abort");
        // The generation names exactly which arm this abort serves; a late transition from
        // an abandoned attempt can never land on a newer fence for the same turn.
        let begun = self.join_fence_slot().begin(turn_id);
        let Some((generation, pre)) = begun else {
            return self.account_turn_abort_ordinary(turn_id, &event_id).await;
        };
        let Ok(_permit) = self.inner.goal_state_lock.try_acquire() else {
            self.join_fence_slot()
                .bypass(generation, "turn abort could not hold the Goal permit");
            return self.account_turn_abort_ordinary(turn_id, &event_id).await;
        };
        let fenced = self
            .account_active_goal_progress_expecting(
                turn_id,
                &event_id,
                codex_state::GoalAccountingMode::ActiveOnly,
                BudgetLimitedGoalDisposition::ClearActive,
                Some(&pre),
            )
            .await;
        match fenced {
            Ok(Some(progress)) => {
                self.join_fence_slot()
                    .complete(generation, pre, progress.state_goal);
                Ok(())
            }
            Ok(None) => {
                // Zero delta, or a CAS miss after another write. Account the latter the
                // ordinary way so usage is never lost, and never pass it off as join.
                match self
                    .account_turn_abort_ordinary_progress(turn_id, &event_id)
                    .await
                {
                    Ok(None) => {
                        self.join_fence_slot().rearm(generation, pre);
                        Ok(())
                    }
                    Ok(Some(_)) => {
                        self.join_fence_slot()
                            .bypass(generation, "Goal row changed before join accounting");
                        Ok(())
                    }
                    Err(err) => {
                        self.join_fence_slot()
                            .bypass(generation, "join accounting failed");
                        Err(err)
                    }
                }
            }
            Err(err) => {
                self.join_fence_slot()
                    .bypass(generation, "join accounting failed");
                Err(err)
            }
        }
    }

    async fn account_turn_abort_ordinary_progress(
        &self,
        turn_id: &str,
        event_id: &str,
    ) -> Result<Option<AccountedGoalProgress>, String> {
        self.account_active_goal_progress(
            turn_id,
            event_id,
            codex_state::GoalAccountingMode::ActiveOnly,
            BudgetLimitedGoalDisposition::ClearActive,
        )
        .await
    }

    async fn account_turn_abort_ordinary(
        &self,
        turn_id: &str,
        event_id: &str,
    ) -> Result<(), String> {
        self.account_turn_abort_ordinary_progress(turn_id, event_id)
            .await
            .map(|_| ())
    }

    /// Serializes a recovery transaction with external Goal mutations.
    pub async fn goal_state_permit(&self) -> Result<SemaphorePermit<'_>, String> {
        self.inner
            .goal_state_lock
            .acquire()
            .await
            .map_err(|err| err.to_string())
    }

    pub async fn prepare_external_goal_mutation(&self) -> Result<(), String> {
        if !self.is_enabled() {
            return Ok(());
        }
        // Invalidate the old turn before the persisted objective/status changes.
        self.inner.accounting_state.reset_empty_responses();

        if let Some(turn_id) = self.inner.accounting_state.current_turn_id() {
            self.account_active_goal_progress(
                turn_id.as_str(),
                &format!("{turn_id}:external-goal-mutation"),
                codex_state::GoalAccountingMode::ActiveOnly,
                BudgetLimitedGoalDisposition::ClearActive,
            )
            .await?;
            return Ok(());
        }

        self.account_idle_goal_progress(
            &format!("{}:external-goal-mutation", self.inner.thread_id),
            codex_state::GoalAccountingMode::ActiveOnly,
            BudgetLimitedGoalDisposition::ClearActive,
        )
        .await?;
        Ok(())
    }

    pub async fn apply_external_goal_set(
        &self,
        goal: codex_state::ThreadGoal,
        previous_goal: Option<PreviousGoalSnapshot>,
    ) -> Result<(), String> {
        if !self.is_enabled() {
            return Ok(());
        }

        self.inner.accounting_state.reset_empty_responses();
        let replaced_existing_goal = previous_goal
            .as_ref()
            .is_some_and(|previous_goal| previous_goal.goal_id != goal.goal_id);
        if previous_goal.is_none() || replaced_existing_goal {
            self.inner.metrics.record_created();
            self.inner
                .analytics
                .created(&goal, GoalEventAttribution::NoTurn);
        }
        let previous_status = previous_goal
            .as_ref()
            .and_then(|previous_goal| (!replaced_existing_goal).then_some(previous_goal.status));
        self.inner
            .metrics
            .record_resumed_if_status_changed(previous_status, goal.status);
        self.inner
            .metrics
            .record_terminal_if_status_changed(previous_status, &goal);
        self.inner
            .analytics
            .status_changed(&goal, previous_status, GoalEventAttribution::NoTurn);
        let objective_changed = previous_goal.as_ref().is_some_and(|previous_goal| {
            !replaced_existing_goal && previous_goal.objective != goal.objective
        });
        match goal.status {
            codex_state::ThreadGoalStatus::Active => {
                if self.inner.accounting_state.current_turn_id().is_some() {
                    let _ = self
                        .inner
                        .accounting_state
                        .mark_current_turn_goal_active(goal.goal_id.clone());
                } else {
                    self.inner
                        .accounting_state
                        .mark_idle_goal_active(goal.goal_id.clone());
                }
                if objective_changed {
                    let item = objective_updated_steering_item(&protocol_goal_from_state(goal));
                    self.inject_active_turn_steering(item).await;
                }
                self.continue_if_idle().await?;
            }
            codex_state::ThreadGoalStatus::BudgetLimited => {
                if self.inner.accounting_state.current_turn_id().is_none() {
                    self.inner.accounting_state.clear_active_goal();
                }
            }
            codex_state::ThreadGoalStatus::Paused
            | codex_state::ThreadGoalStatus::Blocked
            | codex_state::ThreadGoalStatus::UsageLimited
            | codex_state::ThreadGoalStatus::Complete => {
                self.inner.accounting_state.clear_active_goal();
            }
        }
        Ok(())
    }

    pub async fn apply_external_goal_clear(
        &self,
        goal: codex_state::ThreadGoal,
    ) -> Result<(), String> {
        if !self.is_enabled() {
            return Ok(());
        }

        self.inner.analytics.cleared(&goal);
        self.inner.accounting_state.clear_active_goal();
        Ok(())
    }

    pub async fn usage_limit_active_goal_for_turn(&self, turn_id: &str) -> Result<(), String> {
        self.stop_active_goal_for_turn(turn_id, ActiveGoalStopReason::UsageLimit)
            .await
    }

    /// Accounts the ending turn and stops its active goal after an error or repeated empty output.
    pub(crate) async fn stop_active_goal_for_turn(
        &self,
        turn_id: &str,
        reason: ActiveGoalStopReason,
    ) -> Result<(), String> {
        if !self.is_enabled() {
            return Ok(());
        }

        // Hold this through accounting and the status update so external goal
        // mutations and idle continuation cannot interleave between them.
        let _goal_state_permit = self.goal_state_permit().await?;
        let Some(accounting_goal_id) = self
            .inner
            .accounting_state
            .current_active_goal_id_for_turn(turn_id)
        else {
            return Ok(());
        };
        if let ActiveGoalStopReason::ExecutionUnavailable { expected_goal_id } = &reason
            && accounting_goal_id != *expected_goal_id
        {
            return Ok(());
        }

        let (event_name, status, expected_goal_id) = match reason {
            ActiveGoalStopReason::TurnError => {
                ("turn-error", codex_state::ThreadGoalStatus::Blocked, None)
            }
            ActiveGoalStopReason::UsageLimit => (
                "usage-limit",
                codex_state::ThreadGoalStatus::UsageLimited,
                None,
            ),
            ActiveGoalStopReason::EmptyResponse => {
                let Some(expected_goal_id) =
                    self.inner.accounting_state.empty_response_goal(turn_id)
                else {
                    return Ok(());
                };
                if accounting_goal_id != expected_goal_id {
                    return Ok(());
                }
                (
                    "empty-response",
                    codex_state::ThreadGoalStatus::Blocked,
                    Some(expected_goal_id),
                )
            }
            ActiveGoalStopReason::ExecutionUnavailable { expected_goal_id } => (
                "execution-unavailable",
                codex_state::ThreadGoalStatus::Blocked,
                Some(expected_goal_id),
            ),
        };
        self.account_active_goal_progress(
            turn_id,
            &format!("{turn_id}:{event_name}-progress"),
            codex_state::GoalAccountingMode::ActiveOnly,
            BudgetLimitedGoalDisposition::ClearActive,
        )
        .await?;

        let Some(active_goal) = self
            .inner
            .state_dbs
            .thread_goals()
            .get_thread_goal(self.thread_id())
            .await
            .map_err(|err| err.to_string())?
        else {
            self.inner.accounting_state.clear_active_goal();
            return Ok(());
        };
        if expected_goal_id
            .as_ref()
            .is_some_and(|expected_goal_id| active_goal.goal_id != *expected_goal_id)
        {
            return Ok(());
        }
        let can_stop = active_goal.status == codex_state::ThreadGoalStatus::Active
            || (active_goal.status == codex_state::ThreadGoalStatus::BudgetLimited
                && status == codex_state::ThreadGoalStatus::UsageLimited);
        if !can_stop {
            self.inner.accounting_state.clear_active_goal();
            return Ok(());
        }
        let previous_status = Some(active_goal.status);
        let Some(goal) = self
            .inner
            .state_dbs
            .thread_goals()
            .update_thread_goal(
                self.thread_id(),
                codex_state::GoalUpdate {
                    objective: None,
                    status: Some(status),
                    token_budget: None,
                    expected_goal_id: Some(active_goal.goal_id),
                },
            )
            .await
            .map_err(|err| err.to_string())?
        else {
            return Ok(());
        };
        self.inner
            .metrics
            .record_terminal_if_status_changed(previous_status, &goal);
        self.inner.analytics.status_changed(
            &goal,
            previous_status,
            GoalEventAttribution::Turn(turn_id),
        );
        self.inner.accounting_state.clear_active_goal();
        let goal = protocol_goal_from_state(goal);
        self.inner.event_emitter.thread_goal_updated(
            format!("{turn_id}:{event_name}"),
            Some(turn_id.to_string()),
            goal,
        );
        Ok(())
    }

    pub async fn restore_after_resume(&self) -> Result<(), String> {
        if !self.is_enabled() {
            return Ok(());
        }

        let goal = self
            .inner
            .state_dbs
            .thread_goals()
            .get_thread_goal(self.thread_id())
            .await
            .map_err(|err| err.to_string())?;
        match goal {
            Some(goal) if goal.status == codex_state::ThreadGoalStatus::Active => {
                self.inner
                    .accounting_state
                    .mark_idle_goal_active(goal.goal_id);
                self.inner.metrics.record_resumed();
            }
            Some(_) | None => self.inner.accounting_state.clear_active_goal(),
        }
        Ok(())
    }

    pub(crate) async fn continue_if_idle(&self) -> Result<(), String> {
        if !self.tools_available() {
            self.inner.accounting_state.clear_active_goal();
            return Ok(());
        }
        // Hold this through the read/start window so external set/clear cannot
        // change the goal after we read it but before the continuation launches.
        let _goal_state_permit = self.goal_state_permit().await?;

        if self
            .inner
            .state_dbs
            .thread_goals()
            .has_thread_goal_continuation_deferral(self.thread_id())
            .await
            .map_err(|err| err.to_string())?
        {
            return Ok(());
        }

        let Some(thread_manager) = self.inner.thread_manager.upgrade() else {
            tracing::debug!("skipping goal continuation because thread manager is unavailable");
            return Ok(());
        };
        let Ok(thread) = thread_manager.get_thread(self.inner.thread_id).await else {
            tracing::debug!("skipping goal continuation because live thread is unavailable");
            return Ok(());
        };

        let Some(goal) = self
            .inner
            .state_dbs
            .thread_goals()
            .get_thread_goal(self.thread_id())
            .await
            .map_err(|err| err.to_string())?
        else {
            self.inner.accounting_state.clear_active_goal();
            return Ok(());
        };
        if goal.status != codex_state::ThreadGoalStatus::Active {
            self.inner.accounting_state.clear_active_goal();
            return Ok(());
        }
        let start_options = thread
            .thread_extension_data()
            .get::<TurnStartOptions>()
            .map(|options| options.as_ref().clone())
            .unwrap_or_default();
        let item = continuation_steering_item(
            &protocol_goal_from_state(goal),
            thread.config().await.update_plan_enabled,
        );

        match thread
            .start_turn_if_idle(
                TurnInputRequest::new(TurnInput::ResponseItem(item)).on_start(TurnStartOptions {
                    turn_trigger: Some("goal".to_string()),
                    ..start_options
                }),
            )
            .await
        {
            Ok(StartIfIdleSubmission::Started { turn_id }) => {
                // Turn-stop evaluation takes the same permit, so even a fast response
                // cannot finish before this host-admitted continuation is identified.
                self.inner.accounting_state.mark_goal_continuation(turn_id);
            }
            Ok(StartIfIdleSubmission::NotSubmitted { reason }) => {
                tracing::debug!(
                    ?reason,
                    "skipping goal continuation because automatic idle work was rejected"
                );
            }
            Err(error) => {
                tracing::debug!(
                    %error,
                    "skipping goal continuation because turn input submission failed"
                );
            }
        }

        let current_turn_is_goal_active = self
            .inner
            .accounting_state
            .current_turn_id()
            .is_some_and(|turn_id| {
                self.inner
                    .accounting_state
                    .current_active_goal_id_for_turn(turn_id.as_str())
                    .is_some()
            });
        if !current_turn_is_goal_active {
            self.inner
                .accounting_state
                .reset_idle_progress_baseline_and_clear_active_goal();
        }
        Ok(())
    }

    pub(crate) async fn inject_active_turn_steering(&self, item: ResponseItem) {
        let Some(thread_manager) = self.inner.thread_manager.upgrade() else {
            tracing::debug!("skipping goal steering because thread manager is unavailable");
            return;
        };
        let Ok(thread) = thread_manager.get_thread(self.inner.thread_id).await else {
            tracing::debug!("skipping goal steering because live thread is unavailable");
            return;
        };
        if thread.inject_if_running(vec![item]).await.is_err() {
            tracing::debug!("skipping goal steering because no turn is active");
        }
    }

    pub(crate) async fn account_active_goal_progress(
        &self,
        turn_id: &str,
        event_id: &str,
        mode: codex_state::GoalAccountingMode,
        budget_limited_goal_disposition: BudgetLimitedGoalDisposition,
    ) -> Result<Option<AccountedGoalProgress>, String> {
        self.account_active_goal_progress_expecting(
            turn_id,
            event_id,
            mode,
            budget_limited_goal_disposition,
            /*expected_row*/ None,
        )
        .await
    }

    async fn account_active_goal_progress_expecting(
        &self,
        turn_id: &str,
        event_id: &str,
        mode: codex_state::GoalAccountingMode,
        budget_limited_goal_disposition: BudgetLimitedGoalDisposition,
        expected_row: Option<&codex_state::ThreadGoal>,
    ) -> Result<Option<AccountedGoalProgress>, String> {
        let accounting = self.accounting_state();
        let _accounting_permit = accounting
            .progress_accounting_permit()
            .await
            .map_err(|err| err.to_string())?;
        let Some(snapshot) = accounting.progress_snapshot(turn_id) else {
            return Ok(None);
        };
        let previous_status = self
            .current_goal_status_for_metrics(Some(snapshot.expected_goal_id.as_str()))
            .await?;
        let outcome = self
            .inner
            .state_dbs
            .thread_goals()
            .account_thread_goal_usage_expecting(
                self.thread_id(),
                snapshot.time_delta_seconds,
                snapshot.token_delta,
                mode,
                Some(snapshot.expected_goal_id.as_str()),
                expected_row,
            )
            .await
            .map_err(|err| err.to_string())?;
        Ok(match outcome {
            codex_state::GoalAccountingOutcome::Updated(goal) => {
                let goal_id = goal.goal_id.clone();
                self.inner
                    .metrics
                    .record_terminal_if_status_changed(previous_status, &goal);
                self.inner
                    .analytics
                    .usage_accounted(&goal, GoalEventAttribution::Turn(turn_id));
                self.inner.analytics.status_changed(
                    &goal,
                    previous_status,
                    GoalEventAttribution::Turn(turn_id),
                );
                accounting.mark_progress_accounted_for_status(
                    turn_id,
                    &snapshot,
                    goal.status,
                    budget_limited_goal_disposition,
                );
                let state_goal = goal.clone();
                let goal = protocol_goal_from_state(goal);
                self.inner.event_emitter.thread_goal_updated(
                    event_id.to_string(),
                    Some(turn_id.to_string()),
                    goal.clone(),
                );
                Some(AccountedGoalProgress {
                    goal,
                    goal_id,
                    state_goal,
                })
            }
            codex_state::GoalAccountingOutcome::Unchanged(_) => None,
        })
    }

    async fn account_idle_goal_progress(
        &self,
        event_id: &str,
        mode: codex_state::GoalAccountingMode,
        budget_limited_goal_disposition: BudgetLimitedGoalDisposition,
    ) -> Result<Option<AccountedGoalProgress>, String> {
        let accounting = self.accounting_state();
        let _accounting_permit = accounting
            .progress_accounting_permit()
            .await
            .map_err(|err| err.to_string())?;
        let Some(snapshot) = accounting.idle_progress_snapshot() else {
            return Ok(None);
        };
        let previous_status = self
            .current_goal_status_for_metrics(Some(snapshot.expected_goal_id.as_str()))
            .await?;
        let outcome = self
            .inner
            .state_dbs
            .thread_goals()
            .account_thread_goal_usage(
                self.thread_id(),
                snapshot.time_delta_seconds,
                snapshot.token_delta,
                mode,
                Some(snapshot.expected_goal_id.as_str()),
            )
            .await
            .map_err(|err| err.to_string())?;
        Ok(match outcome {
            codex_state::GoalAccountingOutcome::Updated(goal) => {
                let goal_id = goal.goal_id.clone();
                self.inner
                    .metrics
                    .record_terminal_if_status_changed(previous_status, &goal);
                self.inner
                    .analytics
                    .usage_accounted(&goal, GoalEventAttribution::NoTurn);
                self.inner.analytics.status_changed(
                    &goal,
                    previous_status,
                    GoalEventAttribution::NoTurn,
                );
                accounting.mark_idle_progress_accounted_for_status(
                    &snapshot,
                    goal.status,
                    budget_limited_goal_disposition,
                );
                let state_goal = goal.clone();
                let goal = protocol_goal_from_state(goal);
                self.inner.event_emitter.thread_goal_updated(
                    event_id.to_string(),
                    /*turn_id*/ None,
                    goal.clone(),
                );
                Some(AccountedGoalProgress {
                    goal,
                    goal_id,
                    state_goal,
                })
            }
            codex_state::GoalAccountingOutcome::Unchanged(_) => {
                accounting.reset_idle_progress_baseline_and_clear_active_goal();
                None
            }
        })
    }

    async fn current_goal_status_for_metrics(
        &self,
        expected_goal_id: Option<&str>,
    ) -> Result<Option<codex_state::ThreadGoalStatus>, String> {
        let goal = self
            .inner
            .state_dbs
            .thread_goals()
            .get_thread_goal(self.thread_id())
            .await
            .map_err(|err| err.to_string())?;
        Ok(goal.and_then(|goal| {
            expected_goal_id
                .is_none_or(|expected_goal_id| goal.goal_id == expected_goal_id)
                .then_some(goal.status)
        }))
    }
}

/// Typed one-use result of the original turn's own join accounting.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct JoinAccountingReceipt {
    pub turn_id: String,
    pub attempt_id: String,
    /// Exact native row the fence pinned (the CAS expectation).
    pub before: codex_state::ThreadGoal,
    /// Exact native row returned by that same accounting UPDATE.
    pub after: codex_state::ThreadGoal,
}

/// What the post-join gate may rely on. There is no empty or synthetic receipt.
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum JoinAccounting {
    /// The original turn accounted nothing (zero delta) or did not abort yet.
    NotAccounted,
    Accounted(JoinAccountingReceipt),
}

#[derive(Default)]
enum JoinFenceState {
    #[default]
    Empty,
    Armed {
        pre: codex_state::ThreadGoal,
    },
    Accounting,
    Done(JoinAccountingReceipt),
    Bypassed(&'static str),
}

/// At most one attempt-bound fence per thread runtime. Every arm gets a fresh
/// generation; abort-side transitions carry the generation they began with, and
/// request-side transitions carry the exact turn/attempt, so neither can touch a
/// newer fence armed later for the same turn.
#[derive(Default)]
pub(crate) struct JoinFenceSlot {
    generation: u64,
    turn_id: String,
    attempt_id: String,
    state: JoinFenceState,
}

impl JoinFenceSlot {
    pub(crate) fn arm(
        &mut self,
        turn_id: &str,
        attempt_id: &str,
        pre: codex_state::ThreadGoal,
    ) -> Result<(), String> {
        if !matches!(self.state, JoinFenceState::Empty) {
            return Err("another Goal join fence is pending".into());
        }
        self.generation = self.generation.wrapping_add(1);
        self.turn_id = turn_id.to_string();
        self.attempt_id = attempt_id.to_string();
        self.state = JoinFenceState::Armed { pre };
        Ok(())
    }

    /// Armed fence for exactly this turn moves to Accounting and yields its generation.
    pub(crate) fn begin(&mut self, turn_id: &str) -> Option<(u64, codex_state::ThreadGoal)> {
        if self.turn_id != turn_id {
            return None;
        }
        match std::mem::replace(&mut self.state, JoinFenceState::Accounting) {
            JoinFenceState::Armed { pre } => Some((self.generation, pre)),
            other => {
                self.state = other;
                None
            }
        }
    }

    fn accounting(&self, generation: u64) -> bool {
        self.generation == generation && matches!(self.state, JoinFenceState::Accounting)
    }

    pub(crate) fn rearm(&mut self, generation: u64, pre: codex_state::ThreadGoal) {
        if self.accounting(generation) {
            self.state = JoinFenceState::Armed { pre };
        }
    }

    pub(crate) fn complete(
        &mut self,
        generation: u64,
        before: codex_state::ThreadGoal,
        after: codex_state::ThreadGoal,
    ) {
        if self.accounting(generation) {
            self.state = JoinFenceState::Done(JoinAccountingReceipt {
                turn_id: self.turn_id.clone(),
                attempt_id: self.attempt_id.clone(),
                before,
                after,
            });
        }
    }

    pub(crate) fn bypass(&mut self, generation: u64, reason: &'static str) {
        if self.generation == generation && !matches!(self.state, JoinFenceState::Empty) {
            self.state = JoinFenceState::Bypassed(reason);
        }
    }

    fn owned_by(&self, turn_id: &str, attempt_id: &str) -> bool {
        !matches!(self.state, JoinFenceState::Empty)
            && self.turn_id == turn_id
            && self.attempt_id == attempt_id
    }

    /// Request-side release for every exit that did not `finish`. The generation is kept,
    /// so a late abort of this attempt can never match the next arm.
    pub(crate) fn abandon(&mut self, turn_id: &str, attempt_id: &str) {
        if self.owned_by(turn_id, attempt_id) {
            self.state = JoinFenceState::Empty;
        }
    }

    /// One use: any outcome empties the slot, so a receipt can never be replayed.
    pub(crate) fn finish(
        &mut self,
        turn_id: &str,
        attempt_id: &str,
    ) -> Result<JoinAccounting, String> {
        if self.turn_id != turn_id || self.attempt_id != attempt_id {
            return Err("Goal join fence belongs to another turn or attempt".into());
        }
        match std::mem::take(&mut self.state) {
            JoinFenceState::Armed { .. } => Ok(JoinAccounting::NotAccounted),
            JoinFenceState::Done(receipt) => Ok(JoinAccounting::Accounted(receipt)),
            JoinFenceState::Accounting => Err("Goal join accounting still in progress".into()),
            JoinFenceState::Bypassed(reason) => Err(reason.into()),
            JoinFenceState::Empty => Err("Goal join receipt lost or already used".into()),
        }
    }
}

#[cfg(test)]
#[path = "join_fence_tests.rs"]
mod join_fence_tests;
