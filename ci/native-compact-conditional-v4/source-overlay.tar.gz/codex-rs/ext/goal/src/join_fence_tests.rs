use super::*;
use pretty_assertions::assert_eq;

fn row(goal_id: &str, tokens: i64, updated_ms: i64) -> codex_state::ThreadGoal {
    codex_state::ThreadGoal {
        thread_id: ThreadId::from_string("00000000-0000-0000-0000-000000000123").unwrap(),
        goal_id: goal_id.into(),
        objective: "finish".into(),
        status: codex_state::ThreadGoalStatus::Active,
        token_budget: None,
        tokens_used: tokens,
        time_used_seconds: 9,
        created_at: chrono::DateTime::from_timestamp_millis(1_000).unwrap(),
        updated_at: chrono::DateTime::from_timestamp_millis(updated_ms).unwrap(),
    }
}

#[test]
fn fenced_accounting_yields_one_receipt_for_the_exact_attempt() {
    let mut slot = JoinFenceSlot::default();
    slot.arm("turn-1", "attempt-1", row("g", 5, 2_000)).unwrap();
    assert!(slot.arm("turn-2", "attempt-2", row("g", 5, 2_000)).is_err());
    // A different turn's abort never consumes this fence.
    assert_eq!(slot.begin("turn-other"), None);
    let (generation, pre) = slot.begin("turn-1").unwrap();
    assert_eq!(slot.begin("turn-1"), None);
    slot.complete(generation, pre.clone(), row("g", 8, 2_500));
    assert!(slot.finish("turn-1", "attempt-2").is_err());
    assert_eq!(
        slot.finish("turn-1", "attempt-1").unwrap(),
        JoinAccounting::Accounted(JoinAccountingReceipt {
            turn_id: "turn-1".into(),
            attempt_id: "attempt-1".into(),
            before: pre,
            after: row("g", 8, 2_500),
        })
    );
    // One use: the receipt cannot be replayed, and a new attempt may arm.
    assert!(slot.finish("turn-1", "attempt-1").is_err());
    slot.arm("turn-2", "attempt-2", row("g", 8, 2_500)).unwrap();
}

#[test]
fn late_abort_of_an_abandoned_attempt_never_completes_a_newer_same_turn_fence() {
    for late in ["complete", "rearm", "bypass"] {
        let mut slot = JoinFenceSlot::default();
        slot.arm("turn-1", "attempt-1", row("g", 5, 2_000)).unwrap();
        let (old, pre) = slot.begin("turn-1").unwrap();
        // The request exits (UNKNOWN); its guard abandons only its own attempt.
        slot.abandon("turn-1", "attempt-other");
        assert!(
            slot.arm("turn-1", "attempt-2", pre.clone()).is_err(),
            "{late}: foreign abandon ignored"
        );
        slot.abandon("turn-1", "attempt-1");
        // The next attempt on the SAME turn arms, and its own abort begins accounting.
        slot.arm("turn-1", "attempt-2", pre.clone()).unwrap();
        let (new, _) = slot.begin("turn-1").unwrap();
        assert_ne!(old, new);
        match late {
            "complete" => slot.complete(old, pre.clone(), row("g", 99, 9_000)),
            "rearm" => slot.rearm(old, pre.clone()),
            _ => slot.bypass(old, "join accounting failed"),
        }
        // The old abort's transition did not touch the newer fence: it is still accounting.
        assert_eq!(
            slot.finish("turn-1", "attempt-2").unwrap_err(),
            "Goal join accounting still in progress",
            "{late}"
        );
    }
}

#[test]
fn newer_generation_completes_only_with_its_own_rows() {
    let mut slot = JoinFenceSlot::default();
    slot.arm("turn-1", "attempt-1", row("g", 5, 2_000)).unwrap();
    let (old, pre) = slot.begin("turn-1").unwrap();
    slot.abandon("turn-1", "attempt-1");
    slot.arm("turn-1", "attempt-2", pre.clone()).unwrap();
    let (new, pre2) = slot.begin("turn-1").unwrap();
    slot.complete(old, pre.clone(), row("g", 99, 9_000));
    slot.complete(new, pre2.clone(), row("g", 8, 2_500));
    assert_eq!(
        slot.finish("turn-1", "attempt-2").unwrap(),
        JoinAccounting::Accounted(JoinAccountingReceipt {
            turn_id: "turn-1".into(),
            attempt_id: "attempt-2".into(),
            before: pre2,
            after: row("g", 8, 2_500),
        })
    );
}

#[test]
fn unaccounted_bypassed_and_in_progress_fences_never_pass_as_join_accounting() {
    let mut slot = JoinFenceSlot::default();
    slot.arm("turn-1", "attempt-1", row("g", 5, 2_000)).unwrap();
    assert_eq!(
        slot.finish("turn-1", "attempt-1").unwrap(),
        JoinAccounting::NotAccounted
    );

    slot.arm("turn-1", "attempt-1", row("g", 5, 2_000)).unwrap();
    slot.begin("turn-1").unwrap();
    assert!(
        slot.finish("turn-1", "attempt-1").is_err(),
        "in-progress accepted"
    );

    slot.arm("turn-1", "attempt-1", row("g", 5, 2_000)).unwrap();
    let (generation, pre) = slot.begin("turn-1").unwrap();
    slot.rearm(generation, pre.clone());
    assert_eq!(
        slot.finish("turn-1", "attempt-1").unwrap(),
        JoinAccounting::NotAccounted
    );

    slot.arm("turn-1", "attempt-1", pre).unwrap();
    let (generation, _) = slot.begin("turn-1").unwrap();
    slot.bypass(generation, "Goal row changed before join accounting");
    // A completion after a bypass is ignored: bypass is terminal for the attempt.
    slot.complete(generation, row("g", 5, 2_000), row("g", 8, 2_500));
    assert_eq!(
        slot.finish("turn-1", "attempt-1").unwrap_err(),
        "Goal row changed before join accounting"
    );
    assert!(
        slot.finish("turn-1", "attempt-1").is_err(),
        "lost receipt accepted"
    );
}
