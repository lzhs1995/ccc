use super::*;
use crate::HttpClientBuilder;
use pretty_assertions::assert_eq;
use std::io::Read;
use std::io::Write;
use std::net::TcpListener;
use std::sync::Mutex;
use std::time::Duration;

#[derive(Debug, PartialEq, Eq)]
enum Event {
    Dispatch(String, Option<String>),
    Opaque(String),
}

fn recorder(events: Arc<Mutex<Vec<Event>>>) -> impl Fn(RequestObservation<'_>) + Send + Sync {
    move |event| {
        events.lock().unwrap().push(match event {
            RequestObservation::Dispatch { headers, url } => Event::Dispatch(
                url.to_owned(),
                headers
                    .get("authorization")
                    .map(|h| h.to_str().unwrap().to_owned()),
            ),
            RequestObservation::OpaqueRedirect { url } => Event::Opaque(url.to_owned()),
        });
    }
}

// Every response closes its socket; no external network or real credentials.
fn server(responses: Vec<String>) -> (String, std::thread::JoinHandle<Vec<String>>) {
    let listener = TcpListener::bind("127.0.0.1:0").unwrap();
    let url = format!("http://{}/", listener.local_addr().unwrap());
    let worker = std::thread::spawn(move || {
        responses
            .into_iter()
            .map(|response| {
                let (mut stream, _) = listener.accept().unwrap();
                stream
                    .set_read_timeout(Some(Duration::from_secs(5)))
                    .unwrap();
                let mut request = Vec::new();
                while !request.ends_with(b"\r\n\r\n") {
                    let mut byte = [0];
                    stream.read_exact(&mut byte).unwrap();
                    request.push(byte[0]);
                }
                stream.write_all(response.as_bytes()).unwrap();
                String::from_utf8(request).unwrap()
            })
            .collect()
    });
    (url, worker)
}

const OK: &str = "HTTP/1.1 200 OK\r\nContent-Length: 0\r\nConnection: close\r\n\r\n";

#[tokio::test]
async fn concurrent_requests_keep_separate_credentials_and_scope_ends() {
    let (url, worker) = server(vec![OK.into(), OK.into(), OK.into()]);
    let client = HttpClientBuilder::new().build_direct().unwrap();
    let a = Arc::new(Mutex::new(Vec::new()));
    let b = Arc::new(Mutex::new(Vec::new()));
    let (ra, rb) = tokio::join!(
        with_request_observer(
            recorder(a.clone()),
            client
                .get(&url)
                .header("authorization", "Bearer fake-A")
                .send()
        ),
        with_request_observer(
            recorder(b.clone()),
            client
                .get(&url)
                .header("authorization", "Bearer fake-B")
                .send()
        ),
    );
    ra.unwrap();
    rb.unwrap();
    client.get(&url).send().await.unwrap();
    let requests = worker.join().unwrap();
    assert_eq!(
        requests
            .iter()
            .filter(|r| r.contains("Bearer fake-A"))
            .count(),
        1
    );
    assert_eq!(
        requests
            .iter()
            .filter(|r| r.contains("Bearer fake-B"))
            .count(),
        1
    );
    assert_eq!(
        *a.lock().unwrap(),
        vec![Event::Dispatch(url.clone(), Some("Bearer fake-A".into()))]
    );
    assert_eq!(
        *b.lock().unwrap(),
        vec![Event::Dispatch(url, Some("Bearer fake-B".into()))]
    );
}

#[tokio::test]
async fn internal_cross_origin_redirect_invalidates_initial_credentials() {
    let (destination, last) = server(vec![OK.into()]);
    let (url, first) = server(vec![format!(
        "HTTP/1.1 307 Temporary Redirect\r\nLocation: {destination}\r\nContent-Length: 0\r\nConnection: close\r\n\r\n"
    )]);
    let events = Arc::new(Mutex::new(Vec::new()));
    let client = HttpClientBuilder::new().build_direct().unwrap();
    with_request_observer(
        recorder(events.clone()),
        client
            .get(&url)
            .header("authorization", "Bearer fake-A")
            .send(),
    )
    .await
    .unwrap();
    assert!(first.join().unwrap()[0].contains("Bearer fake-A"));
    assert!(!last.join().unwrap()[0].contains("Bearer fake-A"));
    let observed = events.lock().unwrap();
    assert_eq!(
        observed.first(),
        Some(&Event::Dispatch(url, Some("Bearer fake-A".into())))
    );
    assert_eq!(observed.last(), Some(&Event::Opaque(destination)));
}

#[tokio::test]
async fn redirect_back_to_original_url_is_still_opaque() {
    let (url, worker) = server(vec![
        "HTTP/1.1 307 Temporary Redirect\r\nLocation: /next\r\nContent-Length: 0\r\nConnection: close\r\n\r\n".into(),
        "HTTP/1.1 307 Temporary Redirect\r\nLocation: /\r\nContent-Length: 0\r\nConnection: close\r\n\r\n".into(),
        OK.into(),
    ]);
    let events = Arc::new(Mutex::new(Vec::new()));
    let client = HttpClientBuilder::new().build_direct().unwrap();
    with_request_observer(recorder(events.clone()), client.get(&url).send())
        .await
        .unwrap();
    assert_eq!(worker.join().unwrap().len(), 3);
    assert_eq!(
        *events.lock().unwrap(),
        vec![
            Event::Dispatch(url.clone(), None),
            Event::Opaque(format!("{url}next")),
            Event::Opaque(url),
        ]
    );
}
