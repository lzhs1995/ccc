//! Request-scoped diagnostics at the HTTP dispatch boundary. Never resolves auth.

use std::future::Future;
use std::sync::Arc;

use http::HeaderMap;

/// A request presented to the transport, or an opaque internal redirect.
pub enum RequestObservation<'a> {
    Dispatch {
        headers: &'a HeaderMap,
        url: &'a str,
    },
    /// The HTTP library followed redirects without exposing their request headers.
    OpaqueRedirect { url: &'a str },
}

type Observer = Arc<dyn Fn(RequestObservation<'_>) + Send + Sync>;

tokio::task_local! {
    static OBSERVER: Observer;
}

/// Observe only this future's transport calls, including route-aware redirect hops.
/// Callbacks must not panic or change request/auth state. No task-global subscriber
/// is installed, so concurrent requests cannot inherit another thread's identity.
pub async fn with_request_observer<F: Future>(
    observer: impl Fn(RequestObservation<'_>) + Send + Sync + 'static,
    future: F,
) -> F::Output {
    OBSERVER.scope(Arc::new(observer), future).await
}

pub(crate) fn observe(event: RequestObservation<'_>) {
    let _ = OBSERVER.try_with(|observer| observer(event));
}

#[cfg(test)]
#[path = "request_observer_tests.rs"]
mod tests;
