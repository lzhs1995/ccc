use super::*;
use http::HeaderValue;
use pretty_assertions::assert_eq;

#[cfg(unix)]
#[test]
fn directory_publications_preserve_identity_but_replacement_and_permissions_do_not() {
    use std::fs;
    use std::os::unix::fs::PermissionsExt;
    let home = tempfile::tempdir().unwrap();
    let root = home.path().join("credential-observations");
    fs::create_dir(&root).unwrap();
    fs::set_permissions(&root, fs::Permissions::from_mode(0o700)).unwrap();
    let before = directory_identity(&fs::symlink_metadata(&root).unwrap());
    let home_before = directory_identity(&fs::symlink_metadata(home.path()).unwrap());
    fs::write(root.join("other-request.json"), b"{}").unwrap();
    fs::write(home.path().join("other-log"), b"log").unwrap();
    assert_eq!(
        directory_identity(&fs::symlink_metadata(&root).unwrap()),
        before
    );
    assert_eq!(
        directory_identity(&fs::symlink_metadata(home.path()).unwrap()),
        home_before
    );
    fs::set_permissions(&root, fs::Permissions::from_mode(0o755)).unwrap();
    assert_ne!(
        directory_identity(&fs::symlink_metadata(&root).unwrap()),
        before
    );
    fs::rename(&root, home.path().join("old-observations")).unwrap();
    fs::create_dir(&root).unwrap();
    fs::set_permissions(&root, fs::Permissions::from_mode(0o700)).unwrap();
    assert_ne!(
        directory_identity(&fs::symlink_metadata(&root).unwrap()),
        before
    );
}

fn capture(thread: &str, key: &str, transport: &str) -> CredentialObservation {
    let mut headers = HeaderMap::new();
    headers.insert("thread-id", HeaderValue::from_str(thread).unwrap());
    headers.insert(
        "authorization",
        HeaderValue::from_str(&format!("Bearer {key}")).unwrap(),
    );
    CredentialObservation::capture(&headers, "https://example.invalid/v1/responses", transport)
        .unwrap()
}

#[test]
fn simultaneous_threads_keep_the_final_header_not_global_configuration() {
    let a = capture("01a0e96a-68dd-7210-8ef0-d83c89dca4d8", "fake-a", "http");
    let b = capture("01a0e7c1-dbf1-7c23-a186-ce9af424ed55", "fake-b", "http");
    assert_eq!(
        (a.authorization.as_deref(), b.authorization.as_deref()),
        (Some("Bearer fake-a"), Some("Bearer fake-b"))
    );
    assert_eq!(a.observer_epoch, b.observer_epoch);
    assert_ne!(a.thread_id, b.thread_id);
}

#[test]
fn reused_websocket_keeps_handshake_key_and_identifies_warmup() {
    let auth = capture(
        "01a0e96a-68dd-7210-8ef0-d83c89dca4d8",
        "fake-a",
        "websocket",
    );
    let frame = serde_json::json!({"type":"response.create", "client_metadata":{"thread_id":auth.thread_id}});
    let first = auth.websocket_frame(&frame.to_string()).unwrap();
    let second = auth.websocket_frame(&frame.to_string()).unwrap();
    assert_eq!(first.authorization, second.authorization);
    assert_eq!(first.connection_id, second.connection_id);
    let mut warmup = frame;
    warmup["generate"] = false.into();
    assert_eq!(
        auth.websocket_frame(&warmup.to_string()).unwrap().purpose,
        "warmup"
    );
}

#[test]
fn websocket_rejects_other_thread_and_non_request_frames() {
    let auth = capture(
        "01a0e96a-68dd-7210-8ef0-d83c89dca4d8",
        "fake-a",
        "websocket",
    );
    assert!(auth.websocket_frame(r#"{"type":"response.create","client_metadata":{"thread_id":"01a0e7c1-dbf1-7c23-a186-ce9af424ed55"}}"#).is_none());
    assert!(auth.websocket_frame(r#"{"type":"ping"}"#).is_none());
}

#[test]
fn missing_identity_is_not_guessed_and_url_credentials_are_removed() {
    let mut headers = HeaderMap::new();
    assert!(CredentialObservation::capture(&headers, "https://example.invalid", "http").is_none());
    headers.insert(
        "thread-id",
        HeaderValue::from_static("01a0e96a-68dd-7210-8ef0-d83c89dca4d8"),
    );
    let observation = CredentialObservation::capture(
        &headers,
        "https://user:pass@example.invalid/v1/responses?secret=x#fragment",
        "http",
    )
    .unwrap();
    assert_eq!(observation.endpoint, "https://example.invalid/v1/responses");
    assert_eq!(observation.authorization, None);
}

#[cfg(unix)]
#[test]
fn private_snapshot_preserves_separate_threads_and_warmup_history() {
    use std::fs;
    use std::os::unix::fs::PermissionsExt;
    let dir = tempfile::tempdir().unwrap();
    fs::set_permissions(dir.path(), fs::Permissions::from_mode(0o700)).unwrap();
    let a = capture("01a0e96a-68dd-7210-8ef0-d83c89dca4d8", "fake-a", "http");
    let b = capture("01a0e7c1-dbf1-7c23-a186-ce9af424ed55", "fake-b", "http");
    a.write_private(dir.path()).unwrap();
    b.write_private(dir.path()).unwrap();
    let mut warmup = a;
    warmup.purpose = "warmup".to_owned();
    warmup.write_private(dir.path()).unwrap();
    assert_eq!(fs::read_dir(dir.path()).unwrap().count(), 3);
    for entry in fs::read_dir(dir.path()).unwrap() {
        assert_eq!(
            entry.unwrap().metadata().unwrap().permissions().mode() & 0o777,
            0o600
        );
    }
}

#[cfg(unix)]
#[test]
fn public_or_symlink_directory_is_rejected() {
    use std::fs;
    use std::os::unix::fs::PermissionsExt;
    let dir = tempfile::tempdir().unwrap();
    let observation = capture("01a0e96a-68dd-7210-8ef0-d83c89dca4d8", "fake-a", "http");
    fs::set_permissions(dir.path(), fs::Permissions::from_mode(0o755)).unwrap();
    assert!(observation.write_private(dir.path()).is_err());
    fs::set_permissions(dir.path(), fs::Permissions::from_mode(0o700)).unwrap();
    let alias = dir.path().join("alias");
    std::os::unix::fs::symlink(dir.path(), &alias).unwrap();
    assert!(observation.write_private(&alias).is_err());
    assert_eq!(fs::read_dir(dir.path()).unwrap().count(), 1);
}

#[cfg(unix)]
#[test]
fn older_completion_cannot_replace_newer_attempt() {
    use std::fs;
    use std::os::unix::fs::PermissionsExt;
    let dir = tempfile::tempdir().unwrap();
    fs::set_permissions(dir.path(), fs::Permissions::from_mode(0o700)).unwrap();
    let old = capture("01a0e96a-68dd-7210-8ef0-d83c89dca4d8", "fake-old", "http");
    let new = capture(&old.thread_id, "fake-new", "http");
    new.write_private(dir.path()).unwrap();
    old.write_private(dir.path()).unwrap();
    let path = fs::read_dir(dir.path())
        .unwrap()
        .next()
        .unwrap()
        .unwrap()
        .path();
    let value: serde_json::Value = serde_json::from_slice(&fs::read(path).unwrap()).unwrap();
    assert_eq!(value["authorization"], "Bearer fake-new");
    assert_eq!(value["attempt_sequence"], new.attempt_sequence);
}

#[cfg(unix)]
#[test]
fn persistent_opt_in_requires_private_exact_marker() {
    use std::os::unix::fs::PermissionsExt;
    let home = tempfile::tempdir().unwrap();
    let root = home.path().join("credential-observations");
    assert!(super::persistent_directory(home.path()).is_none());
    std::fs::create_dir(&root).unwrap();
    std::fs::set_permissions(&root, std::fs::Permissions::from_mode(0o700)).unwrap();
    let marker = root.join("enabled-v1");
    std::fs::write(&marker, b"ccc-request-credentials-v1\n").unwrap();
    std::fs::set_permissions(&marker, std::fs::Permissions::from_mode(0o600)).unwrap();
    assert_eq!(super::persistent_directory(home.path()), Some(root.clone()));
    std::fs::set_permissions(&marker, std::fs::Permissions::from_mode(0o644)).unwrap();
    assert!(super::persistent_directory(home.path()).is_none());
    std::fs::set_permissions(&marker, std::fs::Permissions::from_mode(0o600)).unwrap();
    std::fs::write(&marker, b"ccc-request-credentials-v0\n").unwrap();
    assert!(super::persistent_directory(home.path()).is_none());
    std::fs::remove_file(&marker).unwrap();
    let other = home.path().join("other");
    std::fs::write(&other, b"ccc-request-credentials-v1\n").unwrap();
    std::fs::set_permissions(&other, std::fs::Permissions::from_mode(0o600)).unwrap();
    std::os::unix::fs::symlink(&other, &marker).unwrap();
    assert!(super::persistent_directory(home.path()).is_none());
}
