//! Opt-in, local request credential observations. Never sent to tracing/telemetry.
//!
//! Records describe a transport attempt, not server acceptance or future auth.
//! The caller supplies the final headers; observing must never resolve auth again.

use http::HeaderMap;
use serde::Serialize;
use std::path::Path;
use std::sync::Mutex;
use std::sync::OnceLock;
use std::sync::atomic::AtomicU64;
use std::sync::atomic::Ordering;

static SEQUENCE: AtomicU64 = AtomicU64::new(0);
use uuid::Uuid;

#[derive(Clone, Serialize)]
pub(crate) struct CredentialObservation {
    schema: u8,
    observer_epoch: String,
    pid: u32,
    thread_id: String,
    session_id: Option<String>,
    endpoint: String,
    authorization: Option<String>,
    api_key: Option<String>,
    transport: String,
    purpose: String,
    observed_at_ms: i64,
    attempt_sequence: u64,
    connection_id: Option<String>,
    credential_scope: String,
}

// Child publications change directory timestamps, not its identity or access policy.
#[cfg(unix)]
fn directory_identity(metadata: &std::fs::Metadata) -> (u64, u64, u32, u32) {
    use std::os::unix::fs::MetadataExt;
    (
        metadata.dev(),
        metadata.ino(),
        metadata.mode(),
        metadata.uid(),
    )
}

// A private, explicit opt-in survives daemon launches from older frontends.
#[cfg(unix)]
fn persistent_directory(home: &Path) -> Option<std::path::PathBuf> {
    use std::io::Read;
    use std::os::unix::fs::MetadataExt;
    use std::os::unix::fs::OpenOptionsExt;
    let home_meta = std::fs::symlink_metadata(home).ok()?;
    if !home.is_absolute() || !home_meta.is_dir() {
        return None;
    }
    let directory = home.join("credential-observations");
    let dir_meta = std::fs::symlink_metadata(&directory).ok()?;
    let marker = directory.join("enabled-v1");
    let before = std::fs::symlink_metadata(&marker).ok()?;
    if !dir_meta.is_dir()
        || dir_meta.mode() & 0o077 != 0
        || dir_meta.uid() != home_meta.uid()
        || !before.is_file()
        || before.mode() & 0o077 != 0
        || before.uid() != dir_meta.uid()
        || before.len() != 27
    {
        return None;
    }
    let file = std::fs::OpenOptions::new()
        .read(true)
        .custom_flags(libc::O_NOFOLLOW | libc::O_NONBLOCK)
        .open(&marker)
        .ok()?;
    let opened = file.metadata().ok()?;
    if !opened.is_file() || (opened.dev(), opened.ino()) != (before.dev(), before.ino()) {
        return None;
    }
    let mut bytes = Vec::new();
    file.take(28).read_to_end(&mut bytes).ok()?;
    let after = std::fs::symlink_metadata(&marker).ok()?;
    let identity = |m: &std::fs::Metadata| {
        (
            m.dev(),
            m.ino(),
            m.mode(),
            m.uid(),
            m.len(),
            m.mtime(),
            m.mtime_nsec(),
            m.ctime(),
            m.ctime_nsec(),
        )
    };
    if bytes != b"ccc-request-credentials-v1\n"
        || identity(&before) != identity(&after)
        || directory_identity(&dir_meta)
            != directory_identity(&std::fs::symlink_metadata(&directory).ok()?)
        || directory_identity(&home_meta)
            != directory_identity(&std::fs::symlink_metadata(home).ok()?)
    {
        return None;
    }
    Some(directory)
}

impl CredentialObservation {
    pub(crate) fn http_observer(
        identity_headers: HeaderMap,
    ) -> impl Fn(codex_http_client::RequestObservation<'_>) + Send + Sync {
        move |event| {
            let observation = match event {
                codex_http_client::RequestObservation::Dispatch { headers, url } => {
                    Self::capture(headers, url, "http")
                }
                codex_http_client::RequestObservation::OpaqueRedirect { url } => {
                    let mut identity = identity_headers.clone();
                    identity.remove(http::header::AUTHORIZATION);
                    identity.remove("api-key");
                    Self::capture(&identity, url, "http").map(|mut observation| {
                        observation.credential_scope = "opaque_redirect".to_owned();
                        observation
                    })
                }
            };
            if let Some(observation) = observation {
                observation.observe();
            }
        }
    }

    pub(crate) fn capture(headers: &HeaderMap, endpoint: &str, transport: &str) -> Option<Self> {
        let thread_id = headers.get("thread-id")?.to_str().ok()?;
        let thread_id = Uuid::parse_str(thread_id).ok()?.to_string();
        // Store only the endpoint, not URL userinfo or query-string credentials.
        let mut endpoint = url::Url::parse(endpoint).ok()?;
        let _ = endpoint.set_username("");
        let _ = endpoint.set_password(None);
        endpoint.set_query(None);
        endpoint.set_fragment(None);
        static EPOCH: OnceLock<String> = OnceLock::new();
        Some(Self {
            schema: 1,
            observer_epoch: EPOCH.get_or_init(|| Uuid::new_v4().to_string()).clone(),
            pid: std::process::id(),
            thread_id,
            session_id: headers
                .get("session-id")
                .and_then(|v| v.to_str().ok())
                .map(str::to_owned),
            endpoint: endpoint.to_string(),
            authorization: headers
                .get(http::header::AUTHORIZATION)
                .and_then(|v| v.to_str().ok())
                .map(str::to_owned),
            api_key: headers
                .get("api-key")
                .and_then(|v| v.to_str().ok())
                .map(str::to_owned),
            transport: transport.to_owned(),
            purpose: "request_attempt".to_owned(),
            observed_at_ms: chrono::Utc::now().timestamp_millis(),
            attempt_sequence: SEQUENCE.fetch_add(1, Ordering::Relaxed),
            connection_id: (transport == "websocket").then(|| Uuid::new_v4().to_string()),
            credential_scope: "request_headers".to_owned(),
        })
    }

    pub(crate) fn observe(&self) {
        let mut directory =
            std::env::var_os("CODEX_CREDENTIAL_OBSERVATIONS_DIR").map(std::path::PathBuf::from);
        #[cfg(unix)]
        if directory.is_none() {
            let home = std::env::var_os("CODEX_HOME")
                .map(std::path::PathBuf::from)
                .or_else(|| std::env::var_os("HOME").map(|h| Path::new(&h).join(".codex")));
            directory = home.as_deref().and_then(persistent_directory);
        }
        if let Some(directory) = directory {
            // Optional diagnostics must never change request/reconnect behavior.
            let _ = self.write_private(&directory);
        }
    }

    pub(crate) fn websocket_frame(&self, text: &str) -> Option<Self> {
        let value: serde_json::Value = serde_json::from_str(text).ok()?;
        if value.get("type")?.as_str()? != "response.create" {
            return None;
        }
        let thread_id = value.get("client_metadata")?.get("thread_id")?.as_str()?;
        if Uuid::parse_str(thread_id).ok()?.to_string() != self.thread_id {
            return None;
        }
        let mut observation = self.clone();
        observation.observed_at_ms = chrono::Utc::now().timestamp_millis();
        observation.attempt_sequence = SEQUENCE.fetch_add(1, Ordering::Relaxed);
        observation.purpose =
            if value.get("generate").and_then(serde_json::Value::as_bool) == Some(false) {
                "warmup"
            } else {
                "request_attempt"
            }
            .to_owned();
        Some(observation)
    }

    #[cfg(unix)]
    fn write_private(&self, directory: &Path) -> std::io::Result<()> {
        use std::fs;
        use std::io::Write;
        use std::os::unix::fs::MetadataExt;
        use std::os::unix::fs::OpenOptionsExt;

        // Serialize publication so a late response cannot replace a newer attempt.
        static PUBLICATION: Mutex<()> = Mutex::new(());
        let _publication = PUBLICATION
            .lock()
            .map_err(|_| std::io::Error::other("publication lock poisoned"))?;
        let destination = directory.join(format!(
            "{}-{}-{}.json",
            self.observer_epoch, self.thread_id, self.purpose
        ));
        // Provisioned by the owner, not auto-created under an arbitrary path.
        let before = fs::symlink_metadata(directory)?;
        if !directory.is_absolute() || !before.is_dir() || before.mode() & 0o077 != 0 {
            return Err(std::io::Error::other(
                "observation directory must be private",
            ));
        }
        if let Ok(bytes) = fs::read(&destination)
            && let Ok(previous) = serde_json::from_slice::<serde_json::Value>(&bytes)
            && previous
                .get("attempt_sequence")
                .and_then(serde_json::Value::as_u64)
                .is_some_and(|sequence| sequence > self.attempt_sequence)
        {
            return Ok(());
        }
        let temporary = directory.join(format!(".{}.tmp", Uuid::new_v4()));
        let mut file = fs::OpenOptions::new()
            .write(true)
            .create_new(true)
            .mode(0o600)
            .open(&temporary)?;
        let result = (|| {
            if file.metadata()?.uid() != before.uid() {
                return Err(std::io::Error::other(
                    "observation directory owner mismatch",
                ));
            }
            let bytes = serde_json::to_vec(self)?;
            file.write_all(&bytes)?;
            let after = fs::symlink_metadata(directory)?;
            if (before.dev(), before.ino(), before.mode(), before.uid())
                != (after.dev(), after.ino(), after.mode(), after.uid())
            {
                return Err(std::io::Error::other("observation directory changed"));
            }
            // Warmups cannot overwrite the latest model request credential.
            fs::rename(&temporary, &destination)
        })();
        if result.is_err() {
            let _ = fs::remove_file(&temporary);
        }
        result
    }

    #[cfg(not(unix))]
    fn write_private(&self, _directory: &Path) -> std::io::Result<()> {
        Err(std::io::Error::other(
            "credential observation ACL support not implemented",
        ))
    }
}

#[cfg(test)]
#[path = "credential_observation_tests.rs"]
mod tests;
