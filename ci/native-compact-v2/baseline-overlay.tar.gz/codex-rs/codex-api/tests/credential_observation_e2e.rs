//! Exercise the real HTTP and WebSocket send paths against local servers.
#![cfg(unix)]
use codex_api::*;
use codex_http_client::HttpClientFactory;
use codex_http_client::OutboundProxyPolicy;
use futures::SinkExt;
use futures::StreamExt;
use http::HeaderMap;
use http::HeaderValue;
use pretty_assertions::assert_eq;
use serde_json::Value;
use serde_json::json;
use std::collections::HashMap;
use std::path::Path;
use std::sync::Arc;
use std::sync::atomic::AtomicUsize;
use std::sync::atomic::Ordering;
use std::time::Duration;
use tokio::net::TcpListener;
use tokio_tungstenite::tungstenite::Message;

struct ChangingAuth(AtomicUsize);
impl AuthProvider for ChangingAuth {
    fn add_auth_headers(&self, headers: &mut HeaderMap) {
        let key = if self.0.fetch_add(1, Ordering::SeqCst) == 0 {
            "Bearer fake-a"
        } else {
            "Bearer fake-b"
        };
        headers.insert("authorization", HeaderValue::from_static(key));
    }
}

fn provider(base_url: String) -> Provider {
    Provider {
        name: "loopback".into(),
        base_url,
        query_params: None,
        headers: HeaderMap::new(),
        retry: RetryConfig {
            max_attempts: 1,
            base_delay: Duration::from_millis(1),
            retry_429: false,
            retry_5xx: false,
            retry_transport: false,
        },
        stream_idle_timeout: Duration::from_secs(5),
    }
}

fn record(directory: &Path, thread: &str, purpose: &str) -> Value {
    let suffix = format!("-{thread}-{purpose}.json");
    let files: Vec<_> = std::fs::read_dir(directory)
        .unwrap()
        .map(Result::unwrap)
        .filter(|entry| entry.file_name().to_string_lossy().ends_with(&suffix))
        .collect();
    assert_eq!(files.len(), 1);
    serde_json::from_slice(&std::fs::read(files[0].path()).unwrap()).unwrap()
}

#[test]
fn actual_headers_are_observed_without_resolving_auth_twice() {
    // Configure only an isolated child; never mutate the test runner environment.
    if let Some(directory) = std::env::var_os("CCC_CREDENTIAL_TEST_CHILD") {
        let runtime = tokio::runtime::Runtime::new().unwrap();
        runtime.block_on(async {
            tokio::time::timeout(Duration::from_secs(20), exercise(Path::new(&directory)))
                .await
                .unwrap();
        });
        return;
    }
    let directory = tempfile::tempdir().unwrap();
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        std::fs::set_permissions(directory.path(), std::fs::Permissions::from_mode(0o700)).unwrap();
    }
    let output = std::process::Command::new(std::env::current_exe().unwrap())
        .args([
            "--exact",
            "actual_headers_are_observed_without_resolving_auth_twice",
            "--nocapture",
        ])
        .env("CCC_CREDENTIAL_TEST_CHILD", directory.path())
        .env("CODEX_CREDENTIAL_OBSERVATIONS_DIR", directory.path())
        .env("NO_PROXY", "localhost,127.0.0.1,::1")
        .env("no_proxy", "localhost,127.0.0.1,::1")
        .output()
        .unwrap();
    assert!(
        output.status.success(),
        "{}\n{}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );
}

async fn exercise(directory: &Path) {
    let server = wiremock::MockServer::start().await;
    wiremock::Mock::given(wiremock::matchers::path("/responses"))
        .respond_with(wiremock::ResponseTemplate::new(401).set_body_string("unauthorized"))
        .mount(&server)
        .await;
    let auth = Arc::new(ChangingAuth(AtomicUsize::new(0)));
    let client = ResponsesClient::new(
        ReqwestTransport::from_http_client(
            codex_http_client::HttpClientBuilder::new()
                .build_direct()
                .unwrap(),
        ),
        provider(server.uri()),
        auth.clone(),
    );
    let threads = [
        uuid::Uuid::new_v4().to_string(),
        uuid::Uuid::new_v4().to_string(),
    ];
    for (index, thread) in threads.iter().enumerate() {
        let headers = build_session_headers(None, Some(thread.clone()));
        assert!(
            client
                .stream(
                    json!({"model":"fake","input":[]}),
                    headers,
                    Compression::None,
                    None
                )
                .await
                .is_err()
        );
        let observed = record(directory, thread, "request_attempt");
        let requests = server.received_requests().await.unwrap();
        assert_eq!(
            observed["authorization"].as_str().unwrap(),
            requests[index].headers["authorization"].to_str().unwrap()
        );
        assert_eq!(observed["thread_id"], thread.as_str());
        assert_eq!(observed["transport"], "http");
    }
    assert_eq!(auth.0.load(Ordering::SeqCst), 2);
    assert_ne!(
        record(directory, &threads[0], "request_attempt")["authorization"],
        record(directory, &threads[1], "request_attempt")["authorization"]
    );

    let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
    let address = listener.local_addr().unwrap();
    let wire = tokio::spawn(async move {
        let (tcp, _) = listener.accept().await.unwrap();
        let mut config = tokio_tungstenite::tungstenite::protocol::WebSocketConfig::default();
        config.extensions.permessage_deflate = Some(Default::default());
        let mut ws = tokio_tungstenite::accept_hdr_async_with_config(
            tcp,
            |request: &tokio_tungstenite::tungstenite::handshake::server::Request, response| {
                assert_eq!(request.headers()["authorization"], "Bearer fake-a");
                Ok(response)
            },
            Some(config),
        )
        .await
        .unwrap();
        for _ in 0..3 {
            let message = ws.next().await.unwrap().unwrap().into_text().unwrap();
            assert_eq!(
                serde_json::from_str::<Value>(&message).unwrap()["type"],
                "response.create"
            );
            ws.send(Message::Text(json!({"type":"response.completed", "response":{"id":"resp-local", "usage":{"input_tokens":0,"output_tokens":0,"total_tokens":0}}}).to_string().into())).await.unwrap();
        }
    });
    let auth = Arc::new(ChangingAuth(AtomicUsize::new(0)));
    let client = ResponsesWebsocketClient::new(provider(format!("http://{address}")), auth.clone());
    let thread = uuid::Uuid::new_v4().to_string();
    let connection = client
        .connect(
            &HttpClientFactory::new(OutboundProxyPolicy::ReqwestDefault),
            build_session_headers(None, Some(thread.clone())),
            HeaderMap::new(),
            None,
            None,
        )
        .await
        .unwrap();
    let mut connection_id = Value::Null;
    for (index, generate) in [Some(false), None, None].into_iter().enumerate() {
        let request = ResponsesWsRequest::ResponseCreate(ResponseCreateWsRequest {
            model: "fake",
            instructions: "",
            previous_response_id: None,
            input: &[],
            tools: None,
            tool_choice: "auto",
            parallel_tool_calls: false,
            reasoning: None,
            store: false,
            stream: true,
            stream_options: None,
            include: &[],
            service_tier: None,
            prompt_cache_key: None,
            text: None,
            generate,
            client_metadata: Some(HashMap::from([("thread_id".into(), thread.clone())])),
            access_programs: None,
        });
        let mut stream = connection
            .stream_request(request, index > 0, None)
            .await
            .unwrap();
        while let Some(event) = stream.next().await {
            event.unwrap();
        }
        let purpose = if index == 0 {
            "warmup"
        } else {
            "request_attempt"
        };
        let observed = record(directory, &thread, purpose);
        assert_eq!(observed["authorization"], "Bearer fake-a");
        if index == 0 {
            connection_id = observed["connection_id"].clone();
        }
        assert_eq!(observed["connection_id"], connection_id);
    }
    wire.await.unwrap();
    assert_eq!(auth.0.load(Ordering::SeqCst), 1);
}
