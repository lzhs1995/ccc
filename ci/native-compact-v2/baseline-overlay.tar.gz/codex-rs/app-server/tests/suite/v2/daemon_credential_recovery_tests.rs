//! Recovery must preserve thread-owned authentication before a client reconnects.
use super::*;
use pretty_assertions::assert_eq;

#[tokio::test]
async fn managed_restart_preserves_mixed_keys_before_client_reconnect() -> Result<()> {
    assert_mixed_key_recovery(KeySource::ProviderDefinition).await
}

#[tokio::test]
async fn managed_restart_preserves_environment_keys_before_client_reconnect() -> Result<()> {
    assert_mixed_key_recovery(KeySource::Environment).await
}

#[tokio::test]
async fn managed_restart_preserves_environment_headers_before_client_reconnect() -> Result<()> {
    assert_mixed_key_recovery(KeySource::EnvironmentHeaders).await
}

enum KeySource {
    ProviderDefinition,
    Environment,
    EnvironmentHeaders,
}

async fn assert_mixed_key_recovery(source: KeySource) -> Result<()> {
    let home = TempDir::new()?;
    let (release_a, gate_a) = oneshot::channel();
    let (release_b, gate_b) = oneshot::channel();
    let (_release_next_a, next_a) = oneshot::channel();
    let (_release_next_b, next_b) = oneshot::channel();
    let (mock, _completions) = start_streaming_sse_server(vec![
        vec![stream_chunk(Some(gate_a), "Original A")?],
        vec![stream_chunk(Some(gate_b), "Original B")?],
        vec![stream_chunk(Some(next_a), "Recovered")?],
        vec![stream_chunk(Some(next_b), "Recovered")?],
    ])
    .await;
    create_config_toml(home.path(), mock.uri(), "never")?;
    let socket = home.path().join("control/server.sock");
    let mut server = spawn_server_with_env(
        home.path(),
        &socket,
        &[
            ("CODEX_TEST_RECOVERY_KEY_A", "fake-key-A"),
            ("CODEX_TEST_RECOVERY_KEY_B", "fake-key-B"),
            ("CODEX_TEST_RECOVERY_HEADER_A", "Bearer fake-key-A"),
            ("CODEX_TEST_RECOVERY_HEADER_B", "Bearer fake-key-B"),
        ],
    )?;
    let mut client = connect_default_daemon_client(&socket).await?;
    let mut ids = Vec::new();
    for (index, key) in ["fake-key-A", "fake-key-B"].into_iter().enumerate() {
        let id = 10 + i64::try_from(index)? * 10;
        let binding = match source {
            KeySource::ProviderDefinition => json!({
                "model_providers.mock_provider.experimental_bearer_token": key,
            }),
            KeySource::Environment => json!({
                "model_providers.mock_provider.env_key": if index == 0 {
                    "CODEX_TEST_RECOVERY_KEY_A"
                } else {
                    "CODEX_TEST_RECOVERY_KEY_B"
                },
            }),
            KeySource::EnvironmentHeaders => json!({
                "model_providers.mock_provider.http_headers": {
                    "Authorization": "Bearer fake-shadowed-key",
                },
                "model_providers.mock_provider.env_http_headers": {
                    "authorization": if index == 0 {
                        "CODEX_TEST_RECOVERY_HEADER_A"
                    } else {
                        "CODEX_TEST_RECOVERY_HEADER_B"
                    },
                },
            }),
        };
        let thread = start_thread(&mut client, id, json!({"config": binding})).await?;
        start_turn(&mut client, id + 1, &thread.thread.id).await?;
        wait_for_requests(&mock, index + 1).await?;
        request(
            &mut client,
            id + 2,
            "thread/goal/set",
            json!({"threadId":thread.thread.id,"objective":"Preserve original goal"}),
        )
        .await?;
        ids.push(thread.thread.id);
    }
    let original_headers = mock.request_headers().await;
    let authorization = |headers: &str| -> String {
        headers
            .lines()
            .find_map(|line| {
                let (name, value) = line.split_once(':')?;
                name.eq_ignore_ascii_case("authorization")
                    .then(|| value.trim().to_owned())
            })
            .unwrap_or_default()
    };
    assert_eq!(
        original_headers
            .iter()
            .map(|h| authorization(h))
            .collect::<Vec<_>>(),
        vec!["Bearer fake-key-A", "Bearer fake-key-B"]
    );
    request_shutdown(&server, &socket).await?;
    assert_still_running(
        &mut server,
        "credential migration must drain active requests",
    )
    .await;
    release_a.send(()).expect("original A is waiting");
    release_b.send(()).expect("original B is waiting");
    wait_success(&mut server).await?;
    assert_eq!(
        daemon_recovery::read_candidates(&daemon_recovery_file_path(home.path()))?,
        ids.into_iter().collect()
    );
    // The successor must not use the current global credential for either thread.
    let config_path = home.path().join("config.toml");
    let mut config = std::fs::read_to_string(&config_path)?;
    if !matches!(source, KeySource::EnvironmentHeaders) {
        config.push_str("\nexperimental_bearer_token = \"fake-global-C\"\n");
    }
    std::fs::write(config_path, config)?;
    let _successor = spawn_server_with_env(
        home.path(),
        &socket,
        &[
            ("CODEX_TEST_RECOVERY_KEY_A", "fake-global-C"),
            ("CODEX_TEST_RECOVERY_KEY_B", "fake-global-C"),
            ("CODEX_TEST_RECOVERY_HEADER_A", "Bearer fake-global-C"),
            ("CODEX_TEST_RECOVERY_HEADER_B", "Bearer fake-global-C"),
        ],
    )?;
    // No client reconnect: these are the first automatic goal requests.
    wait_for_requests(&mock, 4).await?;
    let headers = mock.request_headers().await;
    let mut recovered = headers[2..]
        .iter()
        .map(|h| authorization(h))
        .collect::<Vec<_>>();
    recovered.sort();
    assert_eq!(recovered, vec!["Bearer fake-key-A", "Bearer fake-key-B"]);
    Ok(())
}
