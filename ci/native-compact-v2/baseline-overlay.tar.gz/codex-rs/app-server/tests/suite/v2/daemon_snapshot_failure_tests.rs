//! Staged regression: install into the suite after migration182 releases its freeze.
//! Uses only a temporary daemon and a loopback mock; no real model requests.
use super::*;
use pretty_assertions::assert_eq;

#[tokio::test]
async fn unresolved_provider_keeps_original_daemon_and_thread_available() -> Result<()> {
    let home = TempDir::new()?;
    let (mock, _completions) = start_streaming_sse_server(vec![]).await;
    create_config_toml(home.path(), mock.uri(), "never")?;
    let socket = home.path().join("control/server.sock");
    let mut server = spawn_server(home.path(), &socket)?;
    let mut client = connect_default_daemon_client(&socket).await?;
    // Derive an absent name without mutating the test runner's environment.
    let missing_key = format!("CODEX_ABSENT_RECOVERY_KEY_{}", uuid::Uuid::new_v4());
    assert!(std::env::var_os(&missing_key).is_none());
    let thread = start_thread(
        &mut client,
        /*id*/ 2,
        json!({"config":{"model_providers.mock_provider.env_key":missing_key}}),
    )
    .await?;
    // Establish the rollout through a failed local authentication attempt;
    // a never-used lazy thread cannot exercise the loaded-resume path.
    start_turn(&mut client, /*id*/ 90, &thread.thread.id).await?;
    timeout(DEFAULT_READ_TIMEOUT, async {
        loop {
            let Message::Text(text) = client.next().await.context("socket closed")?? else {
                continue;
            };
            if let JSONRPCMessage::Notification(notification) = serde_json::from_str(&text)?
                && notification.method == "turn/completed"
            {
                break;
            }
        }
        Ok::<(), anyhow::Error>(())
    })
    .await??;
    let before = request(
        &mut client,
        /*id*/ 91,
        "thread/resume",
        json!({"threadId":thread.thread.id,"excludeTurns":true}),
    )
    .await?;
    assert_eq!(before["thread"]["id"], thread.thread.id);
    request_shutdown(&server, &socket).await?;
    assert_still_running(
        &mut server,
        "an unresolved credential must retain its original daemon",
    )
    .await;
    let loaded = request(&mut client, /*id*/ 3, "thread/loaded/list", json!({})).await?;
    assert_eq!(loaded["data"], json!([thread.thread.id]));
    let resumed = request(
        &mut client,
        /*id*/ 4,
        "thread/resume",
        json!({"threadId":thread.thread.id,"excludeTurns":true}),
    )
    .await?;
    assert_eq!(resumed["thread"]["id"], thread.thread.id);
    assert!(!daemon_recovery_file_path(home.path()).exists());
    assert!(mock.requests().await.is_empty());
    Ok(())
}

#[tokio::test]
async fn unreadable_snapshot_keeps_original_bytes_for_recovery() -> Result<()> {
    let home = TempDir::new()?;
    create_config_toml(home.path(), "http://127.0.0.1:1", "never")?;
    let path = daemon_recovery_file_path(home.path());
    std::fs::create_dir_all(path.parent().context("snapshot parent")?)?;
    let original = b"[\"original-thread\",\"codex-interrupted-v1:{truncated";
    std::fs::write(&path, original)?;
    let socket = home.path().join("control/server.sock");
    let mut server = spawn_server(home.path(), &socket)?;
    let mut client = connect_default_daemon_client(&socket).await?;
    request(&mut client, /*id*/ 2, "thread/loaded/list", json!({})).await?;
    assert_eq!(std::fs::read(&path)?, original);
    request_shutdown(&server, &socket).await?;
    assert_still_running(&mut server, "malformed handoff must prevent shutdown").await;
    request(&mut client, /*id*/ 3, "thread/loaded/list", json!({})).await?;
    assert_eq!(std::fs::read(&path)?, original);
    // Remove only this deliberately malformed test fixture before clean shutdown.
    std::fs::remove_file(&path)?;
    request_shutdown(&server, &socket).await?;
    wait_success(&mut server).await?;
    Ok(())
}

#[tokio::test]
async fn failed_snapshot_keeps_original_thread_connected_and_admits_work() -> Result<()> {
    let home = TempDir::new()?;
    let (mock, _completions) =
        start_streaming_sse_server(vec![vec![stream_chunk(None, "Initialized")?]]).await;
    create_config_toml(home.path(), mock.uri(), "never")?;
    let socket = home.path().join("control/server.sock");
    let mut server = spawn_server(home.path(), &socket)?;
    let mut client = connect_default_daemon_client(&socket).await?;
    let thread = start_thread(&mut client, /*id*/ 2, json!({})).await?;
    // A brand-new thread is lazily persisted. Exercise an established session,
    // as in a real daemon handoff, before testing same-thread resume.
    start_turn(&mut client, /*id*/ 89, &thread.thread.id).await?;
    timeout(DEFAULT_READ_TIMEOUT, async {
        loop {
            let Message::Text(text) = client.next().await.context("socket closed")?? else {
                continue;
            };
            if let JSONRPCMessage::Notification(notification) = serde_json::from_str(&text)?
                && notification.method == "turn/completed"
            {
                break;
            }
        }
        Ok::<(), anyhow::Error>(())
    })
    .await??;
    // Distinguish an existing loaded-resume failure from failed-shutdown recovery.
    let before_shutdown = request(
        &mut client,
        /*id*/ 90,
        "thread/resume",
        json!({"threadId":thread.thread.id,"excludeTurns":true}),
    )
    .await
    .context("loaded resume before shutdown injection")?;
    assert_eq!(before_shutdown["thread"]["id"], thread.thread.id);
    let path = daemon_recovery_file_path(home.path());
    // A directory cannot be replaced by the snapshot's atomic file rename.
    std::fs::create_dir_all(&path)?;
    request_shutdown(&server, &socket).await?;
    assert_still_running(
        &mut server,
        "failed handoff must retain the original process",
    )
    .await;
    let loaded = request(&mut client, /*id*/ 3, "thread/loaded/list", json!({})).await?;
    assert!(
        loaded["data"]
            .as_array()
            .context("loaded IDs")?
            .contains(&json!(thread.thread.id))
    );
    // Resume is admission-gated but does not request model inference. It proves
    // that aborting the handoff restored normal operation on the same connection.
    let resumed = request(
        &mut client,
        /*id*/ 4,
        "thread/resume",
        json!({"threadId":thread.thread.id,"excludeTurns":true}),
    )
    .await?;
    assert_eq!(resumed["thread"]["id"], thread.thread.id);
    std::fs::remove_dir(&path)?;
    request_shutdown(&server, &socket).await?;
    wait_success(&mut server).await?;
    assert_eq!(
        daemon_recovery::read_candidates(&path)?,
        [thread.thread.id].into_iter().collect()
    );
    Ok(())
}

#[tokio::test]
async fn failed_restore_preserves_pending_thread_and_provider() -> Result<()> {
    let home = TempDir::new()?;
    create_config_toml(home.path(), "http://127.0.0.1:1", "never")?;
    let path = daemon_recovery_file_path(home.path());
    let id = "11111111-1111-4111-8111-111111111111".to_string();
    let original = daemon_recovery::RecoverySnapshot {
        loaded: [id.clone()].into_iter().collect(),
        providers: [(id, daemon_recovery::SavedProvider {
            id: "pending-test".to_string(),
            definition: json!({"name":"pending-test", "base_url":"http://127.0.0.1:1", "experimental_bearer_token":"fake-pending-key"}),
        })].into_iter().collect(),
        ..Default::default()
    };
    daemon_recovery::write_snapshot(&path, &original)?;
    let socket = home.path().join("control/server.sock");
    let mut server = spawn_server(home.path(), &socket)?;
    let mut client = connect_default_daemon_client(&socket).await?;
    request(&mut client, /*id*/ 2, "thread/loaded/list", json!({})).await?;
    let during = daemon_recovery::read_snapshot(&path)?;
    request_shutdown(&server, &socket).await?;
    wait_success(&mut server).await?;
    let after = daemon_recovery::read_snapshot(&path)?;
    assert_eq!((&during, &after), (&original, &original));
    Ok(())
}
