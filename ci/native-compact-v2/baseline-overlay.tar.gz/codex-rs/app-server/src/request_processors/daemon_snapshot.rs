//! Selects persistent root threads for managed daemon recovery using normal resume semantics.
//! Every eligible root must be saved successfully before the daemon may exit.

use super::ThreadRequestProcessor;
use codex_app_server_transport::daemon_recovery::InterruptedTurn;
use codex_app_server_transport::daemon_recovery::RecoverySnapshot;
use codex_thread_store::PersistContext;
use std::io;

impl ThreadRequestProcessor {
    #[expect(
        clippy::await_holding_invalid_type,
        reason = "snapshot selection must be serialized against pending unloads"
    )]
    pub(crate) async fn daemon_recovery_snapshot(&self) -> io::Result<RecoverySnapshot> {
        let mut snapshot = RecoverySnapshot::default();
        for thread_id in self.thread_manager.list_thread_ids().await {
            let pending_unloads = self.pending_thread_unloads.lock().await;
            if pending_unloads.contains(&thread_id) {
                continue;
            }
            let Ok(thread) = self.thread_manager.get_thread(thread_id).await else {
                continue;
            };
            let config = thread.config_snapshot().await;
            if !config.ephemeral
                && config.parent_thread_id.is_none()
                && !config.session_source.is_non_root_agent()
            {
                let interrupted = thread.interrupted_turn().await;
                self.thread_store
                    .persist_thread(thread_id, PersistContext::Standard)
                    .await
                    .map_err(|_| io::Error::other("cannot persist daemon root thread"))?;
                let provider = config
                    .model_provider
                    .resolved_environment_snapshot()
                    .map_err(|_| io::Error::other("cannot resolve daemon provider binding"))?;
                let definition = serde_json::to_value(&provider)
                    .map_err(|_| io::Error::other("cannot serialize daemon provider binding"))?;
                snapshot.providers.insert(
                    thread_id.to_string(),
                    codex_app_server_transport::daemon_recovery::SavedProvider {
                        id: config.model_provider_id,
                        definition,
                    },
                );
                snapshot.loaded.insert(thread_id.to_string());
                if let Some((turn_id, options, environment)) = interrupted {
                    snapshot.interrupted.insert(
                        thread_id.to_string(),
                        InterruptedTurn {
                            turn_id,
                            output_schema: options.final_output_json_schema,
                            service_tier: options.service_tier,
                            cyber_access_program: options.cyber_access_program,
                            local_environment: Some((&environment).into()),
                        },
                    );
                }
            }
        }
        Ok(snapshot)
    }
}
