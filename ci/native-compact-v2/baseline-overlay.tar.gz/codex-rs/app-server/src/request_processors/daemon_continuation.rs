//! Attempts one new continuation turn immediately after daemon thread restoration.
//! Completed or superseded work is discarded; recovery never waits for a later idle event.
//! Permissions and the saved local executor selection must match the resumed runtime.

use super::ThreadRequestProcessor;
use crate::thread_state::PendingDaemonTurnClosure;
use crate::thread_state::ThreadState;
use codex_app_server_protocol::ThreadEnvironment;
use codex_app_server_transport::daemon_recovery::InterruptedTurn;
use codex_core::CodexThread;
use codex_core::TurnInput;
use codex_core::TurnInputRequest;
use codex_core::TurnInputSubmission;
use codex_core::TurnStartOptions;
use codex_core::context::ContextualUserFragment;
use codex_core::context::InternalContextSource;
use codex_core::context::InternalModelContextFragment;
use codex_protocol::ThreadId;
use codex_protocol::protocol::EnvironmentConfigState;
use codex_protocol::protocol::EventMsg;
use codex_protocol::protocol::TurnAbortReason;
use codex_protocol::protocol::TurnAbortedEvent;
use codex_rollout::RolloutItem;
use std::sync::Arc;

impl ThreadRequestProcessor {
    pub(crate) async fn continue_daemon_turn(&self, thread_id: &str, saved: InterruptedTurn) {
        let Ok(thread_id) = ThreadId::from_string(thread_id) else {
            return;
        };
        let Ok(thread) = self.thread_manager.get_thread(thread_id).await else {
            return;
        };
        let Some(path) = thread.rollout_path() else {
            return;
        };
        let history = match codex_rollout::RolloutRecorder::load_rollout_items(&path).await {
            Ok((history, _, 0)) => history,
            Ok((_, _, parse_errors)) => {
                tracing::warn!(%thread_id, parse_errors, "interrupted turn history is malformed; preserving idle state");
                return;
            }
            Err(err) => {
                tracing::warn!(%thread_id, %err, "failed to read interrupted turn history");
                return;
            }
        };
        // The snapshot has complete recorded input, but the old process may have
        // completed or replaced its turn during the shutdown grace period.
        let Some(start) = history
            .iter()
            .rposition(|item| matches!(item, RolloutItem::EventMsg(EventMsg::TurnStarted(_))))
        else {
            return;
        };
        if !matches!(&history[start], RolloutItem::EventMsg(EventMsg::TurnStarted(event))
            if event.turn_id == saved.turn_id)
            || history[start..].iter().any(|item| match item {
                RolloutItem::EventMsg(EventMsg::TurnComplete(event)) => {
                    event.turn_id == saved.turn_id
                }
                RolloutItem::EventMsg(EventMsg::TurnAborted(event)) => event
                    .turn_id
                    .as_ref()
                    .is_none_or(|turn_id| turn_id == &saved.turn_id),
                _ => false,
            })
        {
            return;
        }
        let previous_context = history.iter().rev().find_map(|item| match item {
            RolloutItem::TurnContext(context)
                if context.turn_id.as_ref() == Some(&saved.turn_id) =>
            {
                Some(context)
            }
            _ => None,
        });
        let Some(previous_context) = previous_context else {
            return;
        };
        let config = thread.config_snapshot().await;
        let [environment] = config.environment_selections() else {
            return;
        };
        if environment.environment_id != codex_exec_server::LOCAL_ENVIRONMENT_ID
            || environment.config != EnvironmentConfigState::FromThread
            || saved.local_environment.as_ref() != Some(&ThreadEnvironment::from(environment))
        {
            return;
        }
        // Recovery must not override a stricter saved or newly configured policy.
        if previous_context.permission_profile() != config.permission_profile {
            return;
        }
        let continuation = ContextualUserFragment::into(InternalModelContextFragment::new(
            InternalContextSource::from_static("daemon_recovery"),
            "The server restarted and interrupted the previous turn. Continue the unfinished work from the saved conversation. Check the current state before repeating actions that may already have completed.",
        ));
        let request = TurnInputRequest::new(TurnInput::ResponseItem(continuation)).on_start(
            TurnStartOptions {
                turn_trigger: Some("daemon_recovery".to_string()),
                final_output_json_schema: saved.output_schema,
                service_tier: saved.service_tier,
                cyber_access_program: saved.cyber_access_program,
                root_turn_id: previous_context.root_turn_id.clone(),
                ..Default::default()
            },
        );
        let predecessor = saved.turn_id.clone();
        match thread.continue_turn_if_idle(request, saved.turn_id).await {
            Ok(TurnInputSubmission::Started { turn_id, .. }) => {
                let state = self.thread_state_manager.thread_state(thread_id).await;
                let closure = {
                    let mut state = state.lock().await;
                    state.pending_daemon_turn_closure = Some(PendingDaemonTurnClosure {
                        predecessor,
                        successor: turn_id,
                        thread: Arc::downgrade(&thread),
                    });
                    // The listener may already have observed the actual start before
                    // the submission acknowledgement reached us.
                    take_daemon_predecessor(&thread, &mut state)
                };
                if let Some(closure) = closure {
                    close_daemon_predecessor(closure).await;
                }
                crate::extensions::send_thread_warning(
                    &self.outgoing,
                    &self.thread_state_manager,
                    thread_id,
                    "Resuming interrupted work".to_string(),
                )
                .await;
            }
            Ok(TurnInputSubmission::NotSubmitted { reason }) => {
                tracing::debug!(%thread_id, ?reason, "recovery continuation was not started");
            }
            Ok(TurnInputSubmission::Steered { .. }) => unreachable!("continuation cannot steer"),
            Err(err) => tracing::warn!(%thread_id, %err, "recovery continuation failed"),
        }
    }
}

pub(crate) fn take_daemon_predecessor(
    thread: &Arc<CodexThread>,
    state: &mut ThreadState,
) -> Option<PendingDaemonTurnClosure> {
    let pending = state.pending_daemon_turn_closure.as_ref()?;
    if !pending
        .thread
        .upgrade()
        .is_some_and(|owner| Arc::ptr_eq(&owner, thread))
    {
        state.pending_daemon_turn_closure = None;
        return None;
    }
    if state.active_turn_id() != Some(pending.successor.as_str())
        && state.last_terminal_turn_id.as_deref() != Some(pending.successor.as_str())
    {
        return None;
    }
    // Take once: an uncertain append must never rearm the continuation or
    // repeatedly append terminal records. The listener and ACK path serialize
    // here using the same thread-state lock.
    state.pending_daemon_turn_closure.take()
}

pub(crate) async fn close_daemon_predecessor(pending: PendingDaemonTurnClosure) {
    // Keep storage awaits outside the state lock. The consumed closure retains
    // exact turn IDs and only its original runtime, even if a new listener starts.
    let Some(thread) = pending.thread.upgrade() else {
        return;
    };
    if let Err(err) = thread.flush_rollout().await {
        tracing::warn!(%err, "failed to persist daemon successor before predecessor closure");
        return;
    }
    // A delivered event is not proof of persistence: the core can emit it
    // after an append failure. Verify the exact successor in canonical history
    // before closing its predecessor, including failures before writer enqueue.
    let Some(path) = thread.rollout_path() else {
        return;
    };
    match codex_rollout::RolloutRecorder::load_rollout_items(&path).await {
        Ok((history, _, parse_errors))
            if parse_errors == 0
                && history.iter().any(|item| {
                    matches!(item, RolloutItem::EventMsg(EventMsg::TurnStarted(event))
                        if event.turn_id == pending.successor)
                }) => {}
        Ok(_) => {
            tracing::warn!(
                "daemon successor missing from valid canonical history; preserving predecessor"
            );
            return;
        }
        Err(err) => {
            tracing::warn!(%err, "failed to verify persisted daemon successor; preserving predecessor");
            return;
        }
    }
    if let Err(err) = thread
        .append_rollout_items(&[RolloutItem::EventMsg(EventMsg::TurnAborted(
            TurnAbortedEvent {
                turn_id: Some(pending.predecessor),
                reason: TurnAbortReason::Interrupted,
                error: None,
                started_at: None,
                completed_at: None,
                duration_ms: None,
            },
        ))])
        .await
    {
        tracing::warn!(%err, "failed to close daemon predecessor after successor start");
    }
}
