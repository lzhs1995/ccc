//! Saves persistent root thread IDs and restores them through the shared internal resume path.
//! Recovery uses normal cold-resume semantics without delaying readiness for runtime loading.
//! Already-loaded runtimes remain owned by their current clients.

use std::io;
use std::path::PathBuf;
use std::sync::Arc;
use tokio::sync::Mutex;

use codex_app_server_transport::daemon_recovery;

pub(crate) type PendingRecovery = Arc<Mutex<Option<daemon_recovery::RecoverySnapshot>>>;

pub(crate) async fn snapshot(
    path: PathBuf,
    mut saved: daemon_recovery::RecoverySnapshot,
    pending: PendingRecovery,
) -> io::Result<()> {
    {
        let pending = pending.lock().await;
        // A malformed startup file must not be overwritten by an empty new snapshot.
        // Re-read only when startup could not establish a pending set.
        let fallback;
        let pending = match pending.as_ref() {
            Some(pending) => pending,
            None => {
                fallback = daemon_recovery::read_snapshot(&path)?;
                &fallback
            }
        };
        for id in &pending.loaded {
            // A live runtime has newer state than a failed partial restore.
            if saved.loaded.insert(id.clone()) {
                if let Some(provider) = pending.providers.get(id) {
                    saved.providers.insert(id.clone(), provider.clone());
                }
                if let Some(turn) = pending.interrupted.get(id) {
                    saved.interrupted.insert(id.clone(), turn.clone());
                }
            }
        }
    }
    // A forced exit must not wait for file I/O in Tokio's blocking pool.
    let (result_tx, result_rx) = tokio::sync::oneshot::channel();
    std::thread::Builder::new()
        .name("daemon-snapshot".into())
        .spawn(move || {
            let result = daemon_recovery::write_snapshot(&path, &saved);
            let _ = result_tx.send(result);
        })?;
    result_rx.await.map_err(io::Error::other)?
}

/// Retain the durable handoff until a replacement snapshot commits.
pub(crate) async fn start_recovery(
    path: PathBuf,
    processor: Arc<crate::message_processor::MessageProcessor>,
    pending: PendingRecovery,
) -> io::Result<tokio::task::JoinHandle<()>> {
    let candidates = tokio::task::spawn_blocking(move || daemon_recovery::read_snapshot(&path))
        .await
        .map_err(io::Error::other)??;
    *pending.lock().await = Some(candidates);
    Ok(tokio::spawn(async move {
        processor.restore_daemon_threads(pending).await;
    }))
}
