//! Preserve process-environment bindings when a managed daemon hands off threads.

use crate::ModelProviderInfo;
use codex_protocol::error::CodexErr;
use codex_protocol::error::Result;

impl ModelProviderInfo {
    /// Returns a definition with this process's environment credentials resolved.
    /// The original definition and process environment are not changed. Dynamic
    /// command, OAuth and gateway credentials retain their existing mechanisms.
    pub fn resolved_environment_snapshot(&self) -> Result<Self> {
        let mut saved = self.clone();
        if let Some(key) = self.api_key()? {
            saved.experimental_bearer_token = Some(key.into());
            saved.env_key = None;
        }
        if self.env_http_headers.is_some() {
            // Reuse request-time parsing and case-insensitive precedence, including
            // omitted empty/invalid values, rather than merging raw map names.
            let headers = self
                .build_header_map()?
                .iter()
                .map(|(name, value)| {
                    let value = std::str::from_utf8(value.as_bytes()).map_err(|_| {
                        CodexErr::InvalidRequest("invalid recovery header encoding".to_owned())
                    })?;
                    Ok((name.as_str().to_owned(), value.to_owned().into()))
                })
                .collect::<Result<_>>()?;
            saved.http_headers = Some(headers);
            saved.env_http_headers = None;
        }
        Ok(saved)
    }
}
