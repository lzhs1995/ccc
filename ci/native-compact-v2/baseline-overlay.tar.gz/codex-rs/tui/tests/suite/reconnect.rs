//! Drives automatic reconnect through the real binary and terminal event loop.

use super::focus_palette::PtyCodex;
use super::focus_palette::write_test_config;
use anyhow::Result;
use anyhow::ensure;
use codex_app_server_protocol::JSONRPCMessage;
use futures::SinkExt;
use futures::StreamExt;
use pretty_assertions::assert_eq;
use serde_json::json;
use std::sync::Arc;
use std::sync::atomic::AtomicUsize;
use std::sync::atomic::Ordering;
use std::time::Duration;
use std::time::Instant;
use tokio::net::UnixListener;
use tokio_tungstenite::tungstenite::Message;

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn automatic_reconnect_restores_draft_and_routes_new_notifications() -> Result<()> {
    exercise_terminal(false).await
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn explicit_encoded_escape_interrupts_running_turn() -> Result<()> {
    exercise_terminal(true).await
}

async fn exercise_terminal(explicit_escape_only: bool) -> Result<()> {
    let repo_root = codex_utils_cargo_bin::repo_root()?;
    // macOS's default temporary directory leaves too little room for the control socket path.
    let codex_home = tempfile::tempdir_in("/tmp")?;
    write_test_config(codex_home.path(), &repo_root)?;
    let config_path = codex_home.path().join("config.toml");
    let config = std::fs::read_to_string(&config_path)?;
    std::fs::write(
        config_path,
        format!("{config}\n[tui]\nstatus_line = [\"thread-id\"]\n"),
    )?;
    let socket = codex_app_server_client::app_server_control_socket_path(codex_home.path())?;
    std::fs::create_dir_all(socket.parent().unwrap())?;
    let listener = UnixListener::bind(socket.as_path())?;
    let (disconnect_tx, mut disconnect_rx) = tokio::sync::oneshot::channel();
    let (restore_tx, restore_rx) = tokio::sync::oneshot::channel();
    let interrupt_count = Arc::new(AtomicUsize::new(0));
    let server_interrupt_count = Arc::clone(&interrupt_count);
    let server_cwd = repo_root.clone();
    let id = "00000000-0000-0000-0000-000000000001";
    let server = tokio::spawn(async move {
        let mut methods = Vec::new();
        let mut restore_rx = Some(restore_rx);
        let thread = json!({
            "id": id, "sessionId": id, "preview": "", "ephemeral": false,
            "modelProvider": "openai", "createdAt": 1, "updatedAt": 2,
            "status": {"type": "active", "activeFlags": []}, "cwd": server_cwd,
            "cliVersion": "0.0.0", "source": "cli", "turns": [{"id": "running", "items": [], "status": "inProgress", "error": null}]
        });
        // The first connection checks daemon compatibility before TUI startup.
        for connection in -1..(if explicit_escape_only { 1 } else { 7 }) {
            let mut socket = loop {
                let (stream, _) = listener.accept().await?;
                // Startup probes the default daemon socket before opening its WebSocket.
                if let Ok(socket) = tokio_tungstenite::accept_async(stream).await {
                    break socket;
                }
            };
            loop {
                let frame = tokio::select! {
                    _ = &mut disconnect_rx, if connection == 0 => {
                        socket.close(/*msg*/ None).await?;
                        break;
                    }
                    frame = socket.next() => frame,
                };
                let Some(Ok(Message::Text(text))) = frame else {
                    break;
                };
                let JSONRPCMessage::Request(request) = serde_json::from_str(&text)? else {
                    continue;
                };
                methods.push(request.method.clone());
                if connection == 1 && request.method == "initialize" {
                    restore_rx.take().unwrap().await?;
                }
                // Keep failing past the original five-attempt limit.
                if (1..=5).contains(&connection) && request.method == "thread/resume" {
                    socket
                        .send(Message::Text(
                            json!({"id": request.id, "error": {
                                "code": -32600,
                                "message": format!("thread {id} is closing; retry after the thread is closed")
                            }})
                            .to_string()
                            .into(),
                        ))
                        .await?;
                    continue;
                }
                let result = match request.method.as_str() {
                    "initialize" => json!({"userAgent": "reconnect-pty"}),
                    // An older daemon can omit the client's default-disabled features.
                    "experimentalFeature/list" => {
                        json!({"data": (["code_mode_host", "auth_elicitation"].map(|name| json!({
                        "name": name, "stage": "stable", "displayName": null,
                        "description": null, "announcement": null,
                        "enabled": true, "defaultEnabled": true,
                    }))), "nextCursor": null})
                    }
                    "account/read" => {
                        json!({"account": {"type": "apiKey"}, "requiresOpenaiAuth": false})
                    }
                    "model/list" => json!({"data": [], "nextCursor": null}),
                    "config/read" => {
                        json!({"config": {"model": "gpt-5.6-terra", "model_provider": "openai",
                        "tui": {"status_line": ["thread-id"]}, "projects": {
                        server_cwd.to_string_lossy(): {"trust_level": "trusted"}
                    }}, "origins": {}, "layers": []})
                    }
                    "configRequirements/read" => json!({"requirements": null}),
                    "thread/start" | "thread/resume" => {
                        json!({"thread": thread, "model": "gpt-5.6-terra", "modelProvider": "openai",
                            "cwd": server_cwd, "approvalPolicy": "never", "approvalsReviewer": "user",
                            "sandbox": {"type": "readOnly"}, "reasoningEffort": null})
                    }
                    "thread/read" => json!({"thread": thread}),
                    "thread/goal/get" => json!({"goal": null}),
                    "turn/interrupt" => json!({}),
                    "skills/list" => json!({"data": []}),
                    _ => {
                        socket
                            .send(Message::Text(
                                json!({"id": request.id, "error": {
                                    "code": -32601, "message": "method not found"
                                }})
                                .to_string()
                                .into(),
                            ))
                            .await?;
                        continue;
                    }
                };
                socket
                    .send(Message::Text(
                        json!({"id": request.id, "result": result})
                            .to_string()
                            .into(),
                    ))
                    .await?;
                // Publish completion only after the response has been sent, so the
                // positive fixture cannot close the peer during this awaited send.
                if request.method == "turn/interrupt" {
                    server_interrupt_count.fetch_add(1, Ordering::SeqCst);
                }
                if connection == 6 && request.method == "thread/resume" {
                    // Keep the recovered turn running: its output must appear without waiting
                    // for turn/completed or rebuilding the transcript.
                    socket
                        .send(Message::Text(
                            json!({
                                "method": "item/agentMessage/delta", "params": {
                                    "threadId": id, "turnId": "running", "itemId": "live-item",
                                    "delta": "fresh-notification-after-reconnect\n"
                                }
                            })
                            .to_string()
                            .into(),
                        ))
                        .await?;
                }
            }
        }
        Ok::<_, anyhow::Error>(methods)
    });
    let mut terminal = PtyCodex::start_cli(&repo_root, codex_home, &["--no-alt-screen"])?;
    terminal.wait_for_startup()?;
    let mut disconnect_tx = Some(disconnect_tx);
    let mut restore_tx = Some(restore_tx);
    for expected in [
        id, // The model label does not establish that the client has attached a thread.
        "preserved-draft",
        "Reconnecting",
        "preserved-draft!",
        "fresh-notification-after-reconnect",
    ] {
        let deadline = Instant::now() + Duration::from_secs(/*secs*/ 60);
        while !terminal.screen_contains(expected) && Instant::now() < deadline {
            terminal.read_output(Duration::from_millis(/*millis*/ 20))?;
            terminal.answer_startup_queries()?;
        }
        ensure!(
            terminal.screen_contains(expected),
            "missing {expected}; screen:\n{}",
            terminal.screen_contents()
        );
        match expected {
            ready if ready == id => {
                let frame_deadline = Instant::now() + Duration::from_secs(5);
                while !terminal.answered_framed_keyboard_query() && Instant::now() < frame_deadline
                {
                    terminal.read_output(Duration::from_millis(20))?;
                    terminal.answer_startup_queries()?;
                }
                ensure!(
                    terminal.answered_framed_keyboard_query(),
                    "full CLI did not emit a complete framed keyboard query"
                );
                // Do not let the initial one-second Pending protection alone make
                // the negative interrupt assertion pass. This remains an integration
                // stimulus: split writes do not prove distinct child read calls.
                let settle_until = Instant::now() + Duration::from_millis(1200);
                while Instant::now() < settle_until {
                    terminal.read_output(Duration::from_millis(20))?;
                    terminal.answer_startup_queries()?;
                }
                if explicit_escape_only {
                    // An independent client receives no mouse fragments or reconnect.
                    // A delayed negative-scenario interrupt cannot satisfy this control.
                    assert_eq!(interrupt_count.load(Ordering::SeqCst), 0);
                    terminal.write_input(b"\x1b[27u")?;
                    let deadline = Instant::now() + Duration::from_secs(5);
                    while interrupt_count.load(Ordering::SeqCst) == 0 && Instant::now() < deadline {
                        terminal.read_output(Duration::from_millis(20))?;
                        terminal.answer_startup_queries()?;
                    }
                    assert_eq!(interrupt_count.load(Ordering::SeqCst), 1);
                    drop(terminal);
                    let methods = tokio::time::timeout(Duration::from_secs(5), server).await???;
                    assert_eq!(methods.iter().filter(|m| *m == "turn/interrupt").count(), 1);
                    assert!(
                        !methods
                            .iter()
                            .any(|m| m == "turn/start" || m == "thread/resume")
                    );
                    return Ok(());
                }
                // Exercise input gaps longer than the legacy Escape timeout.
                for delay_ms in [30, 60, 250] {
                    terminal.write_input(b"\x1b")?;
                    tokio::time::sleep(Duration::from_millis(delay_ms)).await;
                    terminal.write_input(b"[<65;101;20M")?;
                }
                terminal.write_input(b"preserved-draft")?;
            }
            "preserved-draft" => {
                disconnect_tx.take().unwrap().send(()).unwrap();
            }
            "Reconnecting" => terminal.write_input(b"!")?,
            "preserved-draft!" => {
                restore_tx.take().unwrap().send(()).unwrap();
            }
            _ => {}
        }
    }
    // A PTY read can expose the history write before the same terminal update redraws the
    // composer. Wait for both pieces in the same parsed screen before checking recovery.
    let deadline = Instant::now() + Duration::from_secs(/*secs*/ 30);
    while !(terminal.screen_contains("preserved-draft!")
        && terminal.screen_contains("fresh-notification-after-reconnect"))
        && Instant::now() < deadline
    {
        terminal.read_output(Duration::from_millis(/*millis*/ 20))?;
        terminal.answer_startup_queries()?;
    }
    ensure!(
        terminal.screen_contains("preserved-draft!")
            && terminal.screen_contains("fresh-notification-after-reconnect"),
        "draft and notification did not remain visible after recovery; screen:\n{}",
        terminal.screen_contents()
    );
    drop(terminal);
    let methods = tokio::time::timeout(Duration::from_secs(/*secs*/ 5), server).await???;
    assert_eq!(
        methods
            .iter()
            .filter(|method| *method == "thread/resume")
            .count(),
        6
    );
    assert!(!methods.iter().any(|method| method == "turn/start"));
    assert!(
        !methods.iter().any(|method| method == "turn/interrupt"),
        "fragmented terminal input or reconnect must not interrupt the running task: {methods:?}"
    );
    Ok(())
}
