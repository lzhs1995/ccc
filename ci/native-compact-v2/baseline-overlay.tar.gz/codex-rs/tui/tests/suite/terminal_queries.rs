//! Stateful terminal replies for the private PTY, including framed keyboard queries.
pub(crate) fn replies(output: &[u8], offset: &mut usize) -> Vec<u8> {
    let mut reply = Vec::new();
    while *offset < output.len() {
        let tail = &output[*offset..];
        let prefix = b"\x1b[?";
        if prefix.starts_with(tail) {
            break;
        }
        if !tail.starts_with(prefix) {
            *offset += 1;
            continue;
        }
        let rest = &tail[prefix.len()..];
        if rest.is_empty() {
            break;
        }
        if rest[0] == b'u' {
            reply.extend_from_slice(b"\x1b[?7u\x1b[?1;2c");
            *offset += prefix.len() + 1;
            continue;
        }
        let digits = rest.iter().take_while(|b| b.is_ascii_digit()).count();
        if digits > 0 {
            let suffix = &rest[digits..];
            if b"$p".starts_with(suffix) && suffix.len() < 2 {
                break;
            }
            if suffix.starts_with(b"$p") {
                reply.extend_from_slice(prefix);
                reply.extend_from_slice(&rest[..digits]);
                reply.extend_from_slice(b";0$y");
                *offset += prefix.len() + digits + 2;
                continue;
            }
        }
        *offset += 1;
    }
    reply
}

#[cfg(test)]
mod tests {
    use super::replies;

    #[test]
    fn every_split_preserves_order_and_replies_once() {
        let query = b"text\x1b[?29000$p\x1b[?30012$p\x1b[?u\x1b[?31012$p\x1b[?29003$p";
        let expected =
            b"\x1b[?29000;0$y\x1b[?30012;0$y\x1b[?7u\x1b[?1;2c\x1b[?31012;0$y\x1b[?29003;0$y";
        for split in 0..=query.len() {
            let mut offset = 0;
            let mut actual = replies(&query[..split], &mut offset);
            actual.extend(replies(query, &mut offset));
            assert_eq!(actual, expected, "split {split}");
            assert!(replies(query, &mut offset).is_empty());
        }
    }

    #[test]
    fn bytewise_and_reacquisition() {
        let query = b"\x1b[?29000$p\x1b[?u\x1b[?29003$p\x1b[?29000$p\x1b[?u\x1b[?29003$p";
        let mut offset = 0;
        let mut actual = Vec::new();
        for end in 1..=query.len() {
            actual.extend(replies(&query[..end], &mut offset));
        }
        let mut once_offset = 0;
        assert_eq!(actual, replies(query, &mut once_offset));
        assert_eq!(actual.windows(5).filter(|w| *w == b"\x1b[?7u").count(), 2);
    }

    #[test]
    fn unrelated_sequences_do_not_generate_keyboard_replies() {
        let mut offset = 0;
        assert!(replies(b"\x1b[?25h\x1b[?1049l\x1b[6nplain", &mut offset).is_empty());
    }
}
