use super::*;
use serde_json::Value;
use std::fs;
use std::os::unix::fs::PermissionsExt;

fn opt_in(home: &Path) -> std::path::PathBuf {
    let directory = home.join("credential-observations");
    fs::create_dir(&directory).unwrap();
    fs::set_permissions(&directory, fs::Permissions::from_mode(0o700)).unwrap();
    let marker = directory.join("enabled-v1");
    fs::write(&marker, b"ccc-request-credentials-v1\n").unwrap();
    fs::set_permissions(marker, fs::Permissions::from_mode(0o600)).unwrap();
    directory.join(format!("client-{}-thread.json", std::process::id()))
}

#[tokio::test]
async fn committed_selection_and_clear_replace_the_foreground_record() {
    let home = tempfile::tempdir().unwrap();
    let path = opt_in(home.path());
    let (mut app, _event_rx, _op_rx) = crate::app::tests::make_test_app_with_channels().await;
    app.config.codex_home = home.path().to_path_buf().try_into().unwrap();
    let first = ThreadId::new();
    let second = ThreadId::new();
    app.activate_thread_channel(first).await;
    let before: Value = serde_json::from_slice(&fs::read(&path).unwrap()).unwrap();
    assert_eq!(before["thread_id"], first.to_string());
    app.clear_active_thread().await;
    let cleared: Value = serde_json::from_slice(&fs::read(&path).unwrap()).unwrap();
    assert_eq!(cleared["thread_id"], Value::Null);
    app.activate_thread_channel(second).await;
    let after: Value = serde_json::from_slice(&fs::read(&path).unwrap()).unwrap();
    assert_eq!(after["thread_id"], second.to_string());
    assert_eq!(after["client_epoch"], before["client_epoch"]);
    assert_eq!(
        fs::metadata(path).unwrap().permissions().mode() & 0o777,
        0o600
    );
}

#[test]
fn removed_opt_in_clears_previous_selection() {
    let home = tempfile::tempdir().unwrap();
    let path = opt_in(home.path());
    publish(home.path(), Some(ThreadId::new()));
    assert!(path.exists());
    fs::remove_file(path.parent().unwrap().join("enabled-v1")).unwrap();
    publish(home.path(), Some(ThreadId::new()));
    assert!(!path.exists());
}

#[test]
fn invalid_marker_and_symlink_directory_do_not_publish() {
    let home = tempfile::tempdir().unwrap();
    let path = opt_in(home.path());
    fs::write(path.parent().unwrap().join("enabled-v1"), b"disabled").unwrap();
    publish(home.path(), Some(ThreadId::new()));
    assert!(!path.exists());
    let directory = home.path().join("credential-observations");
    let moved = home.path().join("moved");
    fs::rename(&directory, &moved).unwrap();
    std::os::unix::fs::symlink(&moved, &directory).unwrap();
    publish(home.path(), Some(ThreadId::new()));
    assert!(!path.exists());
}

#[test]
fn symlink_replacement_does_not_delete_another_directory_record() {
    let home = tempfile::tempdir().unwrap();
    let path = opt_in(home.path());
    publish(home.path(), Some(ThreadId::new()));
    let directory = home.path().join("credential-observations");
    fs::rename(&directory, home.path().join("original")).unwrap();
    let other = tempfile::tempdir().unwrap();
    let other_path = opt_in(other.path());
    fs::write(&other_path, b"unrelated record").unwrap();
    std::os::unix::fs::symlink(other_path.parent().unwrap(), &directory).unwrap();
    publish(home.path(), Some(ThreadId::new()));
    assert_eq!(fs::read(&path).unwrap(), b"unrelated record");
}
