//! Session configuration and thread-header orchestration for `ChatWidget`.
//! Confirmed model-picker changes can offer the flourish only on their original task; the app
//! checks the previous model when it applies the final selection.

use super::*;
use crate::style::accent_color;

impl ChatWidget {
    /// Offer the flourish only for a successful primary thread/start without initial work.
    pub(crate) fn mark_fresh_task_for_sparkle(
        &mut self,
        started: &crate::app_server_session::AppServerStartedThread,
    ) {
        if started.turns.is_empty()
            && started.session.forked_from_id.is_none()
            && !started.blocks_direct_input
            && self.initial_user_message.is_none()
            && !self.is_user_turn_pending_or_running()
        {
            self.bottom_pane
                .mark_fresh_task_for_sparkle(&started.session.model, &self.local_settings.tui);
        } else {
            self.bottom_pane.dismiss_composer_sparkle();
        }
    }

    pub(crate) fn set_sparkle_terminal_focus(&mut self, focused: bool) {
        self.bottom_pane.set_sparkle_terminal_focus(focused);
    }

    pub(crate) fn prepare_composer_sparkle_key(&self, key: KeyEvent) {
        self.bottom_pane.prepare_composer_sparkle_key(key);
    }

    pub(crate) fn sparkle_thread_for_picker_action(&self, model: &str) -> Option<ThreadId> {
        self.thread_id()
            .filter(|_| BottomPane::is_sparkle_model(model))
    }

    pub(crate) fn on_sparkle_model_selected_from_picker(&mut self, model: &str) {
        if self.current_model() == model {
            self.bottom_pane
                .select_sparkle_model(model, &self.local_settings.tui);
        }
    }

    fn on_session_configured_with_display_and_fork_parent_title(
        &mut self,
        session: ThreadSessionState,
        display: SessionConfiguredDisplay,
        fork_parent_title: Option<String>,
    ) {
        self.windows_sandbox_host =
            if !self.windows_sandbox_local_server && self.remote_connection.is_some() {
                crate::app::WindowsSandboxHost::Remote
            } else {
                session.windows_sandbox_host
            };
        self.invalidate_permission_discovery();
        self.permission_profiles_menu_opened = false;
        self.transcript.reset_copy_history();
        let history_metadata = session.message_history.unwrap_or_default();
        self.bottom_pane.set_history_metadata(
            session.thread_id,
            history_metadata.log_id,
            history_metadata.entry_count,
        );
        self.set_skills(/*skills*/ None);
        self.session_network_proxy = session.network_proxy.clone();
        let previous_thread_id = self.thread_id;
        // Startup already requests this cwd's catalog. Reuse the effective-config cache for
        // the first session; subsequent sessions and cwd changes still explicitly refresh.
        let refresh_skill_sources =
            previous_thread_id.is_some() || self.config.cwd.as_path() != session.cwd.as_path();
        let connector_scope_changed = previous_thread_id != Some(session.thread_id)
            || self.config.cwd.as_path() != session.cwd.as_path();
        self.thread_id = Some(session.thread_id);
        #[cfg(target_os = "windows")]
        if self.windows_sandbox_local_server
            && matches!(self.codex_op_target, CodexOpTarget::AppEvent)
        {
            self.windows_sandbox_config = Default::default();
            self.set_windows_sandbox_mode(/*mode*/ None);
            self.app_event_tx.send(AppEvent::RefreshWindowsSandbox {
                thread_id: session.thread_id,
            });
        }
        self.realtime_conversation_available_for_thread =
            self.config.features.enabled(Feature::RealtimeConversation)
                && codex_realtime_webrtc::RealtimeWebrtcSession::is_supported();
        self.bottom_pane
            .set_voice_command_enabled(self.realtime_conversation_available_for_thread);
        self.bottom_pane
            .set_queue_submissions(/*queue_submissions*/ false);
        if previous_thread_id != self.thread_id {
            self.backend_banner_notice_model = None;
            self.automatic_model_switch_state =
                backend_banners::AutomaticModelSwitchState::default();
            self.review.recent_auto_review_denials = RecentAutoReviewDenials::default();
            self.clear_thread_usage_state();
        }
        self.turn_lifecycle.reset_thread();
        self.clear_safety_buffering();
        self.thread_name = session.thread_name.clone();
        self.current_goal_status_indicator = None;
        self.current_goal_status = None;
        self.update_collaboration_mode_indicator();
        self.forked_from = session.forked_from_id;
        self.current_rollout_path = session.rollout_path.clone();
        self.current_cwd = Some(session.cwd.to_path_buf());
        self.config.cwd = session.cwd.clone();
        self.config.model_provider_id = session.model_provider_id.clone();
        if connector_scope_changed {
            self.invalidate_connector_scope();
        }
        let runtime_workspace_roots = session.runtime_workspace_roots.clone();
        self.config.workspace_roots = runtime_workspace_roots.clone();
        self.config
            .permissions
            .set_workspace_roots(runtime_workspace_roots);
        self.effective_service_tier = session.service_tier.clone();
        if let Err(err) = self
            .config
            .permissions
            .approval_policy
            .set(session.approval_policy.to_core())
        {
            tracing::warn!(%err, "failed to sync approval_policy from SessionConfigured");
            self.config.permissions.approval_policy =
                Constrained::allow_only(session.approval_policy.to_core());
        }
        let permission_snapshot = PermissionProfileSnapshot::from_session_snapshot(
            session.permission_profile.clone(),
            session.active_permission_profile.clone(),
        );
        let permission_sync = self
            .config
            .permissions
            .set_permission_profile_from_session_snapshot(permission_snapshot.clone());
        if let Err(err) = permission_sync {
            tracing::warn!(%err, "failed to sync permissions from SessionConfigured");
            if let Err(replace_err) = self
                .config
                .permissions
                .replace_permission_profile_from_session_snapshot(permission_snapshot)
            {
                tracing::error!(
                    %replace_err,
                    "failed to replace permissions from SessionConfigured after constraint fallback"
                );
            }
        }
        self.config.approvals_reviewer = session.approvals_reviewer;
        self.config.personality = session.personality;
        self.status_line_project_root_name_cache = None;
        let forked_from_id = session.forked_from_id;
        let default_model = session.model.clone();
        self.current_collaboration_mode = self.current_collaboration_mode.with_updates(
            Some(default_model.clone()),
            Some(session.reasoning_effort.clone()),
            /*developer_instructions*/ None,
        );
        if session.reasoning_effort == Some(ReasoningEffortConfig::Ultra) {
            self.set_plan_mode_reasoning_effort(Some(ReasoningEffortConfig::Ultra));
        }
        match session.collaboration_mode.as_deref() {
            Some(collaboration_mode) => {
                self.set_effective_collaboration_mode(collaboration_mode.clone());
            }
            None => {
                self.active_collaboration_mask = Self::initial_collaboration_mask(
                    &self.config,
                    self.model_catalog.as_ref(),
                    Some(&default_model),
                );
                if let Some(mask) = self.active_collaboration_mask.as_mut() {
                    mask.reasoning_effort = Some(session.reasoning_effort.clone());
                }
                self.update_collaboration_mode_indicator();
            }
        }
        let effort = self.effective_reasoning_effort();
        self.bottom_pane
            .set_active_reasoning_effort_baseline(effort.as_ref());
        self.refresh_model_display();
        self.refresh_status_surfaces();
        if previous_thread_id != self.thread_id
            && self.should_prefetch_rate_limits()
            && (self.current_model() == crate::model_catalog::LUNA_RESERVE_MODEL
                || self.backend_banner_fallback().is_some())
        {
            // Reconcile this task with retained account state before sending its initial/queued
            // prompt. Do not wait for the next usage poll after /new, /resume or a thread switch.
            self.hold_rate_limit_recovery();
            self.app_event_tx
                .send(AppEvent::ApplyBackendBannerFallback {
                    thread_id: session.thread_id,
                });
        }
        self.sync_service_tier_commands();
        self.sync_worktrees_enabled();
        self.sync_plugins_command_enabled();
        self.sync_goal_command_enabled();
        self.refresh_plugin_mentions();
        let model_for_header = self.current_model().to_string();
        if display == SessionConfiguredDisplay::Normal {
            let startup_tooltip_override = self.startup_tooltip_override.take();
            let mut session_info_cell = history_cell::new_session_info(
                &self.config,
                &self.local_settings,
                &model_for_header,
                self.model_catalog.display_name(&session.model),
                &session,
                self.show_welcome_banner,
                startup_tooltip_override,
                self.plan_type,
            );
            history_cell::set_session_greeting(
                &mut session_info_cell,
                &self.empty_state_animation.borrow().greeting,
            );
            self.apply_session_info_cell(session_info_cell);
        } else if self
            .transcript
            .active_cell
            .as_ref()
            .is_some_and(|cell| cell.as_any().is::<history_cell::SessionHeaderHistoryCell>())
        {
            self.transcript.active_cell = None;
            self.bump_active_cell_revision();
        }
        self.transcript.saw_copy_source_this_turn = false;
        self.refresh_skills_for_current_cwd(refresh_skill_sources);
        self.refresh_connector_mentions(/*force_refresh*/ false);
        let initial_user_message_pending = self.initial_user_message.is_some();
        self.submit_initial_user_message_if_pending();
        if self.mcp_startup_status.is_none()
            && (!initial_user_message_pending || self.is_user_turn_pending_or_running())
        {
            self.maybe_send_next_queued_input();
        }
        if display == SessionConfiguredDisplay::Normal
            && let Some(forked_from_id) = forked_from_id
        {
            self.emit_forked_thread_event(forked_from_id, fork_parent_title);
        }
        if !self.suppress_session_configured_redraw {
            self.request_redraw();
        }
    }

    pub(crate) fn handle_thread_session(&mut self, session: ThreadSessionState) {
        self.instruction_source_paths = session.instruction_source_paths.clone();
        let fork_parent_title = session.fork_parent_title.clone();
        self.on_session_configured_with_display_and_fork_parent_title(
            session,
            SessionConfiguredDisplay::Normal,
            fork_parent_title,
        );
    }

    pub(crate) fn handle_thread_session_quiet(&mut self, session: ThreadSessionState) {
        self.instruction_source_paths = session.instruction_source_paths.clone();
        self.on_session_configured_with_display_and_fork_parent_title(
            session,
            SessionConfiguredDisplay::Quiet,
            /*fork_parent_title*/ None,
        );
    }

    pub(crate) fn handle_side_thread_session(&mut self, session: ThreadSessionState) {
        self.instruction_source_paths = session.instruction_source_paths.clone();
        let fork_parent_title = session.fork_parent_title.clone();
        self.on_session_configured_with_display_and_fork_parent_title(
            session,
            SessionConfiguredDisplay::SideConversation,
            fork_parent_title,
        );
    }

    pub(super) fn emit_forked_thread_event(
        &mut self,
        forked_from_id: ThreadId,
        fork_parent_title: Option<String>,
    ) {
        let forked_from_id_text = forked_from_id.to_string();
        let line: Line<'static> = if let Some(name) = fork_parent_title
            && !name.trim().is_empty()
        {
            vec![
                "• ".dim(),
                "Thread forked from ".into(),
                name.fg(accent_color()),
                " (".into(),
                forked_from_id_text.fg(accent_color()),
                ")".into(),
            ]
            .into()
        } else {
            vec![
                "• ".dim(),
                "Thread forked from ".into(),
                forked_from_id_text.fg(accent_color()),
            ]
            .into()
        };
        self.app_event_tx.send(AppEvent::InsertHistoryCell(Box::new(
            PlainHistoryCell::new(vec![line]),
        )));
    }

    /// Clear history-derived state while preserving this thread's settings and goal.
    pub(crate) fn reset_after_prompt_revert(
        &mut self,
        rollout_path: Option<PathBuf>,
        retained_turns: &[Turn],
    ) {
        self.current_rollout_path = rollout_path;
        self.input_queue.clear();
        self.reset_realtime_conversation();
        // Finish any output not yet drained from the old runtime without live completion actions.
        self.on_task_complete(
            /*last_agent_message*/ None, /*completion*/ None, /*from_replay*/ true,
        );
        self.turn_lifecycle.reset_thread();
        self.review = Default::default();
        self.transcript.take_active_cell();
        self.transcript.reset_copy_history();
        self.transcript.reset_turn_flags();
        for turn in retained_turns {
            let mut replaying_delegation = false;
            for item in &turn.items {
                if matches!(item, ThreadItem::UserMessage { content, .. }
                    if realtime::realtime_delegation_input(content).is_some())
                {
                    replaying_delegation = true;
                }
                if replaying_delegation && realtime::is_private_realtime_agent_item(item) {
                    continue;
                }
                let (markdown, source) = match item {
                    ThreadItem::AgentMessage { text, .. } => (
                        parse_assistant_markdown(text, self.config.cwd.as_path()).visible_markdown,
                        text,
                    ),
                    ThreadItem::Plan { text, .. } => (text.clone(), text),
                    _ => continue,
                };
                if !markdown.trim().is_empty() {
                    self.transcript
                        .record_agent_markdown(markdown, source.clone());
                }
            }
        }
        self.transcript.last_plan_progress = None;
        self.last_rendered_user_message_display = None;
        self.last_rendered_user_message_client_id = None;
        self.clear_pending_rate_limit_reset_hint();
        self.set_token_info(/*info*/ None);
        self.bottom_pane.clear_pending_questions();
        self.bottom_pane.set_task_running(/*running*/ false);
        self.refresh_status_surfaces();
    }

    pub(crate) fn emit_prompt_edit_thread_event(&mut self) {
        let line: Line<'static> = vec![
            "• ".dim(),
            "Conversation reverted to this point. File changes are unchanged.".into(),
        ]
        .into();
        self.app_event_tx.send(AppEvent::InsertHistoryCell(Box::new(
            PlainHistoryCell::new(vec![line]),
        )));
    }

    /// Update status surfaces before a confirmed manual rename's server notification arrives.
    pub(crate) fn expect_manual_thread_name(&mut self, thread_id: ThreadId, name: String) {
        if self.thread_id == Some(thread_id) {
            self.thread_name = Some(name);
            self.refresh_status_surfaces();
            self.request_redraw();
        }
    }

    /// Update name metadata silently, including late and replayed notifications.
    pub(crate) fn on_thread_name_updated(
        &mut self,
        thread_id: ThreadId,
        thread_name: Option<String>,
    ) {
        if self.thread_id == Some(thread_id) {
            self.thread_name = thread_name;
            self.refresh_status_surfaces();
            self.request_redraw();
            self.maybe_send_next_queued_input();
        }
    }

    pub(super) fn set_skills(&mut self, skills: Option<Vec<SkillMetadata>>) {
        self.bottom_pane.set_skills(skills);
    }
}
