//! Shared on-disk candidate set for managed daemon restarts.

use std::collections::BTreeMap;
use std::collections::BTreeSet;
use std::io;
use std::path::Path;

use codex_core::path_utils::write_atomically;
use serde::Deserialize;
use serde::Serialize;

#[derive(Debug, Default, Deserialize, Serialize, PartialEq, Eq)]
pub struct RecoverySnapshot {
    #[serde(skip)]
    pub loaded: BTreeSet<String>,
    pub interrupted: BTreeMap<String, InterruptedTurn>,
    #[serde(default)]
    pub providers: BTreeMap<String, SavedProvider>,
}

/// Provider definition owned by one saved thread; never format its credentials.
#[derive(Clone, Deserialize, Serialize, PartialEq, Eq)]
pub struct SavedProvider {
    pub id: String,
    pub definition: serde_json::Value,
}

impl std::fmt::Debug for SavedProvider {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("SavedProvider")
            .field("id", &self.id)
            .finish_non_exhaustive()
    }
}

#[derive(Clone, Debug, Deserialize, Serialize, PartialEq, Eq)]
pub struct InterruptedTurn {
    pub turn_id: String,
    pub output_schema: Option<serde_json::Value>,
    pub service_tier: Option<String>,
    pub cyber_access_program: Option<codex_protocol::turn_input::CyberAccessProgram>,
    /// Only local execution with thread-owned configuration can continue automatically.
    /// Older snapshots without this identity are reloaded without continuation.
    pub local_environment: Option<codex_app_server_protocol::ThreadEnvironment>,
}

// Old servers accept the array and skip this non-thread entry during best-effort
// restoration. Keeping metadata in the same atomic file avoids stale sidecars.
const INTERRUPTION_PREFIX: &str = "codex-interrupted-v1:";

pub fn read_snapshot(path: &Path) -> io::Result<RecoverySnapshot> {
    let mut loaded: BTreeSet<String> = match std::fs::read(path) {
        Ok(contents) => serde_json::from_slice(&contents).map_err(io::Error::other)?,
        Err(err) if err.kind() == io::ErrorKind::NotFound => return Ok(RecoverySnapshot::default()),
        Err(err) => return Err(err),
    };
    let mut snapshot = RecoverySnapshot::default();
    let mut metadata_entry = None;
    for entry in &loaded {
        if let Some(metadata) = entry.strip_prefix(INTERRUPTION_PREFIX) {
            if metadata_entry.is_some() {
                return Err(io::Error::new(
                    io::ErrorKind::InvalidData,
                    "multiple daemon recovery metadata records",
                ));
            }
            snapshot = serde_json::from_str(metadata).map_err(|_| {
                io::Error::new(
                    io::ErrorKind::InvalidData,
                    "invalid daemon recovery metadata",
                )
            })?;
            metadata_entry = Some(entry.clone());
        }
    }
    if let Some(entry) = metadata_entry {
        loaded.remove(&entry);
    }
    snapshot.interrupted.retain(|id, _| loaded.contains(id));
    snapshot.providers.retain(|id, _| loaded.contains(id));
    snapshot.loaded = loaded;
    Ok(snapshot)
}

#[cfg(test)]
#[path = "daemon_recovery_tests.rs"]
mod tests;

pub fn read_candidates(path: &Path) -> io::Result<BTreeSet<String>> {
    Ok(read_snapshot(path)?.loaded)
}

pub fn write_candidates(path: &Path, candidates: &BTreeSet<String>) -> io::Result<()> {
    write_snapshot(
        path,
        &RecoverySnapshot {
            loaded: candidates.clone(),
            ..Default::default()
        },
    )
}

pub fn write_snapshot(path: &Path, snapshot: &RecoverySnapshot) -> io::Result<()> {
    let mut saved = snapshot.loaded.clone();
    if !snapshot.interrupted.is_empty() || !snapshot.providers.is_empty() {
        saved.insert(format!(
            "{INTERRUPTION_PREFIX}{}",
            serde_json::to_string(snapshot).map_err(io::Error::other)?
        ));
    }
    write_atomically(
        path,
        &serde_json::to_string(&saved).map_err(io::Error::other)?,
    )
}
