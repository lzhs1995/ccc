use super::*;
use pretty_assertions::assert_eq;
use serde_json::json;

#[test]
fn provider_only_snapshot_roundtrips_without_exposing_debug_credentials() {
    let dir = tempfile::tempdir().unwrap();
    let path = dir.path().join("recovery.json");
    let snapshot = RecoverySnapshot {
        loaded: BTreeSet::from(["thread-a".to_owned(), "thread-b".to_owned()]),
        providers: [("thread-a", "fake-key-a"), ("thread-b", "fake-key-b")]
            .into_iter()
            .map(|(thread, key)| {
                (
                    thread.to_owned(),
                    SavedProvider {
                        id: "same-provider".to_owned(),
                        definition: json!({"experimental_bearer_token": key}),
                    },
                )
            })
            .collect(),
        ..Default::default()
    };
    write_snapshot(&path, &snapshot).unwrap();
    assert_eq!(read_snapshot(&path).unwrap(), snapshot);
    assert!(!format!("{snapshot:?}").contains("fake-key-"));
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        assert_eq!(
            std::fs::metadata(&path).unwrap().permissions().mode() & 0o777,
            0o600
        );
    }
}

#[test]
fn removed_thread_does_not_retain_provider_credentials() {
    let dir = tempfile::tempdir().unwrap();
    let path = dir.path().join("recovery.json");
    let snapshot = RecoverySnapshot {
        providers: BTreeMap::from([(
            "removed".to_owned(),
            SavedProvider {
                id: "provider".to_owned(),
                definition: json!({"experimental_bearer_token": "fake-removed-key"}),
            },
        )]),
        ..Default::default()
    };
    write_snapshot(&path, &snapshot).unwrap();
    assert_eq!(read_snapshot(&path).unwrap(), RecoverySnapshot::default());
}

#[test]
fn corrupt_metadata_cannot_silently_fall_back_to_global_credentials() {
    let dir = tempfile::tempdir().unwrap();
    let path = dir.path().join("recovery.json");
    for metadata in ["{", r#"{"interrupted":{},"providers":{"thread-a":null}}"#] {
        let records = [
            "thread-a".to_owned(),
            format!("{INTERRUPTION_PREFIX}{metadata}"),
        ];
        std::fs::write(&path, serde_json::to_vec(&records).unwrap()).unwrap();
        assert_eq!(
            read_snapshot(&path).unwrap_err().kind(),
            io::ErrorKind::InvalidData
        );
    }
}

#[test]
fn ambiguous_metadata_is_rejected_instead_of_selecting_one_provider() {
    let dir = tempfile::tempdir().unwrap();
    let path = dir.path().join("recovery.json");
    let records = [
        "thread-a".to_owned(),
        format!("{INTERRUPTION_PREFIX}{{\"interrupted\":{{}}}}"),
        format!("{INTERRUPTION_PREFIX}{{\"interrupted\":{{}},\"providers\":{{}}}}"),
    ];
    std::fs::write(&path, serde_json::to_vec(&records).unwrap()).unwrap();
    assert_eq!(
        read_snapshot(&path).unwrap_err().kind(),
        io::ErrorKind::InvalidData
    );
}

#[test]
fn legacy_candidate_list_remains_readable_without_invented_provider() {
    let dir = tempfile::tempdir().unwrap();
    let path = dir.path().join("recovery.json");
    std::fs::write(&path, r#"["thread-a"]"#).unwrap();
    assert_eq!(
        read_snapshot(&path).unwrap(),
        RecoverySnapshot {
            loaded: BTreeSet::from(["thread-a".to_owned()]),
            ..Default::default()
        }
    );
}
