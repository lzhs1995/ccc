use std::io;
use std::panic::AssertUnwindSafe;
use std::panic::catch_unwind;
use std::sync::Arc;
use std::sync::Weak;
use std::sync::atomic::AtomicUsize;
use std::sync::atomic::Ordering;
use std::sync::mpsc::SyncSender;
use std::sync::mpsc::TrySendError;
use std::sync::mpsc::sync_channel;

type Work = Box<dyn FnOnce(Cancellation) + Send + 'static>;

/// A turn owns the strong reference. Queued work must never extend its lifetime.
pub(crate) struct Cancellation(Weak<()>);

impl Cancellation {
    pub(crate) fn is_cancelled(&self) -> bool {
        self.0.strong_count() == 0
    }
}

struct Reservation {
    used: Arc<AtomicUsize>,
    bytes: usize,
}

impl Drop for Reservation {
    fn drop(&mut self) {
        self.used.fetch_sub(self.bytes, Ordering::AcqRel);
    }
}

struct Job {
    _reservation: Reservation,
    cancellation: Cancellation,
    work: Work,
}

#[derive(Debug, PartialEq, Eq)]
pub(crate) enum Submission {
    Queued,
    Cancelled,
    Full,
    ByteLimit,
    Unavailable,
}

/// One serial worker and a bounded pending queue; submission never waits for work.
/// A shared instance bounds CPU concurrency across all sessions in one server.
/// Callers must bound captured input size and report rejected telemetry explicitly.
pub(crate) struct BoundedWorker {
    sender: SyncSender<Job>,
    used: Arc<AtomicUsize>,
    byte_limit: usize,
}

impl BoundedWorker {
    pub(crate) fn new(capacity: usize, byte_limit: usize) -> io::Result<Self> {
        let (sender, receiver) = sync_channel::<Job>(capacity);
        std::thread::Builder::new()
            .name("skill-shadow".to_owned())
            .spawn(move || {
                while let Ok(job) = receiver.recv() {
                    if !job.cancellation.is_cancelled() {
                        // A failed diagnostic must not kill the queue or model turn.
                        let _ = catch_unwind(AssertUnwindSafe(|| {
                            (job.work)(job.cancellation);
                        }));
                    }
                }
            })?;
        Ok(Self {
            sender,
            used: Arc::new(AtomicUsize::new(0)),
            byte_limit,
        })
    }

    pub(crate) fn submit(
        &self,
        owner: Weak<()>,
        retained_bytes: usize,
        work: impl FnOnce(Cancellation) + Send + 'static,
    ) -> Submission {
        let cancellation = Cancellation(owner);
        if cancellation.is_cancelled() {
            return Submission::Cancelled;
        }
        if self
            .used
            .fetch_update(Ordering::AcqRel, Ordering::Acquire, |used| {
                used.checked_add(retained_bytes)
                    .filter(|next| *next <= self.byte_limit)
            })
            .is_err()
        {
            return Submission::ByteLimit;
        }
        let reservation = Reservation {
            used: Arc::clone(&self.used),
            bytes: retained_bytes,
        };
        match self.sender.try_send(Job {
            _reservation: reservation,
            cancellation,
            work: Box::new(work),
        }) {
            Ok(()) => Submission::Queued,
            Err(TrySendError::Full(_)) => Submission::Full,
            Err(TrySendError::Disconnected(_)) => Submission::Unavailable,
        }
    }
}

#[cfg(test)]
#[path = "bounded_worker_tests.rs"]
mod tests;
