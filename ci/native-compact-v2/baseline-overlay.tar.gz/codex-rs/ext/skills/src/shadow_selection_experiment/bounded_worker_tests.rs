use super::*;
use std::sync::Arc;
use std::sync::mpsc::channel;
use std::time::Duration;

const DEADLINE: Duration = Duration::from_secs(5);

#[test]
fn full_queue_returns_without_waiting_for_running_work_and_preserves_fifo() {
    let worker = BoundedWorker::new(/*capacity*/ 2, /*byte_limit*/ 1024).unwrap();
    let owner = Arc::new(());
    let (started_tx, started_rx) = channel();
    let (release_tx, release_rx) = channel();
    assert_eq!(
        worker.submit(
            Arc::downgrade(&owner),
            /*retained_bytes*/ 1,
            move |_| {
                started_tx.send(()).unwrap();
                release_rx.recv_timeout(DEADLINE).unwrap();
            }
        ),
        Submission::Queued
    );
    started_rx.recv_timeout(DEADLINE).unwrap();
    let (tx, rx) = channel();
    for index in 0..2 {
        let tx = tx.clone();
        assert_eq!(
            worker.submit(
                Arc::downgrade(&owner),
                /*retained_bytes*/ 1,
                move |_| {
                    tx.send(index).unwrap();
                }
            ),
            Submission::Queued
        );
    }
    assert_eq!(
        worker.submit(
            Arc::downgrade(&owner),
            /*retained_bytes*/ 1,
            |_| panic!("full work ran")
        ),
        Submission::Full
    );
    release_tx.send(()).unwrap();
    assert_eq!(
        [
            rx.recv_timeout(DEADLINE).unwrap(),
            rx.recv_timeout(DEADLINE).unwrap()
        ],
        [0, 1]
    );
}

#[test]
fn expired_queued_turn_is_skipped_without_cancelling_new_turn() {
    let worker = BoundedWorker::new(/*capacity*/ 2, /*byte_limit*/ 1024).unwrap();
    let current = Arc::new(());
    let old = Arc::new(());
    let (started_tx, started_rx) = channel();
    let (release_tx, release_rx) = channel();
    worker.submit(
        Arc::downgrade(&current),
        /*retained_bytes*/ 1,
        move |_| {
            started_tx.send(()).unwrap();
            release_rx.recv_timeout(DEADLINE).unwrap();
        },
    );
    started_rx.recv_timeout(DEADLINE).unwrap();
    let (tx, rx) = channel();
    let old_tx = tx.clone();
    assert_eq!(
        worker.submit(Arc::downgrade(&old), /*retained_bytes*/ 1, move |_| {
            old_tx.send("old").unwrap();
        }),
        Submission::Queued
    );
    drop(old);
    assert_eq!(
        worker.submit(
            Arc::downgrade(&current),
            /*retained_bytes*/ 1,
            move |_| {
                tx.send("current").unwrap();
            }
        ),
        Submission::Queued
    );
    release_tx.send(()).unwrap();
    assert_eq!(rx.recv_timeout(DEADLINE).unwrap(), "current");
    assert!(rx.recv_timeout(DEADLINE).is_err());
}

#[test]
fn running_job_observes_cancellation_without_retaining_turn() {
    let worker = BoundedWorker::new(/*capacity*/ 1, /*byte_limit*/ 1024).unwrap();
    let owner = Arc::new(());
    let (started_tx, started_rx) = channel();
    let (release_tx, release_rx) = channel();
    let (tx, rx) = channel();
    worker.submit(
        Arc::downgrade(&owner),
        /*retained_bytes*/ 1,
        move |cancellation| {
            started_tx.send(cancellation.is_cancelled()).unwrap();
            release_rx.recv_timeout(DEADLINE).unwrap();
            tx.send(cancellation.is_cancelled()).unwrap();
        },
    );
    assert!(!started_rx.recv_timeout(DEADLINE).unwrap());
    drop(owner);
    release_tx.send(()).unwrap();
    assert!(rx.recv_timeout(DEADLINE).unwrap());
}

#[test]
fn panicking_diagnostic_does_not_prevent_following_job() {
    let worker = BoundedWorker::new(/*capacity*/ 2, /*byte_limit*/ 1024).unwrap();
    let owner = Arc::new(());
    assert_eq!(
        worker.submit(
            Arc::downgrade(&owner),
            /*retained_bytes*/ 1,
            |_| panic!("diagnostic failed")
        ),
        Submission::Queued
    );
    let (tx, rx) = channel();
    assert_eq!(
        worker.submit(
            Arc::downgrade(&owner),
            /*retained_bytes*/ 1,
            move |_| tx.send(()).unwrap()
        ),
        Submission::Queued
    );
    rx.recv_timeout(DEADLINE).unwrap();
}

#[test]
fn cancelled_submission_releases_captured_input() {
    let worker = BoundedWorker::new(/*capacity*/ 1, /*byte_limit*/ 1024).unwrap();
    let input = Arc::new(());
    let captured = Arc::clone(&input);
    assert_eq!(
        worker.submit(
            Weak::new(),
            /*retained_bytes*/ 1,
            move |_| drop(captured)
        ),
        Submission::Cancelled
    );
    assert_eq!(Arc::strong_count(&input), 1);
}

#[test]
fn byte_budget_covers_running_and_cancelled_queue_then_is_reusable() {
    let worker = BoundedWorker::new(/*capacity*/ 2, /*byte_limit*/ 10);
    let worker = worker.unwrap();
    let owner = Arc::new(());
    let cancelled = Arc::new(());
    let (tx, rx) = channel();
    let (release_tx, release_rx) = channel();
    assert_eq!(
        worker.submit(
            Arc::downgrade(&owner),
            /*retained_bytes*/ 4,
            move |_| {
                tx.send(()).unwrap();
                release_rx.recv_timeout(DEADLINE).unwrap();
            }
        ),
        Submission::Queued
    );
    rx.recv_timeout(DEADLINE).unwrap();
    assert_eq!(
        worker.submit(
            Arc::downgrade(&cancelled),
            /*retained_bytes*/ 6,
            |_| panic!("cancelled work ran")
        ),
        Submission::Queued
    );
    assert_eq!(
        worker.submit(
            Arc::downgrade(&owner),
            /*retained_bytes*/ 1,
            |_| panic!("over budget work ran")
        ),
        Submission::ByteLimit
    );
    assert_eq!(worker.used.load(Ordering::Acquire), 10);
    drop(cancelled);
    release_tx.send(()).unwrap();
    let until = std::time::Instant::now() + DEADLINE;
    while worker.used.load(Ordering::Acquire) != 0 {
        assert!(std::time::Instant::now() < until);
        std::thread::yield_now();
    }
    let (tx, rx) = channel();
    assert_eq!(
        worker.submit(
            Arc::downgrade(&owner),
            /*retained_bytes*/ 10,
            move |_| tx.send(()).unwrap()
        ),
        Submission::Queued
    );
    rx.recv_timeout(DEADLINE).unwrap();
}

#[test]
fn byte_budget_releases_after_panic_and_rejects_overflow() {
    let worker = BoundedWorker::new(/*capacity*/ 2, /*byte_limit*/ usize::MAX).unwrap();
    let owner = Arc::new(());
    let (tx, rx) = channel();
    let (release_tx, release_rx) = channel();
    assert_eq!(
        worker.submit(
            Arc::downgrade(&owner),
            /*retained_bytes*/ usize::MAX,
            move |_| {
                tx.send(()).unwrap();
                release_rx.recv_timeout(DEADLINE).unwrap();
                panic!("diagnostic failure");
            }
        ),
        Submission::Queued
    );
    rx.recv_timeout(DEADLINE).unwrap();
    assert_eq!(
        worker.submit(
            Arc::downgrade(&owner),
            /*retained_bytes*/ 1,
            |_| panic!("overflow job ran")
        ),
        Submission::ByteLimit
    );
    release_tx.send(()).unwrap();
    let until = std::time::Instant::now() + DEADLINE;
    while worker.used.load(Ordering::Acquire) != 0 {
        assert!(std::time::Instant::now() < until);
        std::thread::yield_now();
    }
    let (tx, rx) = channel();
    assert_eq!(
        worker.submit(
            Arc::downgrade(&owner),
            /*retained_bytes*/ usize::MAX,
            move |_| tx.send(()).unwrap()
        ),
        Submission::Queued
    );
    rx.recv_timeout(DEADLINE).unwrap();
}
