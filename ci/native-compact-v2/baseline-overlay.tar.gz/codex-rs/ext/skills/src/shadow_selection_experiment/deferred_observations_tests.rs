use super::*;
use std::sync::Barrier;

fn observations() -> DeferredObservations<Vec<usize>> {
    DeferredObservations::new(["a".into(), "b".into()].into_iter().collect())
}

#[test]
fn early_and_late_observations_are_each_delivered_once() {
    let state = observations();
    assert!(matches!(state.observe("a"), Observation::Pending));
    assert!(matches!(state.observe("a"), Observation::Ignored));
    let ranks = Arc::new(vec![7, 3]);
    assert_eq!(state.publish(Arc::clone(&ranks)), vec!["a"]);
    match state.observe("b") {
        Observation::Ready(actual) => assert!(Arc::ptr_eq(&actual, &ranks)),
        _ => panic!("late observation did not receive the frozen ranking"),
    }
    assert!(matches!(state.observe("a"), Observation::Ignored));
    assert!(matches!(state.observe("b"), Observation::Ignored));
    assert_eq!(state.publish(Arc::new(vec![9])), Vec::<String>::new());
}

#[test]
fn foreign_resources_cannot_grow_pending_state() {
    let state = observations();
    for index in 0..10000 {
        assert!(matches!(
            state.observe(&format!("foreign-{index}")),
            Observation::Ignored
        ));
    }
    let inner = state.inner.lock().unwrap();
    assert!(inner.pending.is_empty());
    assert!(inner.seen.is_empty());
}

#[test]
fn concurrent_publish_and_duplicate_calls_deliver_exactly_once() {
    for _ in 0..100 {
        let state = Arc::new(observations());
        let barrier = Arc::new(Barrier::new(9));
        let mut threads = Vec::new();
        for _ in 0..8 {
            let state = Arc::clone(&state);
            let barrier = Arc::clone(&barrier);
            threads.push(std::thread::spawn(move || {
                barrier.wait();
                usize::from(matches!(state.observe("a"), Observation::Ready(_)))
            }));
        }
        barrier.wait();
        let mut delivered = state.publish(Arc::new(vec![7])).len();
        for thread in threads {
            delivered += thread.join().unwrap();
        }
        assert_eq!(delivered, 1);
    }
}

#[test]
fn turn_states_cannot_publish_into_each_other() {
    let old = Arc::new(observations());
    let new = observations();
    assert!(matches!(old.observe("a"), Observation::Pending));
    assert!(matches!(new.observe("a"), Observation::Pending));
    assert_eq!(old.publish(Arc::new(vec![1])), vec!["a"]);
    assert_eq!(new.publish(Arc::new(vec![2])), vec!["a"]);
    let weak = Arc::downgrade(&old);
    drop(old);
    assert!(weak.upgrade().is_none());
}

#[test]
fn second_publication_cannot_replace_frozen_ranking() {
    let state = observations();
    let original = Arc::new(vec![1]);
    assert!(state.publish(Arc::clone(&original)).is_empty());
    assert!(state.publish(Arc::new(vec![2])).is_empty());
    match state.observe("b") {
        Observation::Ready(actual) => assert!(Arc::ptr_eq(&actual, &original)),
        _ => panic!("ranking missing"),
    }
}
