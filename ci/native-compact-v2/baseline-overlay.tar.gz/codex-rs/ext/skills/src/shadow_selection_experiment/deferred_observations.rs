use std::collections::HashSet;
use std::sync::Arc;
use std::sync::Mutex;

/// Turn-local observations that can arrive before background ranking finishes.
/// The caller bounds resources using the immutable eligible-resource set.
pub(crate) struct DeferredObservations<R> {
    inner: Mutex<Inner<R>>,
}

struct Inner<R> {
    eligible: HashSet<String>,
    seen: HashSet<String>,
    pending: Vec<String>,
    rankings: Option<Arc<R>>,
}

pub(crate) enum Observation<R> {
    Ignored,
    Pending,
    Ready(Arc<R>),
}

impl<R> DeferredObservations<R> {
    pub(crate) fn new(eligible: HashSet<String>) -> Self {
        Self {
            inner: Mutex::new(Inner {
                eligible,
                seen: HashSet::new(),
                pending: Vec::new(),
                rankings: None,
            }),
        }
    }

    pub(crate) fn observe(&self, resource: &str) -> Observation<R> {
        let mut inner = self
            .inner
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner);
        if !inner.eligible.contains(resource) || !inner.seen.insert(resource.to_owned()) {
            return Observation::Ignored;
        }
        if let Some(rankings) = &inner.rankings {
            Observation::Ready(Arc::clone(rankings))
        } else {
            inner.pending.push(resource.to_owned());
            Observation::Pending
        }
    }

    /// Publishes once and returns only observations not already handed to a reader.
    /// Callers emit metrics after this method releases its lock.
    pub(crate) fn publish(&self, rankings: Arc<R>) -> Vec<String> {
        let mut inner = self
            .inner
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner);
        if inner.rankings.is_some() {
            return Vec::new();
        }
        inner.rankings = Some(rankings);
        std::mem::take(&mut inner.pending)
    }
}

#[cfg(test)]
#[path = "deferred_observations_tests.rs"]
mod tests;
