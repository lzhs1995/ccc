use std::collections::HashSet;

use codex_skills::SkillDependencies;

use crate::catalog::SkillCatalog;
use crate::catalog::SkillSourceKind;

use super::normalize_skill_resource;

/// Owned selector inputs without skill bodies, environment handles or display metadata.
pub(super) struct DiagnosticDocument {
    pub id: usize,
    pub resource: String,
    pub name: String,
    pub short_description: Option<String>,
    pub description: String,
    pub dependencies: Option<SkillDependencies>,
}

impl DiagnosticDocument {
    /// Owned document storage requested from Rust collections; excludes allocator overhead.
    pub(super) fn retained_bytes(documents: &[Self], capacity: usize) -> usize {
        let mut bytes = capacity.saturating_mul(std::mem::size_of::<Self>());
        for document in documents {
            for value in [&document.resource, &document.name, &document.description] {
                bytes = bytes.saturating_add(value.capacity());
            }
            if let Some(value) = &document.short_description {
                bytes = bytes.saturating_add(value.capacity());
            }
            if let Some(dependencies) = &document.dependencies {
                bytes = bytes.saturating_add(
                    dependencies
                        .tools
                        .capacity()
                        .saturating_mul(std::mem::size_of::<codex_skills::SkillToolDependency>()),
                );
                for tool in &dependencies.tools {
                    for value in [&tool.r#type, &tool.value] {
                        bytes = bytes.saturating_add(value.capacity());
                    }
                    for value in [&tool.description, &tool.transport, &tool.command, &tool.url]
                        .into_iter()
                        .flatten()
                    {
                        bytes = bytes.saturating_add(value.capacity());
                    }
                }
            }
        }
        bytes
    }

    pub(super) fn from_catalog(catalog: SkillCatalog, excluded: &HashSet<String>) -> Vec<Self> {
        catalog
            .entries
            .into_iter()
            .enumerate()
            .filter_map(|(id, entry)| {
                if !entry.is_model_visible()
                    || !matches!(
                        entry.authority.kind,
                        SkillSourceKind::Host | SkillSourceKind::Cloud
                    )
                {
                    return None;
                }
                let resource = normalize_skill_resource(entry.main_prompt.as_str());
                if excluded.contains(&resource) {
                    return None;
                }
                Some(Self {
                    id,
                    resource,
                    name: entry.name,
                    short_description: entry.short_description,
                    description: entry.description,
                    dependencies: entry.dependencies,
                })
            })
            .collect()
    }
}
