use super::*;
use pretty_assertions::assert_eq;
use std::os::unix::fs::MetadataExt;
use std::os::unix::fs::PermissionsExt;

const KEY: &str = "0123456789abcdef01234567";
const SECONDS: i64 = 1_760_000_000;

struct Fixture {
    _dir: tempfile::TempDir,
    base: PathBuf,
    root: PathBuf,
    params: ThreadCompactInterruptParams,
    rollout: PathBuf,
}

fn put(path: &Path, value: &Value) {
    std::fs::write(path, value.to_string()).unwrap();
    std::fs::set_permissions(path, std::fs::Permissions::from_mode(0o600)).unwrap();
}

fn pin(path: &Path) -> Value {
    json!({"path": path, "sha256": sha256_hex(&std::fs::read(path).unwrap())})
}

fn names(root: &Path) -> Vec<String> {
    let mut names: Vec<String> = std::fs::read_dir(root)
        .unwrap()
        .map(|e| e.unwrap().file_name().to_string_lossy().into_owned())
        .collect();
    names.sort();
    names
}

/// A real original journal: `edit` may break any document before it is written.
fn fixture(edit: impl FnOnce(&mut Value)) -> Fixture {
    // The manifest dir is runner-owned without group/world write, unlike /tmp.
    let dir = tempfile::tempdir_in(env!("CARGO_MANIFEST_DIR")).unwrap();
    let base = dir.path().canonicalize().unwrap();
    let root = base.join("journal");
    std::fs::create_dir(&root).unwrap();
    std::fs::set_permissions(&root, std::fs::Permissions::from_mode(0o700)).unwrap();
    let thread = uuid::Uuid::new_v4().to_string();
    let occurrence = uuid::Uuid::new_v4().to_string();
    let rollout = base.join("rollout.jsonl");
    std::fs::write(&rollout, b"{}\n").unwrap();
    let meta = std::fs::metadata(&rollout).unwrap();
    let file_id = json!([meta.dev(), meta.ino()]);
    let pid = std::process::id();
    let params = ThreadCompactInterruptParams {
        thread_id: thread.clone(),
        expected_turn_id: "turn-1".into(),
        compaction_occurrence: occurrence.clone(),
        attempt_id: KEY.into(),
        intent_path: root
            .join(format!("{KEY}-interrupt.json"))
            .to_string_lossy()
            .into_owned(),
        client_pid: pid,
    };
    let process = json!({"pid": pid, "birth": [SECONDS, 12], "tty": "/dev/ttys001"});
    let (workspace, pane, surface) = (
        uuid::Uuid::new_v4().to_string().to_uppercase(),
        uuid::Uuid::new_v4().to_string().to_uppercase(),
        uuid::Uuid::new_v4().to_string().to_uppercase(),
    );
    let now = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap()
        .as_secs_f64();
    let mut docs = json!({
        "intent": {"kind":"interrupt","session_id":thread,"binding":process,
            "params":{"threadId":thread,"turnId":"turn-1"},
            "client_request": serde_json::to_value(&params).unwrap(),
            "input_token":"tok-1","client_epoch":"epoch-1","goal_revision":null,
            "facts":{"path":rollout,"file_id":file_id,"user_offset":7}},
        "state": {"episode":{"key":KEY,"phase":"control_pending","turn_id":"turn-1",
            "compaction_occurrence":occurrence,"input_token":"tok-1","attempt":0,
            "started_at":now - 400.0,"path":rollout,"file_id":file_id,"user_offset":7,
            "goal":null},
            "authenticated_binding":{"process":process},"target":{"process":process}},
        "foreground": {"schema":1,"purpose":"client_foreground_thread","pid":pid,
            "client_epoch":"epoch-1","thread_id":thread,
            "compact_interrupt_capability":CAPABILITY},
        "enrollment": {"scope":"existing_compact_sessions_180_300_v2",
            "targets":[{"session_id":thread,"surface_id":surface,"workspace_id":workspace,
                "pane_id":pane,"process":{"pid":1},"model":"gpt-5.5","effort":"high"}]},
        "config": {"global_paused":false,"sessions":{}},
        "pending": [],
        "native": [],
        "authority": {"schema":AUTHORITY_SCHEMA,"episode_key":KEY,
            "intent_path":params.intent_path,"session_id":thread,
            "compaction_occurrence":occurrence,
            "target":{"workspace_id":workspace,"pane_id":pane,"surface_id":surface,
                "session_id":thread,"process":process,"model":"gpt-5.5","effort":"high"},
            "client":{"pid":pid,"epoch":"epoch-1","thread_id":thread,"capability":CAPABILITY},
            "input_guard":{"safe":true,"caught_up":true,"token":"tok-1",
                "pending":[],"unknown":[]}},
    });
    edit(&mut docs);
    let files = [
        ("intent", format!("{KEY}-interrupt.json")),
        ("state", "state.json".into()),
        ("foreground", "foreground.json".into()),
        ("enrollment", "enrollment.json".into()),
        ("config", "config.json".into()),
        ("pending", "pending-inputs.json".into()),
        ("native", "native-input-intents.json".into()),
    ];
    for (doc, name) in &files {
        put(&root.join(name), &docs[*doc]);
    }
    let mut authority = docs["authority"].clone();
    authority["foreground"] = pin(&root.join("foreground.json"));
    authority["enrollment"] = pin(&root.join("enrollment.json"));
    authority["config"] = pin(&root.join("config.json"));
    authority["pinned_inputs"] = json!([
        pin(&root.join("pending-inputs.json")),
        pin(&root.join("native-input-intents.json")),
    ]);
    put(&root.join(format!("{KEY}-authority.json")), &authority);
    Fixture {
        _dir: dir,
        base,
        root,
        params,
        rollout,
    }
}
/// Lower-case form of an authority target UUID, to prove canonical comparison.
fn lower(d: &Value, field: &str) -> String {
    d["authority"]["target"][field]
        .as_str()
        .unwrap()
        .to_lowercase()
}

fn read(f: &Fixture) -> anyhow::Result<OriginalIntent> {
    OriginalIntent::read(&f.params, &f.rollout)
}

fn claimed(f: &Fixture) -> bool {
    f.root.join(format!("{KEY}-client-claimed.json")).exists()
}

#[test]
fn valid_original_claims_once_and_every_receipt_is_write_once() {
    let f = fixture(|_| {});
    let original = read(&f).unwrap();
    original.check_goal(None).unwrap();
    original.claim().unwrap();
    assert_eq!(
        original.claim().unwrap_err().kind(),
        std::io::ErrorKind::AlreadyExists
    );
    // A fresh read of the same original episode is not a new budget.
    assert_eq!(
        read(&f).unwrap().claim().unwrap_err().kind(),
        std::io::ErrorKind::AlreadyExists
    );
    original
        .receipt("interrupted", &json!({"turnId":"turn-1"}))
        .unwrap();
    assert!(original.receipt("interrupted", &json!({})).is_err());
    original.compact_intent().unwrap();
    assert_eq!(
        original.compact_intent().unwrap_err().kind(),
        std::io::ErrorKind::AlreadyExists
    );
    // A partial UNKNOWN claim is still the consumed budget; nothing was removed.
    std::fs::write(f.root.join(format!("{KEY}-client-claimed.json")), b"{").unwrap();
    assert!(original.claim().is_err());
    assert!(names(&f.root).contains(&format!("{KEY}-compact.json")));
}

#[test]
fn drift_after_read_is_rejected_before_any_side_effect() {
    let cases: [(&str, &[u8]); 7] = [
        ("intent", b"{\"kind\":\"interrupt\"}"),
        ("authority", b"{}"),
        ("state", b"{\"episode\":{}}"),
        ("foreground.json", b"{}"),
        ("pending-inputs.json", b"[1]"),
        ("native-input-intents.json", b"[1]"),
        ("config.json", b"{\"global_paused\":true}"),
    ];
    for (target, bytes) in cases {
        let f = fixture(|_| {});
        let original = read(&f).unwrap();
        let name = match target {
            "intent" => format!("{KEY}-interrupt.json"),
            "authority" => format!("{KEY}-authority.json"),
            "state" => "state.json".into(),
            other => other.into(),
        };
        std::fs::write(f.root.join(&name), bytes).unwrap();
        assert!(original.claim().is_err(), "{target} drift claimed");
        assert!(
            original.compact_intent().is_err(),
            "{target} drift wrote compact"
        );
        assert!(!claimed(&f), "{target} drift left a claim");
    }
}

#[test]
fn symlinked_or_replaced_ancestor_is_never_touched() {
    let f = fixture(|_| {});
    let original = read(&f).unwrap();
    let moved = f.base.join("moved");
    std::fs::rename(&f.root, &moved).unwrap();
    std::os::unix::fs::symlink(&moved, &f.root).unwrap();
    assert!(original.claim().is_err());
    assert!(!moved.join(format!("{KEY}-client-claimed.json")).exists());
    // Same bytes in a different directory inode is still a replaced ancestor.
    std::fs::remove_file(&f.root).unwrap();
    std::fs::create_dir(&f.root).unwrap();
    std::fs::set_permissions(&f.root, std::fs::Permissions::from_mode(0o700)).unwrap();
    for name in names(&moved) {
        std::fs::copy(moved.join(&name), f.root.join(&name)).unwrap();
    }
    assert!(original.claim().is_err());
    assert!(!claimed(&f) && !moved.join(format!("{KEY}-client-claimed.json")).exists());
    // A freshly opened symlinked journal is refused at read time too.
    let g = fixture(|_| {});
    let moved = g.base.join("moved");
    std::fs::rename(&g.root, &moved).unwrap();
    std::os::unix::fs::symlink(&moved, &g.root).unwrap();
    assert!(read(&g).is_err());
}

#[test]
fn untrusted_or_wrong_authority_is_rejected_before_any_write() {
    let cases: Vec<(&str, Box<dyn FnOnce(&mut Value)>)> = vec![
        (
            "enrollment target",
            Box::new(|d: &mut Value| {
                d["enrollment"]["targets"][0]["surface_id"] =
                    json!(uuid::Uuid::new_v4().to_string())
            }),
        ),
        (
            "enrollment duplicated",
            Box::new(|d: &mut Value| {
                let t = d["enrollment"]["targets"][0].clone();
                d["enrollment"]["targets"].as_array_mut().unwrap().push(t);
            }),
        ),
        (
            "enrollment scope",
            Box::new(|d: &mut Value| d["enrollment"]["scope"] = json!("restored_success")),
        ),
        (
            "enrollment empty",
            Box::new(|d: &mut Value| d["enrollment"]["targets"] = json!([])),
        ),
        (
            "process birth",
            Box::new(|d: &mut Value| {
                d["state"]["authenticated_binding"]["process"]["birth"] = json!([SECONDS, 13])
            }),
        ),
        (
            "birth not numeric",
            Box::new(|d: &mut Value| {
                for k in ["intent", "authority"] {
                    let p = if k == "intent" {
                        &mut d[k]["binding"]
                    } else {
                        &mut d[k]["target"]["process"]
                    };
                    p["birth"] = json!(["x", 12]);
                }
                d["state"]["authenticated_binding"]["process"]["birth"] = json!(["x", 12]);
            }),
        ),
        (
            "tty empty",
            Box::new(|d: &mut Value| d["authority"]["target"]["process"]["tty"] = json!("")),
        ),
        (
            "client epoch",
            Box::new(|d: &mut Value| d["authority"]["client"]["epoch"] = json!("epoch-2")),
        ),
        (
            "foreground epoch",
            Box::new(|d: &mut Value| d["foreground"]["client_epoch"] = json!("epoch-2")),
        ),
        (
            "foreground capability",
            Box::new(|d: &mut Value| d["foreground"]["compact_interrupt_capability"] = json!("v3")),
        ),
        (
            "global paused",
            Box::new(|d: &mut Value| d["config"]["global_paused"] = json!(true)),
        ),
        (
            "global paused null",
            Box::new(|d: &mut Value| d["config"]["global_paused"] = Value::Null),
        ),
        (
            "mode not armed",
            Box::new(|d: &mut Value| d["config"]["mode"] = json!("observe")),
        ),
        (
            "target row paused",
            Box::new(|d: &mut Value| {
                let s = lower(d, "surface_id");
                d["config"]["targets"] = json!([{"surface_id":s,"paused":true}]);
            }),
        ),
        (
            "target row disabled",
            Box::new(|d: &mut Value| {
                let s = lower(d, "surface_id");
                d["config"]["targets"] = json!([{"surface_id":s,"enabled":false}]);
            }),
        ),
        (
            "workspace rule paused",
            Box::new(|d: &mut Value| {
                let w = lower(d, "workspace_id");
                d["config"]["workspace_rules"] = json!([{"workspace_id":w,"paused":true}]);
            }),
        ),
        (
            "workspace rule disabled",
            Box::new(|d: &mut Value| {
                let w = lower(d, "workspace_id");
                d["config"]["workspace_rules"] = json!([{"workspace_id":w,"enabled":null}]);
            }),
        ),
        (
            "workspace excludes surface",
            Box::new(|d: &mut Value| {
                let (w, s) = (lower(d, "workspace_id"), lower(d, "surface_id"));
                d["config"]["workspace_rules"] =
                    json!([{"workspace_id":w,"excluded_surface_ids":[s]}]);
            }),
        ),
        (
            "discovery excludes surface",
            Box::new(|d: &mut Value| {
                let s = lower(d, "surface_id");
                d["config"]["discovery_excluded_surface_ids"] = json!([s]);
            }),
        ),
        (
            "config id not uuid",
            Box::new(|d: &mut Value| d["config"]["targets"] = json!([{"surface_id":"surface-1"}])),
        ),
        (
            "enrolled paused",
            Box::new(|d: &mut Value| d["enrollment"]["targets"][0]["paused"] = json!(true)),
        ),
        (
            "enrolled disabled",
            Box::new(|d: &mut Value| d["enrollment"]["targets"][0]["enabled"] = json!(false)),
        ),
        (
            "enrolled recovery disabled",
            Box::new(|d: &mut Value| {
                d["enrollment"]["targets"][0]["recovery_enabled"] = json!(false)
            }),
        ),
        (
            "authority model",
            Box::new(|d: &mut Value| d["authority"]["target"]["model"] = json!("gpt-5.4")),
        ),
        (
            "authority effort",
            Box::new(|d: &mut Value| d["authority"]["target"]["effort"] = json!("low")),
        ),
        (
            "enrolled effort null vs high",
            Box::new(|d: &mut Value| d["enrollment"]["targets"][0]["effort"] = Value::Null),
        ),
        (
            "enrolled effort absent",
            Box::new(|d: &mut Value| {
                d["enrollment"]["targets"][0]
                    .as_object_mut()
                    .unwrap()
                    .remove("effort");
            }),
        ),
        (
            "authority model empty",
            Box::new(|d: &mut Value| {
                d["authority"]["target"]["model"] = json!("");
                d["enrollment"]["targets"][0]["model"] = json!("");
            }),
        ),
        (
            "input pending",
            Box::new(|d: &mut Value| d["authority"]["input_guard"]["pending"] = json!(["x"])),
        ),
        (
            "input token",
            Box::new(|d: &mut Value| d["authority"]["input_guard"]["token"] = json!("tok-2")),
        ),
        (
            "schema",
            Box::new(|d: &mut Value| d["authority"]["schema"] = json!("ccc-compact-authority-v3")),
        ),
        (
            "occurrence",
            Box::new(|d: &mut Value| {
                d["authority"]["compaction_occurrence"] = json!(uuid::Uuid::new_v4().to_string())
            }),
        ),
        (
            "target uuid",
            Box::new(|d: &mut Value| d["authority"]["target"]["pane_id"] = json!("pane-1")),
        ),
    ];
    for (label, edit) in cases {
        let f = fixture(edit);
        let before = names(&f.root);
        assert!(read(&f).is_err(), "{label} accepted");
        assert_eq!(names(&f.root), before, "{label} wrote evidence");
    }
}

#[test]
fn group_writable_journal_is_untrusted() {
    let f = fixture(|_| {});
    std::fs::set_permissions(&f.root, std::fs::Permissions::from_mode(0o770 | 0o020)).unwrap();
    assert!(read(&f).is_err());
    assert!(!claimed(&f));
}
fn goal(thread: &str, goal_id: &str, created_ms: i64, updated_ms: i64) -> codex_state::ThreadGoal {
    codex_state::ThreadGoal {
        thread_id: codex_protocol::ThreadId::from_string(thread).unwrap(),
        goal_id: goal_id.into(),
        objective: "finish".into(),
        status: codex_state::ThreadGoalStatus::Active,
        token_budget: None,
        tokens_used: 5,
        time_used_seconds: 9,
        created_at: chrono::DateTime::from_timestamp_millis(created_ms).unwrap(),
        updated_at: chrono::DateTime::from_timestamp_millis(updated_ms).unwrap(),
    }
}

#[test]
fn same_second_goal_replace_is_rejected_by_revision() {
    let (created, updated) = (SECONDS * 1000 + 100, SECONDS * 1000 + 200);
    let f = fixture(|d| {
        let thread = d["intent"]["session_id"].clone();
        d["state"]["episode"]["goal"] = json!({"threadId":thread,"objective":"finish",
            "status":"active","tokenBudget":null,"tokensUsed":5,"timeUsedSeconds":9,
            "createdAt":SECONDS,"updatedAt":SECONDS});
        d["intent"]["goal_revision"] =
            json!({"goal_id":"goal-1","created_at_ms":created,"updated_at_ms":updated});
    });
    let original = read(&f).unwrap();
    let thread = f.params.thread_id;
    original
        .check_goal(Some(&goal(&thread, "goal-1", created, updated)))
        .unwrap();
    // Identical API seconds, different revision: replace/ABA within one second.
    assert!(
        original
            .check_goal(Some(&goal(&thread, "goal-2", created, updated)))
            .is_err()
    );
    assert!(
        original
            .check_goal(Some(&goal(&thread, "goal-1", created, updated + 1)))
            .is_err()
    );
    assert!(original.check_goal(None).is_err());
    // Expected null Goal needs an explicit null revision, not an absent one.
    let g = fixture(|d| {
        d["intent"].as_object_mut().unwrap().remove("goal_revision");
    });
    assert!(read(&g).unwrap().check_goal(None).is_err());
}

#[test]
fn unrelated_or_absent_ccc_rows_do_not_veto() {
    let f = fixture(|d| {
        let other = uuid::Uuid::new_v4().to_string();
        d["config"] = json!({"targets":[{"surface_id":other,"paused":true}],
            "workspace_rules":[{"workspace_id":other,"enabled":false,
                "excluded_surface_ids":[]}],
            "discovery_excluded_surface_ids":[other]});
    });
    read(&f).unwrap();
    // No global_paused/mode key at all is armed and clear, as in _current_config_clear.
    read(&fixture(|d| d["config"] = json!({}))).unwrap();
}

#[test]
fn settings_admission_needs_the_exact_enrolled_model_and_effort() {
    use codex_protocol::openai_models::ReasoningEffort;
    let f = fixture(|_| {});
    let original = read(&f).unwrap();
    // Before this candidate there was no settings gate: every case below passed.
    original
        .check_settings("gpt-5.5", Some(&ReasoningEffort::High))
        .unwrap();
    assert!(
        original
            .check_settings("gpt-5.4", Some(&ReasoningEffort::High))
            .is_err()
    );
    assert!(
        original
            .check_settings("gpt-5.5", Some(&ReasoningEffort::Medium))
            .is_err()
    );
    assert!(original.check_settings("gpt-5.5", None).is_err());
    assert!(
        original
            .check_settings("gpt-5.5", Some(&ReasoningEffort::None))
            .is_err()
    );
    // An enrolled null effort admits only an absent effort, never the Medium default.
    let g = fixture(|d| {
        d["enrollment"]["targets"][0]["effort"] = Value::Null;
        d["authority"]["target"]["effort"] = Value::Null;
    });
    let original = read(&g).unwrap();
    original.check_settings("gpt-5.5", None).unwrap();
    assert!(
        original
            .check_settings("gpt-5.5", Some(&ReasoningEffort::Medium))
            .is_err()
    );
    assert!(!claimed(&f) && !claimed(&g));
}

fn active_goal_fixture(created: i64, updated: i64) -> Fixture {
    fixture(|d| {
        let thread = d["intent"]["session_id"].clone();
        d["state"]["episode"]["goal"] = json!({"threadId":thread,"objective":"finish",
            "status":"active","tokenBudget":null,"tokensUsed":5,"timeUsedSeconds":9,
            "createdAt":SECONDS,"updatedAt":SECONDS});
        d["intent"]["goal_revision"] =
            json!({"goal_id":"goal-1","created_at_ms":created,"updated_at_ms":updated});
    })
}

#[test]
fn join_accounting_accepts_only_the_original_turns_exact_receipt() {
    use codex_goal_extension::JoinAccounting;
    use codex_goal_extension::JoinAccountingReceipt;
    let (created, updated) = (SECONDS * 1000 + 100, SECONDS * 1000 + 200);
    let f = active_goal_fixture(created, updated);
    let original = read(&f).unwrap();
    let thread = f.params.thread_id.clone();
    let before = goal(&thread, "goal-1", created, updated);
    let after = codex_state::ThreadGoal {
        tokens_used: 905,
        time_used_seconds: 309,
        updated_at: chrono::DateTime::from_timestamp_millis(updated + 300_000).unwrap(),
        ..before.clone()
    };
    let receipt = |before: &codex_state::ThreadGoal, after: &codex_state::ThreadGoal| {
        JoinAccounting::Accounted(JoinAccountingReceipt {
            turn_id: "turn-1".into(),
            attempt_id: KEY.into(),
            before: before.clone(),
            after: after.clone(),
        })
    };
    // Pre-candidate behavior: the all-field check denies normal join accounting.
    assert!(original.check_goal(Some(&after)).is_err());
    original
        .check_goal_after_join(Some(&after), &receipt(&before, &after), "turn-1", KEY)
        .unwrap();
    // No accounting: only the unchanged pinned Goal passes.
    original
        .check_goal_after_join(Some(&before), &JoinAccounting::NotAccounted, "turn-1", KEY)
        .unwrap();
    assert!(
        original
            .check_goal_after_join(Some(&after), &JoinAccounting::NotAccounted, "turn-1", KEY)
            .is_err()
    );
    // External edit after accounting: current is not exactly the receipt's row.
    let edited = codex_state::ThreadGoal {
        tokens_used: 906,
        ..after.clone()
    };
    assert!(
        original
            .check_goal_after_join(Some(&edited), &receipt(&before, &after), "turn-1", KEY)
            .is_err()
    );
    // External edit before accounting: the CAS pre row is not the pinned original.
    let moved = codex_state::ThreadGoal {
        tokens_used: 6,
        ..before.clone()
    };
    assert!(
        original
            .check_goal_after_join(Some(&after), &receipt(&moved, &after), "turn-1", KEY)
            .is_err()
    );
    // Same-second goal_id ABA, objective/budget edits and stopped statuses all veto.
    let aba = codex_state::ThreadGoal {
        goal_id: "goal-2".into(),
        ..after.clone()
    };
    assert!(
        original
            .check_goal_after_join(Some(&aba), &receipt(&before, &aba), "turn-1", KEY)
            .is_err()
    );
    let objective = codex_state::ThreadGoal {
        objective: "other".into(),
        ..after.clone()
    };
    assert!(
        original
            .check_goal_after_join(
                Some(&objective),
                &receipt(&before, &objective),
                "turn-1",
                KEY
            )
            .is_err()
    );
    let budget = codex_state::ThreadGoal {
        token_budget: Some(1),
        ..after.clone()
    };
    assert!(
        original
            .check_goal_after_join(Some(&budget), &receipt(&before, &budget), "turn-1", KEY)
            .is_err()
    );
    for status in [
        codex_state::ThreadGoalStatus::Paused,
        codex_state::ThreadGoalStatus::Blocked,
        codex_state::ThreadGoalStatus::BudgetLimited,
        codex_state::ThreadGoalStatus::Complete,
    ] {
        let stopped = codex_state::ThreadGoal {
            status,
            ..after.clone()
        };
        assert!(
            original
                .check_goal_after_join(Some(&stopped), &receipt(&before, &stopped), "turn-1", KEY)
                .is_err()
        );
    }
    // A "receipt" that accounted nothing, or went backwards, is not join accounting.
    assert!(
        original
            .check_goal_after_join(Some(&before), &receipt(&before, &before), "turn-1", KEY)
            .is_err()
    );
    let backwards = codex_state::ThreadGoal {
        tokens_used: 4,
        ..after.clone()
    };
    assert!(
        original
            .check_goal_after_join(
                Some(&backwards),
                &receipt(&before, &backwards),
                "turn-1",
                KEY
            )
            .is_err()
    );
    // A receipt for another turn or attempt never passes, even with exact rows.
    let foreign = |turn: &str, attempt: &str| {
        JoinAccounting::Accounted(JoinAccountingReceipt {
            turn_id: turn.into(),
            attempt_id: attempt.into(),
            before: before.clone(),
            after: after.clone(),
        })
    };
    assert!(
        original
            .check_goal_after_join(Some(&after), &foreign("turn-1", "other"), "turn-1", KEY)
            .is_err()
    );
    assert!(
        original
            .check_goal_after_join(Some(&after), &foreign("turn-2", KEY), "turn-1", KEY)
            .is_err()
    );
    assert!(
        original
            .check_goal_after_join(Some(&after), &receipt(&before, &after), "turn-1", "other")
            .is_err()
    );
    // Goal cleared during the join.
    assert!(
        original
            .check_goal_after_join(None, &receipt(&before, &after), "turn-1", KEY)
            .is_err()
    );
    assert_eq!(
        OriginalIntent::join_accounting_json(&receipt(&before, &after))["after"]["tokens_used"],
        json!(905)
    );
    assert!(!claimed(&f));
}

/// Reads a terminal receipt written by the real OriginalIntent writer.
fn terminal(f: &Fixture, phase: &str) -> Option<Value> {
    std::fs::read(f.root.join(format!("{KEY}-{phase}.json")))
        .ok()
        .map(|raw| serde_json::from_slice(&raw).unwrap())
}

#[test]
fn deterministic_denials_write_one_exact_terminal_receipt() {
    for reason in [
        DenyReason::GoalJoinAccountingRejected,
        DenyReason::GoalChanged,
        DenyReason::SettingsChanged,
        DenyReason::CompactBudgetConsumed,
    ] {
        let f = fixture(|_| {});
        let original = read(&f).unwrap();
        original.deny(reason).unwrap();
        assert_eq!(
            terminal(&f, "compact-denied"),
            Some(
                json!({"original_intent": f.params.intent_path, "episode_key": KEY,
                "fields": {"turnId": "turn-1", "attemptId": KEY, "reason": reason.as_str()}})
            )
        );
        // One use: a second denial (or a retry) never rewrites the terminal outcome.
        assert_eq!(
            original.deny(reason).unwrap_err().kind(),
            std::io::ErrorKind::AlreadyExists
        );
        assert!(terminal(&f, "not-interrupted").is_none());
    }
}

#[test]
fn false_interruption_writes_one_not_interrupted_receipt() {
    let f = fixture(|_| {});
    let original = read(&f).unwrap();
    original.not_interrupted().unwrap();
    assert_eq!(
        terminal(&f, "not-interrupted").unwrap()["fields"],
        json!({"turnId": "turn-1", "attemptId": KEY})
    );
    assert_eq!(
        original.not_interrupted().unwrap_err().kind(),
        std::io::ErrorKind::AlreadyExists
    );
    assert!(terminal(&f, "compact-denied").is_none());
}

#[test]
fn changed_boundary_input_or_config_leaves_no_terminal_receipt() {
    for target in [
        "pending-inputs.json",
        "native-input-intents.json",
        "config.json",
        "foreground.json",
        "state.json",
    ] {
        let f = fixture(|_| {});
        let original = read(&f).unwrap();
        std::fs::write(f.root.join(target), b"[1]").unwrap();
        // UNKNOWN: neither a denial nor a non-reception claim may be recorded.
        assert!(original.deny(DenyReason::GoalChanged).is_err(), "{target}");
        assert!(original.not_interrupted().is_err(), "{target}");
        assert!(terminal(&f, "compact-denied").is_none(), "{target}");
        assert!(terminal(&f, "not-interrupted").is_none(), "{target}");
    }
    // A replaced journal ancestor is the same: no write anywhere.
    let f = fixture(|_| {});
    let original = read(&f).unwrap();
    let moved = f.base.join("moved");
    std::fs::rename(&f.root, &moved).unwrap();
    std::os::unix::fs::symlink(&moved, &f.root).unwrap();
    assert!(original.deny(DenyReason::GoalChanged).is_err());
    assert!(!moved.join(format!("{KEY}-compact-denied.json")).exists());
}

#[test]
fn real_python_producer_files_match_the_native_reader_contract() {
    let Some(manifest_path) = std::env::var_os("CCC_REAL_PRODUCER_MANIFEST") else {
        return;
    };
    let manifest: Value = serde_json::from_slice(&std::fs::read(manifest_path).unwrap()).unwrap();
    let cases = manifest["cases"].as_array().unwrap();
    assert_eq!(cases.len(), 7);
    for case in cases {
        let params: ThreadCompactInterruptParams =
            serde_json::from_value(case["request"].clone()).unwrap();
        let rollout = PathBuf::from(case["rollout"].as_str().unwrap());
        let name = case["name"].as_str().unwrap();
        match case["expected_reader"].as_str().unwrap() {
            "accept" => {
                let original = OriginalIntent::read(&params, &rollout)
                    .unwrap_or_else(|error| panic!("producer fixture {name}: {error}"));
                original.revalidate().unwrap();
                original
                    .check_settings(
                        "gpt-5.5",
                        Some(&codex_protocol::openai_models::ReasoningEffort::High),
                    )
                    .unwrap();
                let pinned_goal = if original.episode["goal"].is_null() {
                    None
                } else {
                    let g = &original.episode["goal"];
                    let revision = &original.value["goal_revision"];
                    Some(codex_state::ThreadGoal {
                        thread_id: codex_protocol::ThreadId::from_string(
                            g["threadId"].as_str().unwrap(),
                        )
                        .unwrap(),
                        goal_id: revision["goal_id"].as_str().unwrap().into(),
                        objective: g["objective"].as_str().unwrap().into(),
                        status: codex_state::ThreadGoalStatus::Active,
                        token_budget: g["tokenBudget"].as_i64(),
                        tokens_used: g["tokensUsed"].as_i64().unwrap(),
                        time_used_seconds: g["timeUsedSeconds"].as_i64().unwrap(),
                        created_at: chrono::DateTime::from_timestamp_millis(
                            revision["created_at_ms"].as_i64().unwrap(),
                        )
                        .unwrap(),
                        updated_at: chrono::DateTime::from_timestamp_millis(
                            revision["updated_at_ms"].as_i64().unwrap(),
                        )
                        .unwrap(),
                    })
                };
                original.check_goal(pinned_goal.as_ref()).unwrap();
                let (after_goal, join) = if let Some(before) = pinned_goal.as_ref() {
                    let mut after = before.clone();
                    after.tokens_used += 1;
                    after.updated_at += chrono::Duration::milliseconds(1);
                    let join = codex_goal_extension::JoinAccounting::Accounted(
                        codex_goal_extension::JoinAccountingReceipt {
                            turn_id: params.expected_turn_id.clone(),
                            attempt_id: params.attempt_id.clone(),
                            before: before.clone(),
                            after: after.clone(),
                        },
                    );
                    (Some(after), join)
                } else {
                    (None, codex_goal_extension::JoinAccounting::NotAccounted)
                };
                original
                    .check_goal_after_join(
                        after_goal.as_ref(),
                        &join,
                        &params.expected_turn_id,
                        &params.attempt_id,
                    )
                    .unwrap();
                original.claim().unwrap();
                assert_eq!(
                    original.claim().unwrap_err().kind(),
                    std::io::ErrorKind::AlreadyExists
                );
                original
                    .receipt("interrupted", &json!({"turnId": params.expected_turn_id}))
                    .unwrap();
                original.compact_intent().unwrap();
                original
                    .receipt(
                        "compact-started",
                        &json!({
                            "turnId": "fixture-new-turn",
                            "joinAccounting": OriginalIntent::join_accounting_json(&join)
                        }),
                    )
                    .unwrap();
            }
            "no-intent" => {
                assert!(
                    !Path::new(&params.intent_path).exists(),
                    "rejected producer {name} left an intent"
                );
                assert!(
                    OriginalIntent::read(&params, &rollout).is_err(),
                    "rejected producer {name} read"
                );
            }
            status => panic!("unknown producer expectation: {status}"),
        }
    }
}
